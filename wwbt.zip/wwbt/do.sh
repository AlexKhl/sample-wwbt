#!/usr/bin/env bash

case $HOSTNAME in
    "wwbt")
        #production web server
        source ./configs/prod/env.sh
    ;;
    *)
        #dev environment
        source ./configs/dev/env.sh
    ;;
esac

case $1 in
    "env")
        case $HOSTNAME in
        "wwbt")
            echo "PRODUCTION ENVIRONMENT"
            cat ./configs/prod/env.sh
            echo ""
        ;;
        *)
            echo "DEVELOPMENT ENVIRONMENT"
            cat ./configs/dev/env.sh
            echo ""
        ;;
        esac
        ;;
    "reset")
        ./do.sh stop
        ./do.sh clean
        ./do.sh init
        ./do.sh start
        sleep 5
        ;;
    "fullImport")
        ./do.sh drop
        ./do.sh rank
        ./do.sh import
        ./do.sh wikiImageBuildList
        ./do.sh wikiImageDownloadImages
        ./do.sh drop
        ./do.sh import
        ;;
    "import")
        ./do.sh population
        echo "run import command"
        if [ -f ${wikiDumps}/${articleXmlRaw} ]; then
            echo "use uncompressed file"
            #-d xdebug.profiler_enable=On
            pv ${wikiDumps}/${articleXmlRaw}|php ./parser/extract_persons.php
        else
            echo "use compressed file"
            #-d xdebug.profiler_enable=On
            pv ${wikiDumps}/${articleXmlArchive}|bzip2 -c -d|php ./parser/extract_persons.php
        fi;
        ;;
    "celebs")
        echo "run celebs updating"
        php ./parser/extract_celebs.php
        ;;
    "population")
        echo "population index fill"
        source venv/bin/activate
        scrapy runspider python_scripts/scrap_population.py
        exit
       ;;
    "rank")
        echo "run rank calculation"
        if [ -f ${wikiDumps}/${articleXmlRaw} ]; then
            echo "use uncompressed file"
            pv ${wikiDumps}/${articleXmlRaw}|php ./parser/extract_rank.php
        else
            echo "use compressed file"
            pv ${wikiDumps}/${articleXmlArchive}|bzip2 -c -d|php ./parser/extract_rank.php
        fi;
        ;;
    "dump")
        #no echo here, only xml data
        if [ -f ${wikiDumps}/${articleXmlRaw} ]; then
            pv ${wikiDumps}/${articleXmlRaw}
        else
            pv ${wikiDumps}/${articleXmlArchive}|bzip2 -c -d
        fi;
        ;;
    "system")
        echo "run system init command"
        sudo apt-get install pv bzip2 pbzip2 php php-mbstring php-curl php-fpm php-xml nodejs npm nginx ruby-dev
        #npm should be removed for Ubuntu 17.10
        #sudo gem install sass
        #sudo ln -s /usr/bin/nodejs /usr/bin/node #ubuntu nodejs fix
        ;;
    "wikiImageDownloadList")
        echo "get list of images from wikidumps"
        mkdir ${wikiDumps}/images/
        rsync -z -n -r -v rsync://ftpmirror.your.org/wikimedia-images/ ${wikiDumps}/images/ > ./generated/wikiImageDownloadList.txt
        ln -s ${wikiDumps}/images/ ./www/imgdata
        ;;
    "wikiImageBuildList")
        echo "build list of images to download from wikidumps"
        grep -F -f ./generated/wikiImageBuildList.txt ./generated/wikiImageDownloadList.txt |php ./parser/latest-version-only.php > ./generated/rsyncImageList.txt
        ;;
    "wikiImageDownloadImages")
        echo "download images from wikidumps"
        rsync -z -a -v --files-from=./generated/rsyncImageList.txt rsync://ftpmirror.your.org/wikimedia-images/ ${wikiDumps}/images/
        ;;
    "snapshot-init")
        echo "init elasticsearch snapshot storage"
        curl -XDELETE "${elasticServer}/_snapshot/${snapshotStorage}"
        echo ""
        if [[ ! -d "${wikiDumps}/elasticsearch/" ]]; then
            mkdir -v -p "${wikiDumps}/elasticsearch/"
        fi
        path=${wikiDumps}/elasticsearch/
        curl -XPUT "${elasticServer}/_snapshot/${snapshotStorage}?pretty" -H 'Content-Type: application/json' -d"
        {
          \"type\": \"fs\",
          \"settings\": {
            \"location\": \"${path}\",
            \"compress\": true
          }
        }
        "
        echo ""
        ;;
    "snapshot-save")
        echo "backup elasticsearch database"
        snapshot="${2:-snapshot_1}"
        curl -s -XDELETE "${elasticServer}/_snapshot/${snapshotStorage}/${snapshot}" > /dev/null
        curl -XPUT "${elasticServer}/_snapshot/${snapshotStorage}/${snapshot}?wait_for_completion=true" -H 'Content-Type: application/json' -d'
        {
          "indices": "*",
          "ignore_unavailable": true,
          "include_global_state": false
        }'
        echo ""
        ;;
    "snapshot-delete")
        echo "delete elasticsearch snapshot"
        snapshot="${2:-snapshot_1}"
        curl -XDELETE "${elasticServer}/_snapshot/${snapshotStorage}/${snapshot}"
        echo ""
        ;;
    "snapshot-restore")
        echo "restore elasticsearch database"
        snapshot="${2:-snapshot_1}"
        curl -XPOST "${elasticServer}/*/_close"
        echo ""
        curl -XPOST "${elasticServer}/_snapshot/${snapshotStorage}/${snapshot}/_restore?wait_for_completion=true"
        echo ""
        curl -XPOST "${elasticServer}/*/_open"
        echo ""
        curl -XPUT "${elasticServer}/*/_settings" -H 'Content-Type: application/json' -d'
        {
            "index" : {"number_of_replicas" : 0}
        }'
        echo ""
        ;;
    "snapshot-upload")
        echo "upload elasticsearch snapshots"
        path=${wikiDumps}/elasticsearch/
        rsync -avz --delete --info=progress2 ${path} wiki.gamehour.ru:/home/pavel/wwbt-elasticsearch-dev
        ;;
    "snapshot-list")
        echo "upload elasticsearch snapshots"
        curl -XGET "${elasticServer}/_cat/snapshots/${snapshotStorage}?v&s=id"
        ;;
    "snapshot-download")
        echo "upload elasticsearch snapshots"
                curl -XDELETE "${elasticServer}/_snapshot/${snapshotStorage}"
        echo ""
        if [[ ! -d "${wikiDumps}/elasticsearch/" ]]; then
            mkdir -v -p "${wikiDumps}/elasticsearch/"
        fi
        path=${wikiDumps}/elasticsearch/
        rsync -avz --delete --info=progress2 wiki.gamehour.ru:/home/pavel/wwbt-elasticsearch-dev/ ${path}
        curl -XPUT "${elasticServer}/_snapshot/${snapshotStorage}?pretty" -H 'Content-Type: application/json' -d"
        {
          \"type\": \"fs\",
          \"settings\": {
            \"location\": \"${path}\",
            \"compress\": true
          }
        }
        "
        echo ""
        ;;
    "init")
        echo "install tools"
        if [[ ! -d "./tools/elasticsearch/" ]]; then
            mkdir -v -p "./tools/elasticsearch/"
        fi
        pp=$(pwd)
        cd "./tools/elasticsearch/"
        wget -c -O "elasticsearch.zip" "https://artifacts.elastic.co/downloads/elasticsearch/${esVersion}.zip"
        wget -c -O "kibana.zip" "https://artifacts.elastic.co/downloads/kibana/${kibanaVersion}.tar.gz"
        echo "elasticsearch archive is valid";
        if [ -d "elasticsearch" ]; then
            echo -e "\e[31mdirectory already exists.\e[0m execute \e[32m./do.sh clean\e[0m first"
        else
            unzip -K -q "./elasticsearch.zip";
            tar -xf "./kibana.zip";
            cat $pp/configs/dev/elasticsearch.yml >> "${esVersion}/config/elasticsearch.yml"
            cat $pp/configs/dev/kibana.yml >> "${kibanaVersion}/config/kibana.yml"
        fi
        cd -;
        ;;
    "drop")
        echo "drop database"
        curl -XDELETE "${elasticServer}/person"
        echo ""
        ;;
    "clean")
        echo "clean all installed tools"
        cd "./tools/elasticsearch/"
        rm -R "./${esVersion}";
        rm -R "./${kibanaVersion}";
        cd -;
        ;;
    "start")
        echo "start services"
        if [ -d "./tools/elasticsearch/${esVersion}/bin/" ]; then
            cd "./tools/elasticsearch/${esVersion}/bin/"
            ./elasticsearch 2>&1 >/dev/null&
            cd  -;
        else
            echo -e "\e[31mdirectory not exists.\e[0m execute \e[32m./do.sh init\e[0m first"
        fi
        if [ -d "./tools/elasticsearch/${kibanaVersion}/bin/" ]; then
            cd "./tools/elasticsearch/${kibanaVersion}/bin/"
            ./kibana 2>&1 >/dev/null&
            cd  -;
        else
            echo -e "\e[31mdirectory not exists.\e[0m execute \e[32m./do.sh init\e[0m first"
        fi
        cd "./www"
        php -S localhost:8852 index_dev.php 2>&1 ../application.log&
        cd -
        ;;
    "browser")
        echo "open urls in browser"
        chromium-browser "${elasticServer}"
        chromium-browser "http://localhost:5601"
        chromium-browser "http://localhost:8852"
        ;;
    "stop")
        echo "stop all services"
        echo "tools/elasticsearch/${esVersion}"
        pkill -f "tools/elasticsearch/${esVersion}"
        pkill -f "node/bin/node --no-warnings ./../src/cli"
        pkill -f "php -S localhost:8852 index_dev.php"
        pkill -f "php -S localhost:8852 index.php"
        ;;
    "validate")
        echo "validate project"
        composer validate --no-check-all --strict
        ;;
    "prod-install")
        echo "install production environment"
        sudo apt-get install pv bzip2 pbzip2 php php-mbstring php-curl php-fpm php-xml nodejs npm nginx openjdk-9-jdk-headless openjdk-9-jdk-headless
        #https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.2.1.deb
        ;;
    "sitemaps")
        echo "generate sitemaps"
        cd crons
        php sitemaps.php
        cd -;
        cd www/sitemaps-KesbunshIv7
        gzip -kvf ./*.txt
        cd -;

        ;;
    *)
        echo "command is unknown"
        ;;
esac