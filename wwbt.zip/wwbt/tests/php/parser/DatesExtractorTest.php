<?php

require_once __DIR__."/../../../vendor/autoload.php";


final class DatesExtractorTest extends \diplux\tests\DipluxTestCase
{
    public function testGetDatesTest()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            96,
            $parser->getAge('1907-02-09', '2003-03-31')
        );
    }
    public function testDateExtraction()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals([
            'date' => "1924",
            'key' => '',
            'year' => 1924,
            'month' => null,
            'day' => null,
            'original' => '1924',
        ], $parser->extractDate('{{nowrap|1924}}'));

        $this->assertEquals([
            'date' => "1924",
            'key' => '',
            'year' => 1924,
            'month' => null,
            'day' => null,
            'original' => '1924',
        ], $parser->extractDate('1924'));

        $this->assertEquals([
            'date' => "1994-10-20",
            'key' => '10-20',
            'year' => 1994,
            'month' => 10,
            'day' => 20,
            'original' => '{{Death date and age|1994|10|20|1920|01|07}}',
        ], $parser->extractDate('{{Death date and age|1994|10|20|1920|01|07}}'));

        $this->assertEquals([
            'date' => "1989-12-26",
            'key' => '12-26',
            'year' => 1989,
            'month' => 12,
            'day' => 26,
            'original' => '{{death date and age|df=yes|1989|12|26|1918|6|20}}',
        ], $parser->extractDate('{{death date and age|df=yes|1989|12|26|1918|6|20}}'));

        $this->assertEquals([
            'date' => "2011-07-08",
            'key' => '07-08',
            'year' => 2011,
            'month' => 7,
            'day' => 8,
            'original' => '{{death date and age|2011|7|8|1918|4|8}}',
        ], $parser->extractDate('{{death date and age|2011|7|8|1918|4|8}}'));

        $this->assertEquals([
            'date' => "2005",
            'key' => '',
            'year' => 2005,
            'month' => null,
            'day' => null,
            'original' => '{{death year and age|2005|1921}}',
        ], $parser->extractDate('{{death year and age|2005|1921}}'));

        $this->assertEquals([
            'date' => "1996-11-27",
            'key' => '11-27',
            'year' => 1996,
            'month' => 11,
            'day' => 27,
            'original' => '{{death date and age|1996|11|27|1917|12|18|df=yes}}<ref name="Olimpianos">{{cite book|last = Rubio|first = Katia|title = Atletas olímpicos brasileiros|publisher = Editora SESI|date = 2015-11-05|page = 439|language = pt|url = https://books.google.com.eg/books?id=An0UDAAAQBAJ&printsec=frontcover#v=onepage&q=%2218%20de%20dezembro%20de%201917%22&f=false|isbn = 8582055803}}</ref>',
        ], $parser->extractDate('{{death date and age|1996|11|27|1917|12|18|df=yes}}<ref name="Olimpianos">{{cite book|last = Rubio|first = Katia|title = Atletas olímpicos brasileiros|publisher = Editora SESI|date = 2015-11-05|page = 439|language = pt|url = https://books.google.com.eg/books?id=An0UDAAAQBAJ&printsec=frontcover#v=onepage&q=%2218%20de%20dezembro%20de%201917%22&f=false|isbn = 8582055803}}</ref>'));

        $this->assertEquals([
            'date' => "2003-09-27",
            'key' => '09-27',
            'year' => 2003,
            'month' => 9,
            'day' => 27,
            'original' => '{{death date and age|2003|9|27|1917|4|25|df=y}}',
        ], $parser->extractDate('{{nowrap|{{death date and age|2003|9|27|1917|4|25|df=y}}}}'));

        $this->assertEquals([
            'date' => "1994-11-12",
            'key' => '11-12',
            'year' => 1994,
            'month' => 11,
            'day' => 12,
            'original' => '{{death date and age|1994|11|12|1918|06|8}}<br>[[Port Washington, New York]]',
        ], $parser->extractDate('{{death date and age|1994|11|12|1918|06|8}}<br>[[Port Washington, New York]]'));

        $this->assertEquals([
            'date' => "1997-09-01",
            'key' => '09-01',
            'year' => 1997,
            'month' => 9,
            'day' => 01,
            'original' => '{{dob|1997|9|01}}',
        ], $parser->extractDate('September 1997 (aged 78)'));

        $this->assertEquals([
            'date' => "1994-05-30",
            'key' => '05-30',
            'year' => 1994,
            'month' => 5,
            'day' => 30,
            'original' => '{{dob|1994|5|30}}',
        ], $parser->extractDate(' 30 May 1994'));

        $this->assertEquals([
            'date' => '1932-04-04',
            'key' => '04-04',
            'year' => 1932,
            'month' => 4,
            'day' => 4,
            'original' => '{{Birth date|df=yes|1932|4|4}}',
        ], $parser->extractDate('{{Birth date|df=yes|1932|4|4}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{Birth date|1993|2|24|df=yes}}',
        ], $parser->extractDate('{{Birth date|1993|2|24|df=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{birth date|1993|2|24|df=yes}}',
        ], $parser->extractDate('{{birth date|1993|2|24|df=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{Birth date and age|1993|2|24|df=yes}}',
        ], $parser->extractDate('{{Birth date and age|1993|2|24|df=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{Birth date|1993|2|24|mf=yes}}',
        ], $parser->extractDate('{{Birth date|1993|2|24|mf=yes}}'));

        $this->assertEquals(null, $parser->extractDate('{{Birth date|1993|29|29|df=yes}}'));
        $this->assertEquals(null, $parser->extractDate('{{Birth date|1993|df=yes}}'));

        $this->assertEquals([
            'date' => '540-07-01',
            'key' => '07-01',
            'year' => 540,
            'month' => 7,
            'day' => 1,
            'original' => '{{Birth date|540|7|1|mf=yes}}',
        ], $parser->extractDate('{{Birth date|540|7|1|mf=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{Bda|1993|2|24|mf=yes}}',
        ], $parser->extractDate('{{Bda|1993|2|24|mf=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{bda|1993|2|24|mf=yes}}',
        ], $parser->extractDate('{{bda|1993|2|24|mf=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{Dob|1993|2|24|mf=yes}}',
        ], $parser->extractDate('{{Dob|1993|2|24|mf=yes}}'));

        $this->assertEquals([
            'date' => '1993-02-24',
            'key' => '02-24',
            'year' => 1993,
            'month' => 2,
            'day' => 24,
            'original' => '{{dob|1993|2|24|mf=yes}}',
        ], $parser->extractDate('{{dob|1993|2|24|mf=yes}}'));

        $this->assertEquals([
            'date' => '2017-07-28',
            'key' => '07-28',
            'year' => 2017,
            'month' => 7,
            'day' => 28,
            'original' => '{{death date|df=yes|2017|7|28}} (aged {{age for infant|2016|8|4|2017|7|28}})',
        ], $parser->extractDate('{{death date|df=yes|2017|7|28}} (aged {{age for infant|2016|8|4|2017|7|28}})'));

    }

}