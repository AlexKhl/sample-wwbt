<?php

require_once __DIR__ . "/../../../vendor/autoload.php";

class FullTextExtrTest extends \diplux\tests\DipluxTestCase
{
    public function testXtParser()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            'Albert Hofmann (11 January 1906 – 29 April 2008) Hofmann also became interested in the seeds of the Mexican morning glory species Turbina corymbosa, the seeds of which are called ololiuhqui by the natives. He was surprised to find the active compound of ololiuhqui, ergine (LSA, lysergic acid amide), to be closely related to LSD.

In 1962, he and his wife Anita Hofmann (née Guanella, sister of Gustav Guanella, an important Swiss inventor) traveled to southern Mexico to search for the plant "Ska Maria Pastora" (Leaves of Mary the Shepherdess), later known as Salvia divinorum. He was able to obtain samples of this plant, but never succeeded in identifying its active compound, which has since been identified as the diterpenoid salvinorin A. In 1963, Hofmann attended the annual convention of the World Academy of Arts and Sciences (WAAS) in Stockholm.

===Later years===



Hofmann, interviewed shortly before his hundredth birthday, called LSD "medicine for the soul" and was frustrated by the worldwide prohibition of it. "It was used very successfully for ten years in psychoanalysis," he said, adding that the drug was misused by the Counterculture of the 1960s, and then criticized unfairly by the political establishment of the day. He conceded that it could be dangerous if misused, because a relatively high dose of 500 micrograms will have an extremely powerful psychoactive effect, especially if administered to a first-time user without adequate supervision.

In December 2007, Swiss medical authorities permitted psychotherapist Peter Gasser to perform psychotherapeutic experiments with patients who suffer from terminal-stage cancer and other deadly diseases. Completed in 2011, these experiments represent the first study of the therapeutic effects of LSD on humans in 35 years, as other studies have focused on the drug\'s effects on consciousness and body. Hofmann acclaimed the study, and continued to say he believed in the therapeutic benefits of LSD. In 2008, Hofmann wrote to Steve Jobs, asking him to support this research; it is not known if Jobs responded. The Multidisciplinary Association of Psychedelic Studies (MAPS) has supported research in the field of psychoanalysis using LSD, carrying on Hofmann\'s legacy and setting the groundwork for future studies.

Hofmann was due to speak at the World Psychedelic Forum from 21 to 24 March 2008 but was forced to cancel because of bad health.

James Fadiman confirmed that Hofmann was microdosing LSD for at least the last two decades of his life. 

Hofmann was also a long-time friend and correspondent of German author and entomologist Ernst Jünger, whom he met in 1949. Jünger experimented with LSD with Hofmann; in 1970, Jünger published a book of his experiences taking several types of drugs, Annäherungen. Drogen und Rausch (Approaches: Drugs and Intoxication).

=== Disposition of Hofmann\'s papers ===
After retiring from Sandoz in 1971, Hofmann was allowed to take his papers and research home. He gave his archives to the Albert Hofmann Foundation, a Los Angeles-based nonprofit, but the documents mostly sat in storage for years. The archives were sent to the San Francisco area in 2002 to be digitized, but that process was never completed. In 2013, the archives were sent to the Institute of Medical History in Bern, Switzerland, where they are currently being organized.

==Death==
Hofmann died of a heart attack on 29 April 2008, surrounded by several grandchildren and great-grandchildren. He and his wife, Anita, who died in 2007, raised four children.

==Honors and awards==
The Swiss Federal Institute of Technology (ETH Zurich) honored him with the title D.Sc. (honoris causa) in 1969 together with Gustav Guanella, his brother-in-law. In 1971 the Swedish Pharmaceutical Association (Sveriges Farmacevtförbund) granted him the Scheele Award, which commemorates the skills and achievements of the Swedish Pomeranian chemist and pharmacist Carl Wilhelm Scheele.

==See also==
Lysergic acid diethylamide
History of lysergic acid diethylamide
Psychedelic therapy
Timothy Leary
Owsley Stanley
Drug design
Alexander Shulgin
James Fadiman

== References ==


== Further reading ==
Horowitz, Michael. "Interview with Albert Hofmann", High Times (1976)
Nathaniel S. Finney, Jay S. Siegel: In Memoriam – Albert Hofmann (1906–2008). Chimia 62 (2008), 444–447, 
Roberts, Andy. Albion Dreaming: A Popular History of LSD in Britain (2008), Marshall Cavendish, U.K, 978-1905736270/1905736274
Hagenbach, Dieter and Lucius Werthmüller. Mystic Chemist: The Life of Albert Hofmann and His Discovery of LSD (Synergetic Press, 2013). 

== External links ==


*Albert Hofmann Foundation
*LSD: My Problem Child Career Autobiography
*Insight Outlook A book by Albert Hofmann
*Erowid: Albert Hofmann Vault
*Maps.org ("Stanislav Grof interviews Dr. Albert Hofmann")
*Albert Hofmann – Daily Telegraph obituary
*Watch Hofmann\'s Potion, a documentary on the origins of LSD
*Albert Hofmann\'s life and articles 
*LSD Returns—For Psychotherapeutics (Scientific American Magazine article)
*Albert Hofmann and Visionary Mushrooms – includes hand-written molecular structures of LSD and psilocybin by Dr. Hofmann




Category:1906 births
Category:2008 deaths
Category:Swiss chemists
Category:People associated with the University of Zurich
Category:University of Zurich alumni
Category:Psychedelic drug researchers
Category:Psychedelic drug advocates
Category:Drug policy reform activists
Category:Lysergic acid diethylamide
Category:Swiss centenarians
Category:Counterculture of the 1960s',
            $parser->XtractText("{{Use dmy dates|date=November 2016}}
{{Distinguish|Abbie Hoffman}}
{{pp-move-vandalism|small=yes}}
{{Infobox scientist
| name = Albert Hofmann
| image = Albert Hofmann Oct 1993.jpg
| image_size = 
| caption = Albert Hofmann in 1993
| birth_date = {{birth date|1906|1|11|df=y}}
| birth_place = [[Baden, Switzerland]]
| death_date = {{death date and age|2008|4|29|1906|1|11|df=y}}
| death_place = [[Burg im Leimental|Burg im Leimental, Switzerland]]
| residence = [[Switzerland]]
| nationality = [[Switzerland|Swiss]]
| field = [[Chemistry]]
| erdos_number = 
| work_institution = 
| alma_mater = [[University of Zürich]]
| doctoral_advisor = 
| doctoral_students = 
| known_for  = Discovery of [[LSD-25]]
| societies = 
| prizes = 
}}
{{Psychedelic sidebar}}
'''Albert Hofmann''' (11 January 1906 – 29 April 2008)<ref name=\"maps\">{{cite web
 | url = http://www.maps.org/
 | title = Albert Hofmannf | publisher = Multidisciplinary Association for Psychedelic Studies
 | accessdate = 29 April 2008
| archiveurl= https://web.archive.org/web/20080430081104/http://maps.org/| archivedate= 30 April 2008 | deadurl= no}}</ref><ref name=telegraphobit>{{cite news|url=http://www.telegraph.co.uk/news/obituaries/1912485/Albert-Hofmann,-LSD-inventor,-dies.html |title=Obituary: Albert Hofmann, LSD inventor |publisher=Daily Telegraph |accessdate=29 April 2008 |location=London |date=29 April 2008 |archiveurl=https://web.archive.org/web/20080501042140/http://www.telegraph.co.uk/news/obituaries/1912485/Albert-Hofmann%2C-LSD-inventor%2C-dies.html |archivedate=1 May 2008 |deadurl=no }}</ref> was a [[Switzerland|Swiss]] scientist known best for being the first person to [[Chemical synthesis|synthesize]], [[ingestion|ingest]], and learn of the [[Psychedelic drug|psychedelic effects]] of [[lysergic acid diethylamide]] (LSD). Hofmann was also the first person to isolate, synthesize, and name the principal [[psychedelic mushroom]] compounds [[psilocybin]] and [[psilocin]].<ref>Hofmann, A. \"Psilocybin und Psilocin, zwei psychotrope Wirkstoffe aus mexikanischen Rauschpilzen.\" Helvetica Chemica Acta 42: 1557–1572 (1959).</ref> He authored more than 100 scientific articles and numerous books, including ''LSD: Mein Sorgenkind'' (''LSD: My Problem Child'').<ref name=telegraphobit/> In 2007, he shared first place, alongside [[Tim Berners-Lee]], in a list of the 100 greatest living geniuses, published by ''The Telegraph'' newspaper.<ref>{{cite news| url=http://www.telegraph.co.uk/news/uknews/1567544/Top-100-living-geniuses.html | location=London | work=The Daily Telegraph | title=Top 100 living geniuses | date=30 October 2007}}</ref>

== Life and career ==

Hofmann was born in [[Baden, Switzerland]], the first of four children to factory toolmaker Adolf Hofmann and his wife Elisabeth (born Elisabeth Schenk). Owing to his father's low income, Albert's godfather paid for his education. When his father became ill, Hofmann obtained a position as a commercial apprentice in concurrence with his studies. At the age of twenty, Hofmann began his [[chemistry]] degree at the [[University of Zürich]], finishing three years later, in 1929. His main interest was the chemistry of plants and animals, and he later conducted important research on the chemical structure of the common animal substance [[chitin]], for which he received his [[doctorate]], with distinction, in the spring of 1929.<ref>{{cite book|title=Mystic Chemist: The Life of Albert Hofmann and His Discovery of LSD|year=2013|publisher=Synergetic Press|location=Santa Fe, NM|isbn=978-0-907791-46-1|page=16|author=Dieter Hagenbach|edition=First English|author2=Lucius Werthmüller|author3=Stanislav Grof|language=}}</ref>

Regarding his decision to pursue a career as a chemist, Hofmann provided insight during a speech he delivered to the 1996 Worlds of Consciousness Conference in Heidelberg, Germany:

{{quote|One often asks oneself what roles planning and chance play in the realization of the most important events in our lives. [...] This [career] decision was not easy for me. I had already taken a Latin matricular exam, and therefore a career in the humanities stood out most prominently in the foreground. Moreover, an artistic career was tempting. In the end, however, it was a problem of theoretical knowledge which induced me to study chemistry, which was a great surprise to all who knew me. Mystical experiences in childhood, in which Nature was altered in magical ways, had provoked questions concerning the essence of the external, material world, and chemistry was the scientific field which might afford insights into this.<ref>{{cite journal|last=Hoffman|first=Albert|author2=J. Ott|title=LSD: Completely Personal|journal=Newsletter of the Multidisciplinary Association for Psychedelic Studies|year=1996|volume=6|issue=3|url=http://www.maps.org/news-letters/v06n3/06346hof.html|accessdate=7 November 2013}}</ref> }}

=== Discovery of LSD ===
{{Main|History of LSD#Discovery|l1=Discovery of LSD}}

Hofmann became an employee of the pharmaceutical-chemical department of [[Sandoz]] Laboratories (now a subsidiary of [[Novartis]]), located in [[Basel]] as  a co-worker with professor [[Arthur Stoll]], founder and director of the pharmaceutical department.<ref name=\"flashback.se\">{{cite web|url=http://www.psychedelic-library.org/child1.htm |title=LSD, My Problem Child |publisher=psychedelic-library.org |date= |accessdate=16 November 2009}}</ref> He began studying the [[medicinal plant]] [[Drimia maritima|squill]] and the [[fungus]] [[ergot]] as part of a program to purify and synthesize active constituents for use as [[pharmaceuticals]]. His main contribution was to elucidate the chemical structure of the common nucleus of the ''[[Scilla]]'' [[glycoside]]s (an active principal of [[Drimia maritima|Mediterranean Squill]]).<ref name=\"flashback.se\"/> While researching [[lysergic acid]] derivatives, Hofmann first synthesized LSD on 16 November 1938.<ref>Dr. Albert Hofmann; translated from the original German (LSD Ganz Persönlich) by J. Ott. [http://www.maps.org/news-letters/v06n3/06346hof.html MAPS-Volume 6 Number 69 Summer 1969]</ref> The main intention of the synthesis was to obtain a respiratory and circulatory stimulant (an [[analeptic]]) with no effects on the [[uterus]] in analogy to [[nikethamide]] (which is also a diethylamide) by introducing this [[functional group]] to [[lysergic acid]]. 
It was set aside for five years, until 16 April 1943, when Hofmann decided to reexamine it. While re-synthesizing LSD, he accidentally touched his hand to his mouth, nose or possibly eye, ingesting a small amount<ref>{{cite news|url=http://news.bbc.co.uk/2/hi/europe/7374846.stm |title=LSD inventor Albert Hofmann dies |work=[[BBC News]] |date=30 April 2008}}</ref> and discovered its powerful effects. He described what he felt as being:

{{quote|... affected by a remarkable restlessness, combined with a slight dizziness. At home I lay down and sank into a not unpleasant intoxicated[-]like condition, characterized by an extremely stimulated imagination. In a dreamlike state, with eyes closed (I found the daylight to be unpleasantly glaring), I perceived an uninterrupted stream of fantastic pictures, extraordinary shapes with intense, kaleidoscopic play of colors. After some two hours this condition faded away.<ref>Hofmann 1980, p. 15</ref>}}

Three days later, on [[History of LSD#\"Bicycle Day\"|19 April 1943]], Hofmann intentionally ingested 250 micrograms of LSD.  This day is now known as \"Bicycle Day\", because he began to feel the effects of the drug as he rode home on a bike. This was the first intentional LSD trip.<ref>http://blog.oup.com/2013/04/bicycle-day-lsd-albert-hoffman/</ref>

Hofmann continued to take small doses of LSD throughout much of his life, and always hoped to find a use for it.  In his memoir, he emphasized it as a \"sacred drug\": \"I see the true importance of LSD in the possibility of providing material aid to meditation aimed at the mystical experience of a deeper, comprehensive reality.\"<ref name=\"Roberts\">{{cite journal|last1=Roberts|first1=Jacob|title=High Times|journal=Distillations |date=2017|volume=2|issue=4|pages=36–39|url=https://www.sciencehistory.org/distillations/magazine/high-times|accessdate=22 March 2018}}</ref>

=== Further research ===
{{Rquote|right|It gave me an inner joy, an open mindedness, a gratefulness, open eyes and an internal sensitivity for the miracles of creation. [...] I think that in human evolution it has never been as necessary to have this substance LSD. It is just a tool to turn us into what we are supposed to be.|Albert Hofmann|Speech on 100th birthday<ref>{{cite web |url=https://www.wired.com/science/discoveries/news/2006/01/70015?currentPage=2 |title=LSD: The Geek's Wonder Drug? |publisher=Wired.com |date=16 January 2006 |accessdate=29 April 2008}}</ref>}}

Hofmann, later, was to discover [[4-Acetoxy-DET]] (4-acetoxy-N,N-diethyltryptamine), also known as ethacetin, ethylacybin, or 4-AcO-DET, a [[hallucinogenic]] [[tryptamine]]. He first synthesized 4-AcO-DET in 1958 in the [[Sandoz]] lab. Hofmann became director of the natural products department at [[Sandoz]] and continued studying hallucinogenic substances found in Mexican [[mushroom]]s and other plants used by the aboriginal people there. This led to the synthesis of [[psilocybin]], the active agent of many \"[[Psychedelic mushroom|magic mushrooms]].\"<ref name=\"Bleidt\">{{cite book
  | last = Bleidt
  | first = Barry
  |author2= Michael Montagne
  | title = Clinical Research in Pharmaceutical Development
  | publisher = [[Informa|Informa Health Care]]
  | year = 1996
  | pages = 36, 42–43
  | isbn = 0-8247-9745-0
}}</ref> Hofmann also became interested in the seeds of the Mexican [[morning glory]] species ''[[Turbina corymbosa]]'', the seeds of which are called ''ololiuhqui'' by the natives. He was surprised to find the active compound of [[ololiuhqui]], [[ergine]] (LSA, lysergic acid amide), to be closely related to LSD.

In 1962, he and his wife Anita Hofmann (née Guanella, sister of [[Gustav Guanella]], an important Swiss inventor) traveled to southern [[Mexico]] to search for the plant \"Ska Maria Pastora\" (Leaves of Mary the Shepherdess), later known as ''[[Salvia divinorum]]''. He was able to obtain samples of this plant, but never succeeded in identifying its active compound, which has since been identified as the [[diterpenoid]] [[salvinorin A]]. In 1963, Hofmann attended the annual convention of the [[World Academy of Arts and Sciences]] (WAAS) in [[Stockholm]].

===Later years===

[[Image:Albert Hofmann.jpg|thumb|Albert Hofmann in 2006]]

Hofmann, interviewed shortly before his hundredth birthday, called LSD \"medicine for the soul\" and was frustrated by the worldwide prohibition of it. \"It was used very successfully for ten years in psychoanalysis,\" he said, adding that the drug was misused by the [[Counterculture of the 1960s]], and then criticized unfairly by the political establishment of the day. He conceded that it could be dangerous if misused, because a relatively high dose of 500 micrograms will have an extremely powerful psychoactive effect, especially if administered to a first-time user without adequate supervision.<ref>{{cite news|url=https://www.nytimes.com/2006/01/07/international/europe/07hoffman.html|title=New York Times article | work=The New York Times | first=Craig S. | last=Smith | date=7 January 2006}}</ref>

In December 2007, Swiss medical authorities permitted psychotherapist Peter Gasser to perform psychotherapeutic experiments with patients who suffer from terminal-stage cancer and other deadly diseases. Completed in 2011, these experiments represent the first study of the therapeutic effects of LSD on humans in 35 years, as other studies have focused on the drug's effects on consciousness and body.<ref>{{cite news|url=http://www.maps.org/research/psilo-lsd/|title=LSD-Assisted Psychotherapy for Anxiety | work=Multidisciplinary Association for Psychedelic Studies | date=21 October 2011}}</ref> Hofmann acclaimed the study, and continued to say he believed in the therapeutic benefits of LSD.<ref>{{cite web|url=http://www.swissinfo.ch/ger/wissen_und_technik/detail/Das_Comeback_von_LSD.html?siteSect=511&sid=8883306&cKey=1206100275000&ty=st|title=The comeback of LSD – swissinfo.ch}}</ref> In 2008, Hofmann wrote to [[Steve Jobs]], asking him to support this research; it is not known if Jobs responded.<ref>{{cite web|last=Weldon|first=Carolyne|title=Meet the Lab Coat-Clad Granddaddies of LSD|url=http://blog.nfb.ca/2012/08/10/hofmanns-potion-lsd/|work=NFB.ca blog|publisher=[[National Film Board of Canada]]|accessdate=17 August 2012|date=17 August 2012}}</ref>  The Multidisciplinary Association of Psychedelic Studies (MAPS) has supported research in the field of psychoanalysis using LSD, carrying on Hofmann's legacy and setting the groundwork for future studies.<ref>{{cite news|url=http://www.maps.org/research/psilo-lsd/|title=LSD-Assisted Psychotherapy for Anxiety | work=Multidisciplinary Association for Psychedelic Studies | date=7 September 2011}}</ref>

Hofmann was due to speak at the World Psychedelic Forum<ref>{{cite web|url=http://www.psychedelic.info/content_eng/wpf_eng_speakers.html|title=World Psychedelic Forum}}</ref> from 21 to 24 March 2008 but was forced to cancel because of bad health.

James Fadiman confirmed that Hofmann was [[Psychedelic microdosing|microdosing]] LSD for at least the last two decades of his life. <ref>{{cite web|url=https://www.youtube.com/watch?v=JBgKRyRCVFM|title=Microdosing - The Phenomenon, Research Results & Startling Surprises|work=Psychedelic Science 2017|date= 26 April 2017}}</ref>

Hofmann was also a long-time friend and correspondent of German author and entomologist [[Ernst Jünger]], whom he met in 1949. Jünger experimented with LSD with Hofmann; in 1970, Jünger published a book of his experiences taking several types of drugs, ''Annäherungen. Drogen und Rausch'' (''Approaches: Drugs and Intoxication'').

=== Disposition of Hofmann's papers ===
After retiring from Sandoz in 1971, Hofmann was allowed to take his papers and research home. He gave his archives to the Albert Hofmann Foundation, a Los Angeles-based nonprofit, but the documents mostly sat in storage for years. The archives were sent to the San Francisco area in 2002 to be digitized, but that process was never completed. In 2013, the archives were sent to the Institute of Medical History in Bern, Switzerland, where they are currently being organized.<ref>{{Cite news|title = LSD Archive Has Been on a Long, Strange Trip|url = https://www.wsj.com/articles/lsd-archive-has-been-on-a-long-strange-trip-1445215001|newspaper = Wall Street Journal|access-date = 20 October 2015|issn = 0099-9660|first = John|last = Letzing}}</ref>

==Death==
Hofmann died of a heart attack on 29 April 2008, surrounded by several grandchildren and great-grandchildren. He and his wife, Anita, who died in 2007, raised four children.<ref>{{cite news|title=Albert Hofmann, the Father of LSD, Dies at 102|url=https://www.nytimes.com/2008/04/30/world/europe/30hofmann.html?_r=1&|accessdate=2 May 2013|newspaper=The New York Times|date=30 April 2008|author=Craig S Smith}}</ref>

==Honors and awards==
The ''Swiss Federal Institute of Technology'' ([[ETH Zurich]]) honored him with the title D.Sc. (honoris causa) in 1969 together with [[Gustav Guanella]], his brother-in-law. In 1971 the [[Swedish Confederation of Professional Associations|Swedish Pharmaceutical Association]] (''Sveriges Farmacevtförbund'') granted him the [[Scheele Award]], which commemorates the skills and achievements of the [[Swedish Pomerania]]n chemist and pharmacist Carl Wilhelm Scheele.<ref>{{cite web|title=The Scheele Award|url=http://www.swepharm.se/upload/1049/Scheele.pdf|work=The Scheele Award|publisher=Swedish Academy of Pharmaceutical Sciences|accessdate=15 December 2013|year=2005}}</ref>

==See also==
* [[Lysergic acid diethylamide]]
* [[History of lysergic acid diethylamide]]
* [[Psychedelic therapy]]
* [[Timothy Leary]]
* [[Owsley Stanley]]
* [[Drug design]]
* [[Alexander Shulgin]]
* [[James Fadiman]]

== References ==
{{reflist|30em}}

== Further reading ==
* Horowitz, Michael. [http://www.erowid.org/culture/characters/hofmann_albert/hofmann_albert_interview1.shtml \"Interview with Albert Hofmann\"], ''High Times'' (1976)
* Nathaniel S. Finney, Jay S. Siegel: ''In Memoriam'' – Albert Hofmann (1906–2008). [[Chimia]] 62 (2008), 444–447, {{doi|10.2533/chimia.2008.444}}
* Roberts, Andy. ''Albion Dreaming: A Popular History of LSD in Britain'' (2008), Marshall Cavendish, U.K,  978-1905736270/1905736274
* Hagenbach, Dieter and Lucius Werthmüller. ''Mystic Chemist: The Life of Albert Hofmann and His Discovery of LSD'' (Synergetic Press, 2013). {{ISBN|978-090779146-1}}

== External links ==
{{Commons}}
{{Wikiquote}}
*[http://www.hofmann.org/ Albert Hofmann Foundation]
*[http://www.lycaeum.org/books/books/my_problem_child/ ''LSD: My Problem Child''] Career Autobiography
*[http://www.plutocracycaust.org/ah-en.html ''Insight Outlook'' ] A book by Albert Hofmann
*[http://www.erowid.org/characters/hofmann_albert/ Erowid: Albert Hofmann Vault]
*[http://www.maps.org/news-letters/v11n2/11222gro.html Maps.org] (\"Stanislav Grof interviews Dr. Albert Hofmann\")
*[http://www.telegraph.co.uk/news/obituaries/1912485/Obituary-Albert-Hofmann-LSD-inventor.html Albert Hofmann] – Daily Telegraph obituary
*[http://www.nfb.ca/film/hofmanns_potion Watch ''Hofmann's Potion'', a documentary on the origins of LSD]
*[http://www.cannabismagazine.es/digital/busqueda-avanzada?searchword=obra+de+albert&ordering=&searchphrase=exact Albert Hofmann's life and articles] {{es icon}}
*[http://www.scientificamerican.com/article.cfm?id=return-of-a-problem-child LSD Returns—For Psychotherapeutics (Scientific American Magazine article)]
*[http://www.stainblue.com/ah.html Albert Hofmann and Visionary Mushrooms – includes hand-written molecular structures of LSD and psilocybin by Dr. Hofmann]

{{Authority control}}

{{DEFAULTSORT:Hofmann, Albert}}
[[Category:1906 births]]
[[Category:2008 deaths]]
[[Category:Swiss chemists]]
[[Category:People associated with the University of Zurich]]
[[Category:University of Zurich alumni]]
[[Category:Psychedelic drug researchers]]
[[Category:Psychedelic drug advocates]]
[[Category:Drug policy reform activists]]
[[Category:Lysergic acid diethylamide]]
[[Category:Swiss centenarians]]
[[Category:Counterculture of the 1960s]]
")
        );

        $this->assertEquals(
            'Roger II (22 December 1095 – 26 February 1154) was King of Sicily, son of Roger I of Sicily and successor to his brother Simon. He began his rule as Count of Sicily in 1105, became Duke of Apulia and Calabria in 1127, and then King of Sicily in 1130. By the time of his death at the age of 58, Roger had succeeded in uniting all the Norman conquests in Italy into one kingdom with a strong centralized government.

==Background==


By 999, Norman adventurers had arrived in southern Italy. By 1016, they were involved in the complex local politics where Lombards were fighting against the Byzantine Empire. As mercenaries they fought the enemies of the Italian city-states sometimes fighting for the Byzantines and sometimes against them, but in the following century they gradually became the rulers of the major polities south of Rome.

Roger I ruled the County of Sicily at the time of the birth of his youngest son, Roger, at Mileto, Calabria, in 1095. Roger I\'s nephew, Roger Borsa, was the Duke of Apulia and Calabria, and his great nephew, Richard II of Capua, was the Prince of Capua. Alongside these three major rulers were a large number of minor counts, who effectively exercised sovereign power in their own localities. These counts at least nominally owed allegiance to one of these three Norman rulers, but such allegiance was usually weak and often ignored.

When Roger I died in 1101, his young son, Simon of Hauteville, became Count, with his mother Adelaide del Vasto as regent. Simon died four years later in 1105, at the age of 12. Adelaide continued as regent to her younger son Roger, who was just nine years old.

==Reign==

===Rise to power in Sicily===
 at the time of Roger\'s death in 1154 is indicated by a thicker black line encircling most of southern Italy.]]

Upon the death of his elder brother, Simon of Hauteville, in 1105, Roger inherited the County of Sicily under the regency of his mother, Adelaide del Vasto. His mother was assisted by such notables as Christodulus, the Greek emir of Palermo. In 1109, Byzantine Emperor Alexios I Komnenos, bestowed upon him the title of protonobilissimos, in recognition of his knowledge of the Byzantine court. In the summer of 1110, Roger was visited by the Norwegian king Sigurd Jorsalfare, who was on his way to Jerusalem. The story suggests that Sigurd gave Roger the name King of Sicily, twenty years before he actually obtained this title.

In 1112, at the age of sixteen, Roger began his personal rule, being named "now knight, now Count of Sicily and Calabria" in a charter document dated 12 June 1112. Roger married his first wife, Elvira, daughter of Alfonso VI of Castile, and his fourth queen, Isabella, who may be identical to his former concubine, the converted Moor, Zaida, baptised Isabella.

In 1122, William II the Duke of Apulia, who was fighting with Count Jordan of Ariano, offered to renounce his remaining claims to Sicily as well as part of Calabria. Roger, in exchange, provided William with 600 knights and access to money for his campaign.

===Rise to power in southern Italy===
When William II of Apulia died childless in July 1127, Roger claimed all Hauteville family possessions in the peninsula as well as the overlordship of the Principality of Capua, which had been nominally given to Apulia almost thirty years earlier. However, the union of Sicily and Apulia was resisted by Pope Honorius II and by the subjects of the duchy itself.

====Royal investiture====
 date of 528 (1133–34).]]

The popes had long been suspicious of the growth of Norman power in southern Italy, and at Capua in December, the pope preached a crusade against Roger, setting Robert II of Capua and Ranulf II of Alife (his own brother-in-law) against him. After this coalition failed, in August 1128 Honorius invested Roger at Benevento as Duke of Apulia. The baronial resistance, backed by Naples, Bari, Salerno, and other cities whose aim was civic freedom, gave way. In September 1129 Roger was generally recognized as duke of Apulia by Sergius VII of Naples, Robert of Capua, and the rest. He began at once to enforce order in the duchy, where ducal power had long been fading.

On the death of Pope Honorius in February 1130 there were two claimants to the papal throne. Roger supported Antipope Anacletus II against Innocent II. He was crowned in Palermo on Christmas Day 1130. Roger II\'s elaborate royal mantle bears the date 528 of the Islamic calendar (1133–34), therefore it could not have been used for his coronation. It was later used as coronation cloak by the Holy Roman Emperors and is now in the Imperial Treasury (Schatzkammer) in Vienna.

====Peninsular rebellions====
This plunged Roger into a ten-year war. Bernard of Clairvaux, Innocent\'s champion, organized a coalition against Anacletus and his "half-heathen king." He was joined by Louis VI of France, Henry I of England, and Lothair III, Holy Roman Emperor. Meanwhile, southern Italy revolted.

In 1130, the Duchy of Amalfi revolted and in 1131, Roger sent John of Palermo across the Strait of Messina to join up with a royal troop from Apulia and Calabria and march on Amalfi by land while George of Antioch blockaded the town by sea and set up a base on Capri. Amalfi soon capitulated.

In 1132, Roger sent Robert II of Capua and Ranulf II of Alife to Rome in a show of force in support of Anacletus. While they were away, Roger\'s half-sister Matilda, Ranulf\'s wife, fled to Roger claiming abuse. Simultaneously, Roger annexed Ranulf\'s brother\'s County of Avellino. Ranulf demanded the restitution of both wife and countship. Both were denied, and Ranulf left Rome against orders, with Robert following.

 riding to war, from Liber ad honorem Augusti of Petrus de Ebulo, 1196.]]
First Roger dealt with a rebellion in Apulia, where he defeated and deposed Grimoald, Prince of Bari, replacing him with his second son Tancred. Meanwhile, Robert and Ranulf took papal Benevento. Roger went to meet them but was defeated at the Battle of Nocera on 25 July 1132. Roger retreated to Salerno.

The next year, Lothair III came down to Rome for his imperial coronation. The rebel leaders met him there, but they were refused help because Lothair\'s force was too small. With the emperor\'s departure, divisions in his opponents\' ranks allowed Roger to reverse his fortunes. By July 1134, Roger\'s troops had forced Ranulf, Sergius, and the other ringleaders to submit. Robert was expelled from Capua and Roger installed his third son, Alfonso of Hauteville as Prince of Capua. Roger II\'s eldest son Roger was given the title of Duke of Apulia.

Meanwhile, Lothair\'s contemplated attack upon Roger had gained the backing of Pisa, Genoa, and the Byzantine emperor John II, each of whom feared the growth of a powerful Norman kingdom. A Pisan fleet led by the exiled prince of Capua dropped anchor off Naples in 1135. Ranulf joined Robert and Sergius there, encouraged by news coming from Sicily that Roger was fatally ill or even already dead. The important fortress of Aversa, among others, passed to the rebels and only Capua resisted, under the royal chancellor, Guarin. On June 5, however, Roger disembarked in Salerno, much to the surprise of all the mainland provinces. The royal army, split into several forces, easily conquered Aversa and even Alife, the base of the natural rebel leader, Ranulf. Most of the rebels took refuge in Naples, which was besieged in July, but despite poor health conditions within the city, Roger was not able to take it, and returned to Messina late in the year.

====Imperial invasion====
, an ancient world map drawn by Muhammad al-Idrisi for Roger II of Sicily in 1154. The north is at the bottom, and so the map appears "upside down" compared to modern cartographic conventions.]]
In 1136, the long-awaited imperial army, led by Lothair and the duke of Bavaria, Henry the Proud, descended the peninsula to support the three rebels. Henry, Robert, and Ranulf took a large contingent of troops to besiege the peninsular capital of the kingdom, Salerno. Roger remained in Sicily, leaving its mainland garrisons helpless under the chancellor Robert of Selby, while even the Byzantine emperor John II Comnenus sent subsidies to Lothair. Salerno surrendered, and the large army of Germans and Normans marched to the very south of Apulia. There, in June 1137, Lothair besieged and took Bari. At San Severino, after the victorious campaign, he and the pope jointly invested Ranulf as duke of Apulia in August 1137, and the emperor then retired to Germany. Roger, freed from the utmost danger, immediately disembarked in Calabria, at Tropea, with 400 knights and other troops, probably mostly Muslims. After having been welcomed by the Salernitans, he recovered ground in Campania, sacking Pozzuoli, Alife, Capua, and Avellino. Sergius was forced to acknowledge him as overlord of Naples and switch his allegiance to Anacletus. This moment marked the fall of an independent Neapolitan duchy, and thereafter the ancient city was fully integrated into the Norman realm.

From there Roger moved to Benevento and northern Apulia, where Duke Ranulf, although steadily losing his bases of power, had some German troops plus some 1,500 knights from the cities of Melfi, Trani, Troia, and Bari, who were "ready to die rather than lead a miserable life." On 30 October 1137, at the Battle of Rignano (next to Monte Gargano), the younger Roger and his father, with Sergius of Naples, met the defensive army of Duke Ranulf. It was the greatest defeat of Roger II\'s career. Sergius died and Roger fled to Salerno. It capped Ranulf\'s meteoric career: twice victor over Roger. Anacletus II died in January 1138, but Innocent II refused to reconcile with the King.

In spring 1138, the royal army invaded the Principality of Capua, with the precise intent of avoiding a pitched battle and of dispersing Ranulf\'s army with a series of marches through difficult terrain. While the count of Alife hesitated, Roger, now supported by Benevento, destroyed all the rebels\' castles in the region, capturing an immense booty. Ranulf himself, who had taken refuge in his capital Troia, died of malarial fever on 30 April 1139. Later, Roger exhumed his body from his grave in Troia cathedral and threw it in a ditch, only to repent subsequently and rebury him decently.

At this time, with Sergius dead, Alfonso was elected to replace him and together with his brother Roger went off to conquer the Abruzzi.

====Consolidation of kingship====
 Ducalis, dated year 10 (1140), after the king\'s victory on July 25. Obverse: Christ. Reverse: King Roger and Duke Roger.]]

After the death of Anacletus in January 1138, Roger had sought the confirmation of his title from Innocent. However, the pope wanted an independent Principality of Capua as a buffer state between the Kingdom of Sicily and the Papal States, something Roger would not accept. In the summer of 1139, Innocent II invaded the kingdom with a large army, but was ambushed at Galluccio on 22 July 1139, southeast of present-day Cassino, by Roger\'s son and was captured. Three days later, by the Treaty of Mignano, the pope proclaimed Roger II rex Siciliae ducatus Apuliae et principatus Capuae (king of Sicily, duke of Apulia and commander of Capua). The boundaries of his regno were only later fixed by a truce with the pope in October 1144. These lands were for the next seven centuries to constitute the kingdoms of Naples and Sicily.

In 1139, Bari, the 50,000 inhabitants of which had remained unscathed behind its massive walls during the wars of the past year, decided to surrender. The excellentissimus princeps Jaquintus, who had led the rebellion of the city, was hanged, along with many of his followers, but the city avoided being sacked. Roger\'s execution of the prince and his counsellors was perhaps the most violent act of his life.

While his sons overcame pockets of resistance on the mainland, on 5 November 1139 Roger returned to Palermo to plan a great act of legislation: the Assizes of Ariano, an attempt to establish his dominions in southern Italy as a coherent state. He returned to check on his sons\' progress in 1140 and then went to Ariano, a town central to the peninsular possessions (and a centre of rebellion under his predecessors). There he promulgated the great law regulating all Sicilian affairs. It invested the king and his bureaucracy with absolute powers and reduced the authority of the often rebellious vassals. While there, centralising his kingdom, Roger declared a new standard coinage, named after the duchy of Apulia: the ducat.

===Economy===

Roger’s reforms in laws and administration not only aimed to strengthen his rule but also to improve the economic standing of Sicily and southern Italy. He was "very concerned to gain money, but hardly very prodigal in expending it."

In 1140 at his assembly at Ariano he introduced new coinage to make it easier to trade with the rest of the Mediterranean, as there were smaller denominations of the previous coins, to allow more accurate and efficient trading. However, although this new coinage made long distance trade easier it was very detrimental to local trade which spread "hatred throughout Italy." By the 1150s most of this coinage was no longer in use and soon after, it disappeared altogether.

Nevertheless, the controversy over the coinage did not hinder the Kingdom’s prosperity. Roger II had not only acquired large wealth through his royal patrimony but also through his military campaigns and their financial rewards. For example, gold and silver were gained through the campaigns in Apulia in 1133 and Greece in 1147.

Sicily\'s geographic situation at the centre of Mediterranean made it a brilliant location for trade with Europe, North Africa and the Middle East. Its primary export was durum wheat; others included foods like cheese and vine fruits. Unlike other states, Sicily also had a strong political and military standing so its merchants were supported and to some extent protected. This standing allowed for an increase in internal trade and a stronger market which led to noticeable developments in agriculture.

===Later reign===

, at Palermo, the most wonderful of Roger\'s churches, with Norman doors, Saracenic arches, Byzantine dome, and roof adorned with Arabic scripts, is perhaps the most striking product of the brilliant and mixed civilization over which the grandson of the Norman Trancred ruled" (from 1911 Encyclopædia Britannica).]]

Roger had now become one of the greatest kings in Europe. At Palermo, he gathered round him distinguished men of various races, such as the famous Arab geographer Muhammad al-Idrisi and the Byzantine Greek historian Nilus Doxopatrius. The king welcomed the learned and practised toleration towards the several creeds, races and languages of his realm. To administer his domain he hired many Greeks and Arabs, who were trained in long-established traditions of centralized government. He was served by men of diverse nationality, such as the Englishman Thomas Brun, a kaid of the Curia and, in the fleet by two Greeks, first Christodulus and then George of Antioch, whom he made in 1132 ammiratus ammiratorum or "Emir of Emirs", in effect prime vizier. (This title later became the English word admiral). Roger made Sicily the leading maritime power in the Mediterranean.



A powerful fleet was built up under several admirals, or "emirs", of whom the greatest was George, formerly in the service of the Muslim prince of Mahdia. Mainly thanks to him, a series of conquests were made on the African coast (1146–1153). From 1135 Roger II started to conquer the coast of Tunisia and enlarge his dominions: Tripoli was captured in 1146 and Cape Bona in 1148. These conquests were lost in the reign of Roger\'s successor William, however, and never formed an integral part of the kingdom in southern Italy.

The Second Crusade (1147–1148) offered Roger an opportunity to revive attacks on the Byzantine Empire, the traditional Norman enemy to the East. It also afforded him an opportunity, through the agency of Theodwin, a cardinal ever-vigilant for Crusade supporters, to strike up a correspondence with Conrad III of Germany in an effort to break his alliance with Manuel I Comnenus. Roger himself never went on an expedition against Byzantium, instead handing command to the skillful George. In 1147, George set sail from Otranto with seventy galleys to attack Corfu. According to Nicetas Choniates, the island capitulated thanks to George\'s bribes (and the tax burden of the imperial government), welcoming the Normans as their liberators. Leaving a garrison of 1,000 men, George sailed on to the Peloponnesus. He sacked Athens and quickly moved on to the Aegean Islands. He ravaged the coast all along Euboea and the Gulf of Corinth and penetrated as far as Thebes, Greece, where he pillaged the silk factories and carried off the Jewish damask, brocade, and silk weavers, taking them back to Palermo where they formed the basis for the Sicilian silk industry. George capped the expedition with a sack of Corinth, in which the relics of Saint Theodore were stolen, and then returned to Sicily. In 1149, however, Corfu was retaken. George went on a punitive expedition against Constantinople, but could not land and instead defied the Byzantine emperor by firing arrows against the palace windows. Despite this act, his expedition left no enduring effects.

Roger died at Palermo on 26 February 1154 and was buried in the Cathedral of Palermo. He was succeeded by his fourth son, William.

Roger is the subject of King Roger, a 1926 opera by Polish composer Karol Szymanowski. The last months of his life are also featured in Tariq Ali\'s book A Sultan in Palermo. Studiorum Universitas Ruggero II, a private non-traditional university connected to Accademia Normanna was incorporated in the U.S. on April 30, 2001 in honor of this king.

==Family==

Roger\'s first marriage was in 1117 to Elvira, a daughter of King Alfonso VI of Castile. When she died, rumors flew that Roger had died as well, as his grief had made him a recluse. They had six children:

Roger (b. 1118 – d. 12 May 1148), heir, Duke of Apulia (from 1135), possibly also Count of Lecce;
Tancred (b. 1119 – d. 1138), Prince of Bari (from 1135).
Alfonso (b. 1120/1121 – d. 10 October 1144), Prince of Capua (from 1135) and Duke of Naples;
A daughter (d. young in 1135);
William (b. 1131 – d. 7 May 1166), his successor, Duke of Apulia (from 1148)
Henry (b. 1135 – d. young).

Roger\'s second marriage was in 1149 to Sibylla, daughter of Hugh II, Duke of Burgundy. They had two children:

Henry (b. 29 August 1149 – d. young);
Stillborn child (16 September 1150).

Roger\'s third marriage was in 1151 to Beatrice of Rethel, a grandniece of King Baldwin II of Jerusalem. They had one daughter:

*Constance (b. posthumously, 2 November 1154 – d. 28 November 1198),

Roger also had five known illegitimate children:

—By a daughter of Hugues I, Count of Molise:
Simon, who became Prince of Taranto in 1144.

—With unknown mistresses:
A daughter, wife of Rodrigo Garcés (later Henry, Count of Montescaglioso)
A daughter, wife of the neapolitan nobleman Adam;
Clenenza, married Hugues II, Count of Molise;
Adelisa (d. aft. 1184/87) married firstly Joscelin, Count of Loreto, and secondly Robert of Bassonville, Count of Loritello;
Marina, married the great admiral Margaritus of Brindisi.










 
Category:Roman Catholic monarchs
Category:Kings of Sicily
Category:Medieval child rulers
Category:1095 births
Category:1154 deaths
Category:Burials at Palermo Cathedral
Category:Christians of the Second Crusade
Category:Dukes of Apulia
Category:Hauteville family
Category:Italo-Normans
Category:Byzantine–Norman wars',
            $parser->XtractText("{{Redirect|Roger II|the Viscount of Carcassonne|Roger II Trencavel}}
{{Use dmy dates|date=August 2013}}
{{more footnotes|date=December 2012}}
{{expand Russian|topic=bio|Рожер II|date=July 2011}}

{{infobox royalty
| name         = Roger II
| succession   = [[King of Sicily#Kings of Sicily|King of Sicily]]
| image        = Martorana RogerII2008.jpg
| caption      = Detail of the [[mosaic]] with Roger II receiving the crown from Christ, [[Martorana]], [[Palermo]]. The mosaic carries an inscription ''Rogerios Rex'' in Greek letters.
| reign        = 27&nbsp;September 1130&nbsp;– <br />26&nbsp;February 1154
| coronation   = 25&nbsp;December 1130
| successor    = [[William I of Sicily|William I]]
| house        = [[House of Hauteville|Hauteville]]
| father       = [[Roger I of Sicily]]
| mother       = [[Adelaide del Vasto]]
| spouse       = [[Elvira of Castile, Queen of Sicily|Elvira of Castile]]<br />[[Sibylla of Burgundy]]<br />[[Beatrice of Rethel]]
| issue        = [[Roger III, Duke of Apulia]]<br>[[Tancred, Prince of Bari]]<br>[[Alfonso of Capua]]<br>[[William I of Sicily]]<br>[[Constance, Queen of Sicily]]<br>[[Simon, Prince of Taranto]]
| birth_date   = {{birth date|1095|12|22|df=yes}}
| birth_place  = [[Mileto]] ([[Calabria]])
| death_date   = {{death date and age|1154|2|26|1095|12|22|df=yes}}
| death_place  = [[Palermo]], [[Kingdom of Sicily]]
| burial_place = [[Cathedral of Palermo]], [[Sicily]]
}}

'''Roger II''' (22 December 1095<ref name=\"Houben, p. 30\">Houben, p. 30.</ref> – 26 February 1154) was King of [[Sicily]], son of [[Roger I of Sicily]] and successor to his brother [[Simon, Count of Sicily|Simon]]. He began his rule as [[Count of Sicily]] in 1105, became [[Duke of Apulia and Calabria]] in 1127, and then [[King of Sicily]] in 1130. By the time of his death at the age of 58, Roger had succeeded in uniting all the [[Italo-Normans|Norman]] conquests in Italy into one kingdom with a strong [[centralized government]].

==Background==
{{See also|Norman conquest of southern Italy}}

By 999, [[Normans|Norman]] adventurers had arrived in southern Italy.<ref>{{cite book|last=Barber|first=Malcolm|title=The Two Cities: Medieval Europe 1050-1320|year=2004|publisher=Routledge|isbn=0-415-17415-5|pages=209}}</ref> By 1016, they were involved in the complex local politics where Lombards were fighting against the [[Byzantine Empire]].  As mercenaries they fought the enemies of the Italian city-states sometimes fighting for the Byzantines and sometimes against them, but in the following century they gradually became the rulers of the major [[polity|polities]] south of Rome.

Roger I ruled the [[County of Sicily]] at the time of the birth of his youngest son, Roger, at [[Mileto]], [[Calabria]], in 1095.<ref>{{cite book|last=Houben|first=Hubert|title=Roger II of Sicily: a Ruler Between East and West|year=1997 (English translation 2002)|publisher=Cambridge University Press|isbn=0-521-65573-0|pages=xvii, Chronology}}</ref> Roger I's nephew, [[Roger Borsa]], was the [[List of Counts and Dukes of Apulia and Calabria|Duke of Apulia and Calabria]], and his great nephew, [[Richard II of Capua]], was the [[Principality of Capua|Prince of Capua]]. Alongside these three major rulers were a large number of minor [[count]]s, who effectively exercised sovereign power in their own localities.  These counts at least nominally owed allegiance to one of these three Norman rulers, but such allegiance was usually weak and often ignored.<ref>Matthew, p. 21.</ref>

When Roger I died in 1101, his young son, [[Simon of Hauteville]], became Count, with his mother [[Adelaide del Vasto]] as regent.  Simon died four years later in 1105, at the age of 12.  Adelaide continued as regent to her younger son Roger, who was just nine years old.<ref>Houben, p 24</ref>

==Reign==

===Rise to power in Sicily===
[[File:Southern Italy 1112.svg|thumb|Southern Italy in 1112. The border of the [[Kingdom of Sicily]] at the time of Roger's death in 1154 is indicated by a thicker black line encircling most of southern Italy.]]

Upon the death of his elder brother, Simon of Hauteville, in 1105, Roger inherited the County of Sicily under the [[Regent|regency]] of his mother, Adelaide del Vasto.  His mother was assisted by such notables as [[Christodulus]], the Greek [[emir]] of [[Palermo]]. In 1109, Byzantine Emperor [[Alexios I Komnenos]], bestowed upon him the title of ''protonobilissimos'', in recognition of his knowledge of the Byzantine court.<ref>''Roger II of Sicily: Rex, Basileus, and Khalif? Identity, Politics, and Propaganda in the Cappella Palatina'', Karen C. Britt, '''Mediterranean Studies''', Vol. 16, (2007), 24. '''JSTOR'''</ref> In the summer of 1110, Roger was visited by the Norwegian king [[Sigurd I of Norway|Sigurd Jorsalfare]], who was on his way to [[Jerusalem]].<ref>Houben, p 26, quoting [[Snorri Sturluson]], ''[[Heimskringla]]'', written in the 1220s. According to the ''[[Fagrskinna]]'', Roger was ''Jarl Rogeirr''.</ref> The story suggests that Sigurd gave Roger the name King of Sicily, twenty years before he actually obtained this title.

In 1112, at the age of sixteen, Roger began his personal rule, being named \"now knight, now Count of Sicily and Calabria\" in a charter document dated 12 June 1112.<ref name=\"Houben, p. 30\"/> In 1117, his mother, who had married [[Baldwin I of Jerusalem]], returned to Sicily, since the Patriarch of Jerusalem had declared the marriage invalid.  Roger seems to have felt the slight, and this might explain his later reluctance to go crusading.<ref>Houben, 29, quoting [[William of Tyre]], ''[[Chronicon (William of Tyre)|Chronicon]]'' xi.29</ref>  Roger married his first wife, [[Elvira of Castile, wife of Roger II|Elvira]], daughter of [[Alfonso VI of Castile]], and his fourth queen, Isabella, who may be identical to his former concubine, the converted Moor, Zaida, baptised Isabella.

In 1122, [[William II of Apulia|William II]] the [[Duke of Apulia]], who was fighting with Count [[Jordan of Ariano]], offered to renounce his remaining claims to Sicily as well as part of [[Calabria]].<ref name=\"Houben, p. 37\">Houben, p. 37.</ref> Roger, in exchange, provided William with 600 knights and access to money for his campaign.<ref name=\"Houben, p. 37\" />

===Rise to power in southern Italy===
When William II of Apulia died childless in July 1127, Roger claimed all [[Hauteville family]] possessions in the peninsula as well as the overlordship of the [[Principality of Capua]], which had been nominally given to Apulia almost thirty years earlier. However, the union of [[Sicily]] and Apulia was resisted by [[Pope Honorius II]] and by the subjects of the duchy itself.

====Royal investiture====
[[File:Weltliche Schatzkammer Wienc.jpg|thumb|right|Royal mantle of Roger II, bearing an inscription in Arabic with the [[Hijra year|Hegira]] date of 528 (1133–34).]]

The popes had long been suspicious of the growth of Norman power in southern Italy, and at Capua in December, the pope preached a [[crusade]] against Roger, setting [[Robert II of Capua]] and [[Ranulf II of Alife]] (his own brother-in-law) against him. After this coalition failed, in August 1128 Honorius invested Roger at [[Benevento]] as Duke of Apulia.<ref name=\"Britt25\">''Roger II of Sicily: Rex, Basileus, and Khalif? Identity, Politics, and Propaganda in the Cappella Palatina'', Karen C. Britt, '''Mediterranean Studies''', Vol. 16, (2007), 25. '''JSTOR'''</ref> The baronial resistance, backed by [[Naples]], [[Bari]], [[Salerno]], and other cities whose aim was civic freedom, gave way. In September 1129 Roger was generally recognized as duke of Apulia by [[Sergius VII of Naples]], Robert of Capua, and the rest. He began at once to enforce order in the duchy, where ducal power had long been fading.

On the death of Pope Honorius in February 1130 there were two claimants to the papal throne.  Roger supported [[Antipope Anacletus II]] against [[Pope Innocent II|Innocent II]].<ref name=\"Britt25\" />  The reward was a crown,<ref name=\"Britt25\" /> and, on 27 September 1130, Anacletus' [[papal bull]] made Roger king of Sicily.<ref>Marjorie Chibnall, ''The Normans'', (Wiley & Sons, 2006), 86.</ref> He was crowned in [[Palermo]] on [[Christmas Day]] 1130. Roger II's elaborate royal mantle bears the date 528 of the [[Islamic calendar]] (1133–34), therefore it could not have been used for his coronation.<ref name=\"Bauer: Mantel\">Rotraud Bauer: ''Der Mantel Rogers II. und die siculo-normannischen Gewänder aus den königlichen Hofwerkstätten in Palermo''. In: Hg. Wilfried Seipel.: ''Nobiles Officinae. Die königlichen Hofwerkstätten zu Palermo zur Zeit der Normannen und Staufer im 12. und 13. Jahrhundert''. Milano 2004, {{ISBN|3-85497-076-5}}, pp. 115–123.</ref><ref name=\"Bauer: Geschichte\">Rotraud Bauer: ''Zur Geschichte der sizilischen Gewänder, später Krönungsgewänder der Könige und Kaiser des Heiligen Römischen Reiches''. In: Wilfried Seipel (Hg.): ''Nobiles Officinae. Die königlichen Hofwerkstätten zu Palermo zur Zeit der Normannen und Staufer im 12. und 13. Jahrhundert.'' Milano 2004, {{ISBN|3-85497-076-5}}. pp. 85–95</ref> It was later used as coronation cloak by the Holy Roman Emperors and is now in the [[Imperial_Treasury,_Vienna|Imperial Treasury]] (Schatzkammer) in [[Vienna]].

====Peninsular rebellions====
This plunged Roger into a ten-year war. [[Bernard of Clairvaux]], Innocent's champion, organized a coalition against Anacletus and his \"half-heathen king.\"  He was joined by [[Louis VI of France]], [[Henry I of England]], and [[Lothair III, Holy Roman Emperor]]. Meanwhile, southern Italy revolted.

In 1130, the [[Duchy of Amalfi]] revolted and in 1131, Roger sent [[John (Sicilian admiral)|John of Palermo]] across the [[Strait of Messina]] to join up with a royal troop from Apulia and Calabria and march on [[Amalfi]] by land while [[George of Antioch]] blockaded the town by sea and set up a base on [[Capri]].<ref>Houben, 60. Norwich, 11.</ref> Amalfi soon capitulated.

In 1132, Roger sent [[Robert II of Capua]] and [[Ranulf II of Alife]] to [[Rome]] in a show of force in support of Anacletus. While they were away, Roger's half-sister Matilda, Ranulf's wife, fled to Roger claiming abuse. Simultaneously, Roger annexed Ranulf's brother's County of [[Avellino]]. Ranulf demanded the restitution of both wife and countship. Both were denied, and Ranulf left Rome against orders, with Robert following.

[[File:Roger II Sicily.jpg|thumb|left|[[Roger II]] riding to war, from ''Liber ad honorem Augusti'' of [[Peter of Eboli|Petrus de Ebulo]], 1196.]]
First Roger dealt with a rebellion in Apulia, where he defeated and deposed [[Grimoald, Prince of Bari]], replacing him with his second son [[Tancred, Prince of Bari|Tancred]].  Meanwhile, Robert and Ranulf took papal [[Benevento]]. Roger went to meet them but was defeated at the [[Battle of Nocera]] on 25 July 1132. Roger retreated to Salerno.

The next year, Lothair III came down to Rome for his imperial coronation. The rebel leaders met him there, but they were refused help because Lothair's force was too small.<ref>Houben, p. 63.</ref>  With the emperor's departure, divisions in his opponents' ranks allowed Roger to reverse his fortunes. By July 1134, Roger's troops had forced Ranulf, Sergius, and the other ringleaders to submit. Robert was expelled from Capua and Roger installed his third son, [[Alfonso of Hauteville]] as Prince of Capua. Roger II's eldest son [[Roger III, Duke of Apulia|Roger]] was given the title of Duke of Apulia.

Meanwhile, Lothair's contemplated attack upon Roger had gained the backing of [[Pisa]], [[Genoa]], and the [[Byzantine emperor]] [[John II Komnenos|John II]], each of whom feared the growth of a powerful Norman kingdom. A Pisan fleet led by the exiled prince of Capua dropped anchor off Naples in 1135. Ranulf joined Robert and Sergius there, encouraged by news coming from Sicily that Roger was fatally ill or even already dead. The important fortress of [[Aversa]], among others, passed to the rebels and only Capua resisted, under the royal chancellor, [[Guarin]]. On June 5, however, Roger disembarked in Salerno, much to the surprise of all the mainland provinces. The royal army, split into several forces, easily conquered Aversa and even Alife, the base of the natural rebel leader, Ranulf. Most of the rebels took refuge in Naples, which was besieged in July, but despite poor health conditions within the city, Roger was not able to take it, and returned to [[Messina]] late in the year.

====Imperial invasion====
[[File:TabulaRogeriana.jpg|thumb|The [[Tabula Rogeriana]], an [[Early world maps|ancient world map]] drawn by [[Muhammad al-Idrisi]] for Roger II of Sicily in 1154. The north is at the bottom, and so the map appears \"upside down\" compared to modern [[cartography|cartographic]] conventions.]]
In 1136, the long-awaited imperial army, led by Lothair and the [[duke of Bavaria]], [[Henry the Proud]], descended the peninsula to support the three rebels. Henry, Robert, and Ranulf took a large contingent of troops to besiege the peninsular capital of the kingdom, [[Salerno]]. Roger remained in Sicily, leaving its mainland garrisons helpless under the chancellor [[Robert of Selby]], while even the Byzantine emperor [[John II Comnenus]] sent subsidies to Lothair. Salerno surrendered, and the large army of Germans and Normans marched to the very south of Apulia. There, in June 1137, Lothair besieged and took [[Bari]]. At [[Mercato San Severino|San Severino]], after the victorious campaign, he and the pope jointly invested Ranulf as duke of Apulia in August 1137, and the emperor then retired to Germany. Roger, freed from the utmost danger, immediately disembarked in Calabria, at [[Tropea]], with 400 knights and other troops, probably mostly Muslims. After having been welcomed by the Salernitans, he recovered ground in [[Campania]], sacking [[Pozzuoli]], Alife, Capua, and Avellino. Sergius was forced to acknowledge him as overlord of Naples and switch his allegiance to Anacletus. This moment marked the fall of an independent Neapolitan duchy, and thereafter the ancient city was fully integrated into the Norman realm.

From there Roger moved to Benevento and northern [[Apulia]], where Duke Ranulf, although steadily losing his bases of power, had some German troops plus some 1,500 knights from the cities of [[Melfi]], [[Trani]], [[Troia (Italy)|Troia]], and Bari, who were \"ready to die rather than lead a miserable life.\" On 30 October 1137, at the [[Battle of Rignano]] (next to [[Gargano|Monte Gargano]]), the younger Roger and his father, with Sergius of Naples, met the defensive army of Duke Ranulf. It was the greatest defeat of Roger II's career. Sergius died and Roger fled to Salerno. It capped Ranulf's meteoric career: twice victor over Roger. Anacletus II died in January 1138, but Innocent II refused to reconcile with the King.

In spring 1138, the royal army invaded the [[Principality of Capua]], with the precise intent of avoiding a pitched battle and of dispersing Ranulf's army with a series of marches through difficult terrain. While the count of Alife hesitated, Roger, now supported by Benevento, destroyed all the rebels' castles in the region, capturing an immense booty. Ranulf himself, who had taken refuge in his capital Troia, died of malarial fever on 30 April 1139. Later, Roger exhumed his body from his grave in Troia cathedral and threw it in a ditch, only to repent subsequently and rebury him decently.

At this time, with Sergius dead, Alfonso was elected to replace him and together with his brother Roger went off to conquer the [[Abruzzi]].

====Consolidation of kingship====
[[File:Scifato ducale.jpg|left|thumb|250px|AR [[Scyphate]] Ducalis, dated year 10 (1140), after the king's victory on July 25. Obverse: Christ. Reverse: King Roger and Duke Roger.]]

After the death of Anacletus in January 1138, Roger had sought the confirmation of his title from Innocent. However, the pope wanted an independent Principality of Capua as a buffer state between the [[Kingdom of Sicily]] and the [[Papal States]], something Roger would not accept.<ref>Houben et al., p.71</ref>  In the summer of 1139, Innocent II invaded the kingdom with a large army, but was ambushed at [[Galluccio]] on 22 July 1139,<ref>Encyclopædia Britannica, 1911.</ref> southeast of present-day [[Cassino, Italy|Cassino]], by Roger's son and was captured. Three days later, by the [[Treaty of Mignano]], the pope proclaimed Roger II  ''rex Siciliae ducatus Apuliae et principatus Capuae'' (king of Sicily, duke of Apulia and commander of Capua). The boundaries of his ''regno'' were only later fixed by a truce with the pope in October 1144. These lands were for the next seven centuries to constitute the kingdoms of Naples and Sicily.

In 1139, Bari, the 50,000 inhabitants of which had remained unscathed behind its massive walls during the wars of the past year, decided to surrender. The ''excellentissimus princeps'' [[Jaquintus, Prince of Bari|Jaquintus]], who had led the rebellion of the city, was hanged, along with many of his followers, but the city avoided being sacked. Roger's execution of the prince and his counsellors was perhaps the most violent act of his life.

While his sons overcame pockets of resistance on the mainland, on 5 November 1139 Roger returned to Palermo to plan a great act of legislation: the [[Assizes of Ariano]], an attempt to establish his dominions in southern Italy as a coherent state. He returned to check on his sons' progress in 1140 and then went to [[Ariano]], a town central to the peninsular possessions (and a centre of rebellion under his predecessors). There he promulgated the great law regulating all [[Sicilians|Sicilian]] affairs. It invested the king and his bureaucracy with absolute powers and reduced the authority of the often rebellious vassals. While there, centralising his kingdom, Roger declared a new standard coinage, named after the duchy of Apulia: the ''[[ducat]].''

===Economy===
[[File:RogerIIofSicilySilverDucaleBrindisiMint.jpg|thumb|Coin of Roger II of Sicily, silver Ducale, Brindisi mint.]]
Roger’s reforms in laws and administration not only aimed to strengthen his rule but also to improve the economic standing of Sicily and [[southern Italy]].  He was \"very concerned to gain money, but hardly very prodigal in expending it.\"<ref name=\"Houben p 159\">Houben p 159</ref>

In 1140 at his assembly at Ariano he introduced new coinage to make it easier to trade with the rest of the Mediterranean, as there were smaller denominations of the previous coins, to allow more accurate and efficient trading.  However, although this new coinage made long distance trade easier it was very detrimental to local trade which spread \"hatred throughout Italy.\"<ref name=\"Houben p 159\"/>  By the 1150s most of this coinage was no longer in use and soon after, it disappeared altogether.

Nevertheless, the controversy over the coinage did not hinder the Kingdom’s prosperity.  Roger II had not only acquired large wealth through his royal patrimony but also through his military campaigns and their financial rewards.  For example, gold and silver were gained through the campaigns in Apulia in 1133 and Greece in 1147.<ref>Houben p 161</ref>

Sicily's geographic situation at the centre of Mediterranean made it a brilliant location for trade with Europe, North Africa and the Middle East. Its primary export was durum wheat; others included foods like cheese and vine fruits. Unlike other states, Sicily also had a strong political and military standing so its merchants were supported and to some extent protected.<ref>Houben p 164</ref>  This standing allowed for an increase in internal trade and a stronger market which led to noticeable developments in agriculture.<ref>Houben p 163</ref>

===Later reign===
{{See also|Norman-Arab-Byzantine culture|Kingdom of Africa}}
[[File:Chapelle Palatine.jpg|thumb|\"The [[Cappella Palatina]], at Palermo, the most wonderful of Roger's churches, with [[Norman architecture|Norman doors]], [[Islamic architecture|Saracenic arches]], [[Byzantine architecture|Byzantine dome]], and roof adorned with [[Arabic alphabet|Arabic scripts]], is perhaps the most striking product of the brilliant and mixed civilization over which the grandson of the Norman Trancred ruled\" (from [[EB1911|1911 Encyclopædia Britannica]]).]]

Roger had now become one of the greatest kings in Europe. At Palermo, he gathered round him distinguished men of various races, such as the famous [[Geography in medieval Islam|Arab geographer]] [[Muhammad al-Idrisi]] and the Byzantine [[Greek historiography|Greek historian]] Nilus Doxopatrius. The king welcomed the learned and practised toleration towards the several creeds, races and languages of his realm. To administer his domain he hired many [[Greeks]] and [[Arab]]s, who were trained in long-established traditions of centralized government.<ref>[[Maurice Keen]], Pelican History of Medieval Europe, Routledge Kegan & Paul 1968</ref> He was served by men of diverse nationality, such as the Englishman [[Thomas Brun]], a ''[[kaid]]'' of the ''Curia'' and, in the fleet by two Greeks, first Christodulus and then [[George of Antioch]], whom he made in 1132 ''ammiratus ammiratorum'' or \"Emir of Emirs\", in effect prime [[vizier]]. (This title later became the English word [[admiral]]). Roger made Sicily the leading maritime power in the [[Mediterranean]].

[[File:Regnonormanno1160.jpg|thumb|left|200px|The \"Kingdom of Africa\" (''Regno d'Africa'') pinpointed in red of Roger II]]

A powerful fleet was built up under several admirals, or \"emirs\", of whom the greatest was George, formerly in the service of the [[Muslim]] prince of [[Mahdia]]. Mainly thanks to him, a [[Kingdom of Africa|series of conquests were made on the African coast]] (1146–1153). From 1135 Roger II started to conquer the coast of Tunisia and enlarge his dominions: [[Tripoli]] was captured in 1146 and [[Bône|Cape Bona]] in 1148. These conquests were lost in the reign of Roger's successor William, however, and never formed an integral part of the kingdom in southern Italy.

The [[Second Crusade]] (1147–1148) offered Roger an opportunity to revive attacks on the [[Byzantine Empire]], the traditional Norman enemy to the East. It also afforded him an opportunity, through the agency of [[Theodwin]], a cardinal ever-vigilant for Crusade supporters, to strike up a correspondence with [[Conrad III of Germany]] in an effort to break his alliance with [[Manuel I Comnenus]]. Roger himself never went on an expedition against [[Byzantium]], instead handing command to the skillful George. In 1147, George set sail from [[Otranto]] with seventy galleys to attack [[Corfu]]. According to [[Nicetas Choniates]], the island capitulated thanks to George's bribes (and the tax burden of the imperial government), welcoming the Normans as their liberators. Leaving a garrison of 1,000 men, George sailed on to the [[Peloponnesus]]. He sacked [[Athens]] and quickly moved on to the [[Aegean Islands]]. He ravaged the coast all along [[Euboea]] and the [[Gulf of Corinth]] and penetrated as far as [[Thebes, Greece]], where he pillaged the silk factories and carried off the Jewish damask, brocade, and silk weavers, taking them back to Palermo where they formed the basis for the Sicilian silk industry. George capped the expedition with a sack of [[Corinth]], in which the relics of [[Theodore of Amasea|Saint Theodore]] were stolen, and then returned to Sicily. In 1149, however, Corfu was retaken. George went on a [[punitive expedition]] against Constantinople, but could not land and instead defied the Byzantine emperor by firing arrows against the palace windows. Despite this act, his expedition left no enduring effects.

Roger died at [[Palermo]] on 26 February 1154 and was buried in the [[Cathedral of Palermo]]. He was succeeded by his fourth son, [[William I of Sicily|William]].

Roger is the subject of ''[[King Roger]]'', a 1926 opera by Polish composer [[Karol Szymanowski]]. The last months of his life are also featured in [[Tariq Ali]]'s book ''A Sultan in Palermo''. Studiorum Universitas Ruggero II, a private non-traditional university connected to [[Accademia Normanna]] was incorporated in the U.S. on April 30, 2001 in honor of this king.<ref>http://www.normanacademy.it/RugIIUni.htm</ref>

==Family==
[[File:Tomb of Roger II of Sicily - Cathedral of Palermo - Italy 2015.JPG|thumb|Roger's tomb in the Cathedral of Palermo.]]
Roger's first marriage was in 1117 to [[Elvira of Castile, Queen of Sicily|Elvira]], a daughter of King [[Alfonso VI of Castile]]. When she died, rumors flew that Roger had died as well, as his grief had made him a recluse.<ref>Houben, 65.</ref> They had six children:

* [[Roger III, Duke of Apulia|Roger]] (b. 1118 – d. 12 May 1148), heir, [[Duke of Apulia]] (from 1135), possibly also Count of [[Lecce]];
* [[Tancred, Prince of Bari|Tancred]] (b. 1119 – d. 1138), Prince of Bari (from 1135).
* [[Alfonso of Hauteville|Alfonso]] (b. 1120/1121 – d. 10 October 1144), [[Prince of Capua]] (from 1135) and [[Duke of Naples]];
* A daughter (d. young in 1135);
* [[William I of Sicily|William]] (b. 1131 – d. 7 May 1166), his successor, [[Duke of Apulia]] (from 1148)<ref>''The New Cambridge Medieval History: Volume 4, C.1024-c.1198'', Part II, ed. David Luscombe and Jonathan Riley-Smith, (Cambridge University Press, 2004), 760.</ref>
* Henry (b. 1135 – d. young).

Roger's second marriage was in 1149 to [[Sibylla of Burgundy|Sibylla]], daughter of [[Hugh II, Duke of Burgundy]].<ref name=\"Houben96\">Houben, 96.</ref> They had two children:

* Henry (b. 29 August 1149 – d. young);
* Stillborn child (16 September 1150).<ref name=\"Houben96\" />

Roger's third marriage was in 1151 to [[Beatrice of Rethel]], a grandniece of King [[Baldwin II of Jerusalem]].<ref name=\"Houben96\" /> They had one daughter:

*[[Constance of Sicily|Constance]] (b. posthumously, 2 November 1154 – d. 28 November 1198),<ref name=\"Houben96\" /> who married the Emperor [[Henry VI, Holy Roman Emperor|Henry VI]] and was later Queen of Sicily.<ref>''Italy and Sicily under Frederick II'', Michaelangelo Schipa, '''The Cambridge Medieval History''', Vol. IV, ed. J.R. Tanner, [[Charles William Previté-Orton|C. W. Previté-Orton]] and [[Zachary Nugent Brooke|Z.N. Brooke]], (Cambridge University Press, 1957), 131.</ref>

Roger also had five known illegitimate children:

—By a daughter of Hugues I, Count of Molise:
* [[Simon of Taranto|Simon]], who became [[Prince of Taranto]] in 1144.<ref name=\"Houben96\" />

—With unknown mistresses:
* A daughter, wife of Rodrigo Garcés (later [[Henry, Count of Montescaglioso]])
* A daughter, wife of the neapolitan nobleman Adam;
* Clenenza,  married Hugues II, Count of Molise;
* Adelisa (d. aft. 1184/87) married firstly Joscelin, Count of Loreto, and secondly [[Robert III of Loritello|Robert of Bassonville]], Count of Loritello;
* Marina, married the great admiral [[Margaritus of Brindisi]].

{{ahnentafel top|width=100%}}
{{ahnentafel-compact5
|style=font-size: 90%; line-height: 110%;
|border=1
|boxstyle=padding-top: 0; padding-bottom: 0;
|boxstyle_1=background-color: #fcc;
|boxstyle_2=background-color: #fb9;
|boxstyle_3=background-color: #ffc;
|1= 1. '''Roger II of Sicily'''
|2= 2. [[Roger I of Sicily]]
|3= 3. [[Adelaide del Vasto]]
|4= 4. [[Tancred of Hauteville]]
|5= 5. Fredisenda
|6= 6. Manfred del Vasto

}}</center>
{{ahnentafel bottom}}

==Notes==
{{reflist|2}}

==Sources==
{{Commons category|Roger II of Sicily}}
*[[Alexander of Telese]], ''The Deeds of Roger''.
*[[Pierre Aubé|Aubé, Pierre]]. ''Roger II de Sicile''. 2001.
*Barber, Malcolm. ''The Two Cities: Medieval Europe, 1050-1320'', Routledge, [[London]], second edition 2004, chapter 9, ''The Kingdom of Sicily''
*Hamel, Pasquale ''L'invenzione del regno, dalla conquista normanna alla fondazione del Regnum  Siciliae (1061/1154)'' (Palermo, 2009)
*Holmes, George, ''The Oxford IllustratedHistory of Medieval Europe''.  OUP, 1988.
*[[Hubert Houben (historian)|Houben, Hubert]] (translated by Graham A. Loud and Diane Milburn). ''Roger II of Sicily: Ruler between East and West''. [[Cambridge University Press]], 2002.
*Matthew, Donald. ''The Norman Kingdom of Sicily (Cambridge Medieval Textbooks)'', 1992.
* Alex Metcalfe [https://books.google.com/books?id=VRXTzPOly-oC&printsec=frontcover&dq=the+muslims+of+medieval+italy&hl=en&ei=MpdKTYXDKsW7hAeo1p2oDg&sa=X&oi=book_result&ct=result&resnum=1&ved=0CCkQ6AEwAA#v=onepage&q&f=false ''The Muslims of Medieval Italy''] (Edinburgh, 2009)
*Francois Neveux. ''The Normans'', Constable & Robinson, London, 2008 (translated by Howard Curtis).
*[[John Julius Norwich|Norwich, John Julius]]. ''The Normans in the South 1016-1130''. Longmans: [[London]], 1967.
*[[John Julius Norwich|Norwich, John Julius]]. ''The Kingdom in the Sun 1130-1194''. Longman: [[London]], 1970.
*Rowe, John Gordon. \"[https://www.jstor.org/stable/3162160 The Papacy and the Greeks (1122-1153) (Part II).]\" ''Church History'', Vol. 28, No. 3. (Sep., 1959), pp 310–327.
*Wieruszowski, Helen. \"[https://www.jstor.org/stable/2851498 Roger II of Sicily, Rex-Tyrannus, In Twelfth-Century Political Thought.]\" ''Speculum'', Vol. 38, No. 1. (Jan., 1963), pp 46–78.

==External links==
*[https://web.archive.org/web/20060822161507/http://www.paradoxplace.com/Perspectives/Sicily%20%26%20S%20Italy/Montages/Sicily/Palermo/Palermo%20%26%20First%20Normans.htm Adrian Fletcher’s Paradoxplace – Palermo and the First Normans – Photos]
*[http://www.saudiaramcoworld.com/issue/197704/al-idrisi.and.roger.s.book.htm '' Al-Idrisi And Roger’s Book ''], written by Frances Carney Gies.

{{S-start}}
{{s-reg}}
{{s-bef| before = [[Simon, Count of Sicily|Simon]] }}
{{s-ttl| title  = [[Count of Sicily]]
       | years  = 1105–1130 }}
{{s-non| rows   = 2 | reason= [[Kingdom of Sicily]] created }}
{{s-bef| before = [[William II, Duke of Apulia|William II]] }}
{{s-ttl| title  = [[Duke of Apulia and Calabria]]
       | years  = 1127–1130 }}
{{s-new}}
{{s-ttl| title  = [[King of Sicily]]
       | years  =1130–1154 }}
{{s-aft| after= [[William I of Sicily|William I]] }}
{{succession box|title=[[Principality of Taranto|Prince of Taranto]]|before=[[Bohemond II of Antioch|Bohemond II]]|after=[[Tancred, Prince of Bari|Tancred]]|years=1128–1132}}
{{S-end}}

{{Authority control}}

{{DEFAULTSORT:Roger 02 of Sicily}}
[[Category:Roger II of Sicily| ]]
[[Category:Roman Catholic monarchs]]
[[Category:Kings of Sicily]]
[[Category:Medieval child rulers]]
[[Category:1095 births]]
[[Category:1154 deaths]]
[[Category:Burials at Palermo Cathedral]]
[[Category:Christians of the Second Crusade]]
[[Category:Dukes of Apulia]]
[[Category:Hauteville family]]
[[Category:Italo-Normans]]
[[Category:Byzantine–Norman wars]]
")
        );

        $this->assertEquals(
            'Joseph Marie Benoît François Xavier Galouzeau de Villepin (born 14 March 1926 in Brussels, Belgium – 30 October 2014), simply known as Xavier de Villepin, was a former high-ranking civil servant of France, and a former French senator from the center-right UMP party (and before that from the more centrist UDF party). He was the father of the former Prime Minister of France, Dominique de Villepin.

==Biography==
Xavier de Villepin graduated from the renowned French business school HEC Paris in 1949 and later from the Harvard Business School. He took part in the French Resistance in 1944. As a French civil servant, he spent many years overseas. From 1950 until 1979, he served in chronological order in French Algeria, in Australia, in the French protectorate of Morocco, in Venezuela, and finally in the United States. He became a member of the Association of French Citizens Abroad (Union des Français de l\'Étranger) in 1960, and its 2nd vice-president in 1979.

Xavier de Villepin was elected to the French senate in 1986 by the constituency of the French citizens living abroad, and remained a French senator until September 2004, when he chose not to run for a third term. In 1993 he was elected chairman of the French Senate Committee on Foreign Affairs, Defense, and Armed Forces (Commission des affaires étrangères, de la défense et des forces armées). He resigned from the committee in 2002 following the appointment of his son Dominique de Villepin as Minister of Foreign Affairs.

== References ==


== External links ==
http://www.xavierdevillepin.com/, personal pages in French




Category:1926 births
Category:2014 deaths
Category:French politicians
Category:HEC Paris alumni
Category:Harvard Business School alumni
Category:Senators of French citizens living abroad',
            $parser->XtractText("{{BLP sources|date=December 2010}}
{{infobox person
| name = Xavier de Villepin
| birth_date = {{birth date|1926|3|14|df=yes}}
| birth_place = [[Brussels]], [[Belgium]]
| death_date = {{death date and age|2014|10|30|1926|3|14|df=yes}}
| death_place = [[Paris]], [[France]]
| nationality = [[France|French]]
| education = [[HEC Paris]]<br>[[Harvard Business School]]
| occupation = Politician<br>Industrialist
| relatives = [[Dominique de Villepin]] (son)
}}
'''Joseph Marie Benoît François Xavier Galouzeau de Villepin'''<ref>https://gw.geneanet.org/frebault?lang=en&pz=henri&nz=frebault&ocz=0&p=joseph+marie+benoit+francois+xavier&n=galouzeau+de+villepin</ref>{{Unreliable source?|date=January 2018}} (born 14 March 1926 in [[Brussels]], [[Belgium]] – 30 October 2014), simply known as '''Xavier de Villepin''', was a former high-ranking civil servant of [[France]], and a former [[French Senate|French senator]] from the center-right [[Union pour un Mouvement Populaire|UMP]] party (and before that from the more centrist [[Union for French Democracy|UDF]] party). He was the father of the former [[Prime Minister of France]], [[Dominique de Villepin]].

==Biography==
Xavier de Villepin graduated from the renowned French business school HEC Paris in 1949 and later from the [[Harvard Business School]]. He took part in the [[French Resistance]] in 1944. As a French civil servant, he spent many years overseas. From 1950 until 1979, he served in chronological order in [[French Algeria]], in [[Australia]], in the French [[protectorate]] of [[Morocco]], in [[Venezuela]], and finally in the [[United States]]. He became a member of the Association of French Citizens Abroad (''Union des Français de l'Étranger'') in 1960, and its 2nd vice-president in 1979.

Xavier de Villepin was elected to the [[French senate]] in 1986 by the constituency of the French citizens living abroad, and remained a French senator until September 2004, when he chose not to run for a third term.<ref>{{Cite web |language=French |title=Anciens sénateurs Vème République : de VILLEPIN Xavier |trans-title=Former senator of the fifth Republic : de VILLEPIN Xavier |url=http://www.senat.fr/senateur/de_villepin_xavier86050e.html |work=French Senat}}</ref> In 1993 he was elected chairman of the French Senate Committee on Foreign Affairs, Defense, and Armed Forces (''Commission des affaires étrangères, de la défense et des forces armées''). He resigned from the committee in 2002 following the appointment of his son Dominique de Villepin as [[Minister of Foreign Affairs (France)|Minister of Foreign Affairs]].

== References ==
<references/>

== External links ==
* http://www.xavierdevillepin.com/,{{dead link|date=July 2016 |bot=InternetArchiveBot |fix-attempted=yes }} personal pages in French

{{Authority control}}

{{DEFAULTSORT:Villepin, Xavier De}}
[[Category:1926 births]]
[[Category:2014 deaths]]
[[Category:French politicians]]
[[Category:HEC Paris alumni]]
[[Category:Harvard Business School alumni]]
[[Category:Senators of French citizens living abroad]]
")
        );
    }
}