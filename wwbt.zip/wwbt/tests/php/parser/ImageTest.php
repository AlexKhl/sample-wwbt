<?php

require_once __DIR__ . "/../../../vendor/autoload.php";

/**
 * @covers Email
 */
final class ImageTest extends \diplux\tests\DipluxTestCase
{
    public function testImageExtraction()
    {
        $imageParser = new \diplux\app\entity\ImageWrapper();

        $this->assertEquals('Within_Temptation_-_Running_Up_That_Hill.jpg', $imageParser->extractName('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill.jpg', true));
        $this->assertEquals('Within_Temptation_-_Running_Up_That_Hill', $imageParser->extractName('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill.jpg'));
        $this->assertEquals('Burak_Özçivit_2011.jpg', $imageParser->extractName('wikipedia/tr/archive/5/57/20110918204402!Burak_Özçivit_2011.jpg', true));
        $this->assertEquals('Burak_Özçivit_2011', $imageParser->extractName('wikipedia/tr/archive/5/57/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('Burak_Özçivit_2011.jpg', $imageParser->extractName('/20110918204402!Burak_Özçivit_2011.jpg', true));
        $this->assertEquals('Burak_Özçivit_2011', $imageParser->extractName('/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('Burak_Özçivit_2011.jpg', $imageParser->extractName('20110918204402!Burak_Özçivit_2011.jpg', true));
        $this->assertEquals('Burak_Özçivit_2011', $imageParser->extractName('20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg', $imageParser->extractName('wikipedia/commons/8/8a/Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg', true));
        $this->assertEquals('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage', $imageParser->extractName('wikipedia/commons/8/8a/Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg'));
        $this->assertEquals('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg', $imageParser->extractName('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg', true));
        $this->assertEquals('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage', $imageParser->extractName('Flickr_-_NewsPhoto!_-_Marxisme_festival_Amsterdam,_Jean-Yves_Lesage.jpg'));
    }

    public function testImageHash()
    {
        $imageParser = new \diplux\app\entity\ImageWrapper();

        $this->assertEquals('a5a4b3a71e31ca61866d978ee28c056d', $imageParser->getHash('wikipedia/tr/archive/5/57/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('a5a4b3a71e31ca61866d978ee28c056d', $imageParser->getHash('/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('a5a4b3a71e31ca61866d978ee28c056d', $imageParser->getHash('/20110918204402!Burak_Özçivit_2011.png'));
        $this->assertEquals('a5a4b3a71e31ca61866d978ee28c056d', $imageParser->getHash('20110918204402!Burak_Özçivit_2011.jpg'));

        $this->assertEquals('b9f196a2c3e7fd03f339d2f380050ee8', $imageParser->getHash('Within_Temptation_-_Running_Up_That_Hill.jpg'));
        $this->assertEquals('b9f196a2c3e7fd03f339d2f380050ee8', $imageParser->getHash('Within_Temptation_-_Running_Up_That_Hill'));
        $this->assertEquals('b9f196a2c3e7fd03f339d2f380050ee8', $imageParser->getHash('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill.jpg'));
        $this->assertEquals('b9f196a2c3e7fd03f339d2f380050ee8', $imageParser->getHash('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill'));
    }

    public function testImagePathGenerator()
    {
        $imageParser = new \diplux\app\entity\ImageWrapper();

        $this->assertEquals('a/5a/a5a4b3a71e31ca61866d978ee28c056d.jpg', $imageParser->getRealPath('wikipedia/tr/archive/5/57/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('a/5a/a5a4b3a71e31ca61866d978ee28c056d.jpg', $imageParser->getRealPath('/20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('a/5a/a5a4b3a71e31ca61866d978ee28c056d.jpg', $imageParser->getRealPath('20110918204402!Burak_Özçivit_2011.jpg'));
        $this->assertEquals('a/5a/a5a4b3a71e31ca61866d978ee28c056d.png', $imageParser->getRealPath('20110918204402!Burak_Özçivit_2011.png'));
        $this->assertEquals('b/9f/b9f196a2c3e7fd03f339d2f380050ee8', $imageParser->getRealPath('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill'));
        $this->assertEquals('b/9f/b9f196a2c3e7fd03f339d2f380050ee8.gif', $imageParser->getRealPath('wikipedia/tr/2/2a/Within_Temptation_-_Running_Up_That_Hill.gif'));
    }
}

