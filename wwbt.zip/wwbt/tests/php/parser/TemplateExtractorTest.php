<?php

require_once __DIR__."/../../../vendor/autoload.php";

/**
 * @covers Email
 */
final class TemplateExtractorTest extends \diplux\tests\DipluxTestCase
{

    public function testAstParser()
    {
        $parser = new \diplux\parser\Extractor();

        $testPairs = [
            [
                'text' =>
                    <<<CDATA
=== Achilles and Patroclus ===
{{main article|Achilles and Patroclus}}
CDATA
                ,
                'result' => [
                    '=== Achilles and Patroclus ===',
                    [
                        'type' => 'macros',
                        'text' => '{{main article|Achilles and Patroclus}}',
                        'args' => [
                            'main article',
                            'Achilles and Patroclus',
                        ],
                    ],
                ]
            ],
            [
                'text' =>
                    <<<CDATA
In the ''Odyssey'', Agamemnon informs Achilles of his pompous burial and the erection of his [[mound]] at the [[Hellespont]] while they are receiving the dead [[Suitors of Penelope|suitors]] in Hades.&lt;ref&gt;''Odyssey'' 24.36–94.&lt;/ref&gt;
He claims they built a massive burial mound on the beach of Ilion that could be seen by anyone approaching from the Ocean.&lt;ref&gt;{{Cite book
| title = The Odyssey of Homer
| author= Richmond Lattimore
| publisher = Harper Perennial
| year = 2007
| isbn = 978-0-06-124418-6
| location = New York
| page = 347
}}&lt;/ref&gt; Achilles was cremated and his ashes buried in the same urn as those of Patroclus.&lt;ref&gt;E. Hamilton (1969), ''Mythology''. New York: Penguin Books.&lt;/ref&gt; Paris was later killed by [[Philoctetes]] using the enormous bow of [[Heracles]].
CDATA
                ,
                'result' => [
                    "In the ''Odyssey'', Agamemnon informs Achilles of his pompous burial and the erection of his [[mound]] at the [[Hellespont]] while they are receiving the dead [[Suitors of Penelope|suitors]] in Hades.&lt;ref&gt;''Odyssey'' 24.36–94.&lt;/ref&gt;
He claims they built a massive burial mound on the beach of Ilion that could be seen by anyone approaching from the Ocean.&lt;ref&gt;",
                    [
                        'type' => 'macros',
                        'text' => '{{Cite book
| title = The Odyssey of Homer
| author= Richmond Lattimore
| publisher = Harper Perennial
| year = 2007
| isbn = 978-0-06-124418-6
| location = New York
| page = 347
}}',

                        'args' => [
                            'Cite book',
                            'title' => 'The Odyssey of Homer',
                            'author' => 'Richmond Lattimore',
                            'publisher' => 'Harper Perennial',
                            'year' => '2007',
                            'isbn' => '978-0-06-124418-6',
                            'location' => 'New York',
                            'page' => '347',

                        ],
                    ],
                    "&lt;/ref&gt; Achilles was cremated and his ashes buried in the same urn as those of Patroclus.&lt;ref&gt;E. Hamilton (1969), ''Mythology''. New York: Penguin Books.&lt;/ref&gt; Paris was later killed by [[Philoctetes]] using the enormous bow of [[Heracles]].",
                ]
            ],
            [
                'text' => <<<CDATA
{{Infobox person
| name         = Bille August
| image        = Bille August.jpg
| birth_date   = {{birth date and age|1948|11|9|df=yes}}
| birth_place  = [[Brede, Denmark|Brede]], Denmark
| occupation   = Film director
| years_active = 1978–present
| spouse       = {{marriage|[[Pernilla August]]&lt;br&gt;|1991|1997|end=div}}&lt;br /&gt;Masja Dessau&lt;br /&gt;Annie Munksgaard&lt;br /&gt;Sara-Marie Maltha &lt;br&gt;(m. ?–present)
| children     = 8, including [[Anders August|Anders]]
}}
CDATA
                ,
                'result' => [
                    [
                        'type' => 'macros',
                        'text' => '{{Infobox person
| name         = Bille August
| image        = Bille August.jpg
| birth_date   = {{birth date and age|1948|11|9|df=yes}}
| birth_place  = [[Brede, Denmark|Brede]], Denmark
| occupation   = Film director
| years_active = 1978–present
| spouse       = {{marriage|[[Pernilla August]]&lt;br&gt;|1991|1997|end=div}}&lt;br /&gt;Masja Dessau&lt;br /&gt;Annie Munksgaard&lt;br /&gt;Sara-Marie Maltha &lt;br&gt;(m. ?–present)
| children     = 8, including [[Anders August|Anders]]
}}',
                        'args' => [
                            'Infobox person',
                            'name' => 'Bille August',
                            'image' => 'Bille August.jpg',
                            'birth_date' => [
                                'type' => 'macros',
                                'text' => '{{birth date and age|1948|11|9|df=yes}}',
                                'args' => [
                                    'birth date and age',
                                    '1948',
                                    '11',
                                    '9',
                                    'df' => 'yes',
                                ],
                            ],
                            'birth_place' => '[[Brede, Denmark|Brede]], Denmark',
                            'occupation' => 'Film director',
                            'years_active' => '1978–present',
                            'spouse' => [
                                [
                                    'type' => 'macros',
                                    'text' => '{{marriage|[[Pernilla August]]&lt;br&gt;|1991|1997|end=div}}',
                                    'args' => [
                                        'marriage',
                                        '[[Pernilla August]]&lt;br&gt;',
                                        '1991',
                                        '1997',
                                        'end' => 'div',
                                    ],
                                ],
                                '&lt;br /&gt;Masja Dessau&lt;br /&gt;Annie Munksgaard&lt;br /&gt;Sara-Marie Maltha &lt;br&gt;(m. ?–present)',
                            ],
                            'children' => '8, including [[Anders August|Anders]]',
                        ],
                    ]
                ],
            ],
            [
                'text' =>
                    <<<CDATA
{{Infobox person
| name = Benny Andersson
| image = Benny Andersson 2012-09-24 001.jpg
| caption = Andersson in September 2012
| image_size = &lt;!-- Only for images narrower than 220 pixels --&gt;
| birth_name = Göran Bror Benny Andersson
| birth_date = {{Birth date and age|1946|12|16|df=y}}
| birth_place = [[Vällingby]], [[Sweden]]
| other_names = Göran Andersson&lt;br&gt;Göran B. Andersson&lt;br&gt;Göran B.B. Andersson&lt;br&gt;Benny B.G. Andersson&lt;br&gt;Benny Bror Göran Andersson
| occupation = {{flatlist|
*Composer
*musician
*producer
*songwriter
}}
| years_active = 1964–present
| spouse = {{marriage|[[Anni-Frid Lyngstad|Anni-Frid (Frida) Lyngstad]]&lt;br&gt;|1978|1981|end=divorced}}&lt;br&gt;{{marriage|Mona Nörklit&lt;br&gt;|1981}}
| children = 3
| relations =
| partner = Christina Grönvall
| module = {{Infobox musical artist|embed=yes
| background = solo_singer
| genre = {{flatlist|
*[[Folk rock]]
*[[Europop]]
*[[Swedish folk music|Swedish folk]]
*[[Euro disco]]
*[[schlager]]
}}
| label = {{flatlist|
*[[Polar Music|Polar]]
*[[Epic Records|Epic]]
*[[Mono Music|Mono]]
}}
| instrument = {{flatlist|
*Keyboards
*vocals
*guitar
}}
| associated_acts = {{flatlist|
*[[ABBA]]
*[[Hep Stars]]
*[[Orsa Spelmän]]
*[[Björn Ulvaeus]]
*[[Anni-Frid Lyngstad]] }}
}}
| website = }}
CDATA
                ,
                'result' => [
                    [
                        'type' => 'macros',
                        'text' => <<<CDATA
{{Infobox person
| name = Benny Andersson
| image = Benny Andersson 2012-09-24 001.jpg
| caption = Andersson in September 2012
| image_size = &lt;!-- Only for images narrower than 220 pixels --&gt;
| birth_name = Göran Bror Benny Andersson
| birth_date = {{Birth date and age|1946|12|16|df=y}}
| birth_place = [[Vällingby]], [[Sweden]]
| other_names = Göran Andersson&lt;br&gt;Göran B. Andersson&lt;br&gt;Göran B.B. Andersson&lt;br&gt;Benny B.G. Andersson&lt;br&gt;Benny Bror Göran Andersson
| occupation = {{flatlist|
*Composer
*musician
*producer
*songwriter
}}
| years_active = 1964–present
| spouse = {{marriage|[[Anni-Frid Lyngstad|Anni-Frid (Frida) Lyngstad]]&lt;br&gt;|1978|1981|end=divorced}}&lt;br&gt;{{marriage|Mona Nörklit&lt;br&gt;|1981}}
| children = 3
| relations =
| partner = Christina Grönvall
| module = {{Infobox musical artist|embed=yes
| background = solo_singer
| genre = {{flatlist|
*[[Folk rock]]
*[[Europop]]
*[[Swedish folk music|Swedish folk]]
*[[Euro disco]]
*[[schlager]]
}}
| label = {{flatlist|
*[[Polar Music|Polar]]
*[[Epic Records|Epic]]
*[[Mono Music|Mono]]
}}
| instrument = {{flatlist|
*Keyboards
*vocals
*guitar
}}
| associated_acts = {{flatlist|
*[[ABBA]]
*[[Hep Stars]]
*[[Orsa Spelmän]]
*[[Björn Ulvaeus]]
*[[Anni-Frid Lyngstad]] }}
}}
| website = }}
CDATA
                        ,
                        'args' => [
                            'Infobox person',
                            'name' => 'Benny Andersson',
                            'image' => 'Benny Andersson 2012-09-24 001.jpg',
                            'caption' => 'Andersson in September 2012',
                            'image_size' => '&lt;!-- Only for images narrower than 220 pixels --&gt;',
                            'birth_name' => 'Göran Bror Benny Andersson',
                            'birth_date' => [
                                'type' => 'macros',
                                'text' => '{{Birth date and age|1946|12|16|df=y}}',
                                'args' => [
                                    'Birth date and age',
                                    '1946',
                                    '12',
                                    '16',
                                    'df' => 'y',
                                ],

                            ],
                            'birth_place' => '[[Vällingby]], [[Sweden]]',
                            'other_names' => 'Göran Andersson&lt;br&gt;Göran B. Andersson&lt;br&gt;Göran B.B. Andersson&lt;br&gt;Benny B.G. Andersson&lt;br&gt;Benny Bror Göran Andersson',
                            'occupation' => [
                                'type' => 'macros',
                                'text' => '{{flatlist|
*Composer
*musician
*producer
*songwriter
}}',
                                'args' => [
                                    'flatlist',
                                    '*Composer
*musician
*producer
*songwriter'
                                ],

                            ],

                            'years_active' => '1964–present',
                            'spouse' => [
                                [
                                    'type' => 'macros',
                                    'text' => '{{marriage|[[Anni-Frid Lyngstad|Anni-Frid (Frida) Lyngstad]]&lt;br&gt;|1978|1981|end=divorced}}',
                                    'args' => [
                                        'marriage',
                                        '[[Anni-Frid Lyngstad|Anni-Frid (Frida) Lyngstad]]&lt;br&gt;',
                                        '1978',
                                        '1981',
                                        'end' => 'divorced',
                                    ]
                                ],
                                '&lt;br&gt;',
                                [
                                    'type' => 'macros',
                                    'text' => '{{marriage|Mona Nörklit&lt;br&gt;|1981}}',
                                    'args' => [
                                        'marriage',
                                        'Mona Nörklit&lt;br&gt;',
                                        '1981'
                                    ]
                                ],
                            ],
                            'children' => '3',
                            'relations' => '',
                            'partner' => 'Christina Grönvall',

                            'module' => [
                                'type' => 'macros',
                                'text' => '{{Infobox musical artist|embed=yes
| background = solo_singer
| genre = {{flatlist|
*[[Folk rock]]
*[[Europop]]
*[[Swedish folk music|Swedish folk]]
*[[Euro disco]]
*[[schlager]]
}}
| label = {{flatlist|
*[[Polar Music|Polar]]
*[[Epic Records|Epic]]
*[[Mono Music|Mono]]
}}
| instrument = {{flatlist|
*Keyboards
*vocals
*guitar
}}
| associated_acts = {{flatlist|
*[[ABBA]]
*[[Hep Stars]]
*[[Orsa Spelmän]]
*[[Björn Ulvaeus]]
*[[Anni-Frid Lyngstad]] }}
}}',
                                'args' => [
                                    'Infobox musical artist',
                                    'embed' => 'yes',
                                    'background' => 'solo_singer',
                                    'genre' => [
                                        'type' => 'macros',
                                        'text' => '{{flatlist|
*[[Folk rock]]
*[[Europop]]
*[[Swedish folk music|Swedish folk]]
*[[Euro disco]]
*[[schlager]]
}}',
                                        'args' => [
                                            'flatlist',
                                            '*[[Folk rock]]
*[[Europop]]
*[[Swedish folk music|Swedish folk]]
*[[Euro disco]]
*[[schlager]]'
                                        ],
                                    ],
                                    'label' => [
                                        'type' => 'macros',
                                        'text' => '{{flatlist|
*[[Polar Music|Polar]]
*[[Epic Records|Epic]]
*[[Mono Music|Mono]]
}}',
                                        'args' => [
                                            'flatlist',
                                            '*[[Polar Music|Polar]]
*[[Epic Records|Epic]]
*[[Mono Music|Mono]]'
                                        ],
                                    ],
                                    'instrument' => [
                                        'type' => 'macros',
                                        'text' => '{{flatlist|
*Keyboards
*vocals
*guitar
}}',
                                        'args' => [
                                            'flatlist',
                                            '*Keyboards
*vocals
*guitar'
                                        ],
                                    ],
                                    'associated_acts' => [
                                        'type' => 'macros',
                                        'text' => '{{flatlist|
*[[ABBA]]
*[[Hep Stars]]
*[[Orsa Spelmän]]
*[[Björn Ulvaeus]]
*[[Anni-Frid Lyngstad]] }}',
                                        'args' => [
                                            'flatlist',
                                            '*[[ABBA]]
*[[Hep Stars]]
*[[Orsa Spelmän]]
*[[Björn Ulvaeus]]
*[[Anni-Frid Lyngstad]]'
                                        ],
                                    ],
                                ],

                            ],

                            'website' => '',
                        ],
                    ],
                ],
            ],
            [
                'text' =>
                    <<<CDATA
{{flatlist|* [[Singing|Singer]]
* [[dance]]r
* [[Model (people)|model]]
* [[Actor|actress]]
* [[Businessman|businesswoman]]}} 
CDATA
                ,
                'result' => [
                    [
                        'type' => 'macros',
                        'text' => '{{flatlist|* [[Singing|Singer]]
* [[dance]]r
* [[Model (people)|model]]
* [[Actor|actress]]
* [[Businessman|businesswoman]]}}',
                        'args' => [
                            'flatlist',
                            '* [[Singing|Singer]]
* [[dance]]r
* [[Model (people)|model]]
* [[Actor|actress]]
* [[Businessman|businesswoman]]',
                        ],
                    ],
                ]
            ],

        ];

        //we don't use loop here to navigate directly to failed test
        $i = 0;
        $this->assertTextEquals($testPairs[$i]['text'], $parser->unprocessText($testPairs[$i++]['result']), 'invalid test data or concatenation');
        $this->assertTextEquals($testPairs[$i]['text'], $parser->unprocessText($testPairs[$i++]['result']), 'invalid test data or concatenation');
        $this->assertTextEquals($testPairs[$i]['text'], $parser->unprocessText($testPairs[$i++]['result']), 'invalid test data or concatenation');
        $this->assertTextEquals($testPairs[$i]['text'], $parser->unprocessText($testPairs[$i++]['result']), 'invalid test data or concatenation');
        $this->assertTextEquals($testPairs[$i]['text'], $parser->unprocessText($testPairs[$i++]['result']), 'invalid test data or concatenation');

        //we don't use loop here to navigate directly to failed test
        $i = 0;
        $this->assertEquals($testPairs[$i]['result'], $parser->processText($testPairs[$i++]['text']), 'invalid parsing');
        $this->assertEquals($testPairs[$i]['result'], $parser->processText($testPairs[$i++]['text']), 'invalid parsing');
        $this->assertEquals($testPairs[$i]['result'], $parser->processText($testPairs[$i++]['text']), 'invalid parsing');
        $this->assertEquals($testPairs[$i]['result'], $parser->processText($testPairs[$i++]['text']), 'invalid parsing');
        $this->assertEquals($testPairs[$i]['result'], $parser->processText($testPairs[$i++]['text']), 'invalid parsing');
    }

    public function testLinksExtractor()
    {
        $parser = new \diplux\parser\Extractor();

        $testPairs = [
            [
                'text' =>
                    <<<CDATA
{{flatlist|* [[Singing|Singer]]
* [[dance]]r
* [[Model (people)|model]]
* [[Actor|actress]]
* [[Actor|actress]]
* [[Businessman|businesswoman]]}} 
CDATA
                ,
                'result' => [
                    'Actor',
                    'Businessman',
                    'Model (people)',
                    'Singing',
                    'dance',
                ]
            ],

        ];

        //we don't use loop here to navigate directly to failed test
        $i = 0;
        $this->assertEquals($testPairs[$i]['result'], $parser->extractLinks($testPairs[$i++]['text']), 'invalid links extraction');

    }

}

