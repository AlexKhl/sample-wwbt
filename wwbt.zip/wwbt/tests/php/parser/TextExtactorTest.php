<?php

require_once __DIR__ . "/../../../vendor/autoload.php";

final class TextExtactorTest extends \diplux\tests\DipluxTestCase
{

    public function testAlivingParser()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            'dead',
            $parser->extractAliving("Nais Lago (born 25 February 1914) was an Italian stage, film and television actress.")
            //http://localhost:8852/person/nais-lago-1914-02-25/
        );

        $this->assertTextEquals(
            'dead',
            $parser->extractAliving('David Earl McGill (born October 25, 1901) was a Canadian athlete who competed in the 5000 metres at the 1924 Summer Olympics')
        );

        $this->assertTextEquals(
            'alive',
            $parser->extractAliving('Max Webb (born March 2, 1917) is a Polish-born American real estate developer and philanthropist from Los Angeles, California. A Holocaust survivor, he is the co-founder of one of the largest real estate development companies in Southern California. He has supported charitable causes in the United States and Israel.')
        );

        $this->assertTextEquals(
            'dead',
            $parser->extractAliving('Wilson Connie Day (born December 30, 1897) was a Negro Leagues infielder for several years before the founding of the first Negro National League, and in its first few seasons.
')
        );

        $this->assertTextEquals(
            'dead',
            $parser->extractAliving('James Hezekiah Law (born December 28, 1899) was an American football coach. He was the second head football coach at Prairie View A&M University in Prairie View, Texas and he held that position for four seasons, from 1926 until 1929. His record at Prairie View was 20–9–5')
        );

        $this->assertTextEquals(
            'dead',
            $parser->extractAliving('Anderson Pryor (born July 14, 1900) was a Negro Leagues Second Baseman during the first Negro National League.
He played most of his seasons for the Detroit Stars.')
        );

    }

    public function testBioDatesParser()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            [
                'birth_date' => '1881-01-01',
                'death_date' => '1967-01-01'
            ],
            $parser->extractDatesFromBio("Harold \"Paddy\" Carolin (1881-1967) was a rugby union player who represented South Africa and is credited with conceiving both the 3-4-1 scrum formation and helping choose the name 'Springboks' for the South African national side. Carolin was the second player ever to serve as captain abroad, following Paul Roos.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1332-06-16',
                'death_date' => '1379-04-01'
            ],
            $parser->extractDatesFromBio("Isabella of England (16 June 1332 – c.April 1379), was the eldest daughter of King Edward III of England and Philippa of Hainault and the wife of Enguerrand de Courcy, Earl of Bedford, by whom she had two daughters. She was made a Lady of the Garter in 1376.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1851-02-26',
                'death_date' => '1931-01-31'
            ],
            $parser->extractDatesFromBio("Baron Slavko Cuvaj de Ivanska (26 February 1851, in Bjelovar – 31 January 1931, in Vienna) was a Croatian politician who was Ban (viceroy) of Croatia-Slavonia and royal commissioner for Austria-Hungary.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1851-01-01',
                'death_date' => '1920-01-01'
            ],
            $parser->extractDatesFromBio("Abram S. Isaacs (1851-1920) was an American rabbi, author, and professor. Isaacs received his education at the New York University, from which he was graduated in 1871")
        );

        $this->assertEquals(
            [
                'birth_date' => '1851-01-01',
                'death_date' => '1921-01-01'
            ],
            $parser->extractDatesFromBio("William Allison Sweeney (1851–1921) was an American newspaper writer, editor, and owner, poet, and author of a history of Afro-American soldiers in World War I.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1820-12-14',
                'death_date' => '1891-04-30'
            ],
            $parser->extractDatesFromBio("Abram Lyle (14 December 1820 – 30 April 1891) is noted for founding the sugar refiners Abram Lyle & Sons which merged with the company of his rival Henry Tate to become Tate & Lyle in 1921.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1907-11-21',
                'death_date' => '1976-01-01'
            ],
            $parser->extractDatesFromBio("Alfred Edward \"Alf\" Pattenden (21 November 1907 – 1976), also known as Kid Pattenden, was a British boxer who was British bantamweight champion between 1928 and 1929.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1888-04-20',
                'death_date' => '1947-03-18'
            ],
            $parser->extractDatesFromBio("Ibō Takahashi (高橋 伊望 Takahashi Ibō, April 20, 1888 – March 18, 1947) was an admiral in the Imperial Japanese Navy during World War II.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1917-04-08',
                'death_date' => '1991-06-01'
            ],
            $parser->extractDatesFromBio("Erwin Schädler (8 April 1917 – June 1991) was a German international footballer")
        );

        $this->assertEquals(
            [
                'birth_date' => '1907-07-23',
                'death_date' => '1984-04-29'
            ],
            $parser->extractDatesFromBio("Charles Bradfield Morrey Jr. (23 July 1907 – 29 April 1984) was an American mathematician who made fundamental contributions to the calculus of variations and the theory of partial differential equations.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1917-05-27',
                'death_date' => '1995-09-01'
            ],
            $parser->extractDatesFromBio("Gregorio Caloggero (27 May 1917 – September 1995) was a Peruvian cyclist. He competed in the individual and team road race events at the 1936 Summer Olympics")
        );

        $this->assertEquals(
            [
                'birth_date' => '1917-05-27',
                'death_date' => '1995-09-01'
            ],
            $parser->extractDatesFromBio("<p>Gregorio Caloggero (27 May 1917 – September 1995) was a Peruvian cyclist. He competed in the individual and team road race events at the 1936 Summer Olympics.</p>")
        );

        $this->assertEquals(
            [
                'birth_date' => '1917-01-26',
                'death_date' => '2010-11-07'
            ],
            $parser->extractDatesFromBio("<p>Kurt Baier (January 26, 1917 – November 7, 2010) was an Austrian moral philosopher who taught for most of his career in Australia and the United States.</p>")
        );

        $this->assertEquals(
            [
                'birth_date' => '1918-05-24',
                'death_date' => '1994-04-07'
            ],
            $parser->extractDatesFromBio("Cecil Hilton Monk Gould (24 May 1918 – 7 April 1994) was a British art historian and curator who specialised in Renaissance painting. He was a former Keeper and Deputy Director of the National Gallery in London.")
        );

        $this->assertEquals(
            [
                'birth_date' => '1921-11-01',
                'death_date' => '2000-08-01'
            ],
            $parser->extractDatesFromBio("Norman Dodgin (born 1 November 1921 in Gateshead - August 2000) was an English footballer who played between 1947 and 1955. His predominant position was at defence.

Dodgin became a player-manager in 1953 while playing for Exeter City, until his retirement from playing in 1955, at which point he became a full-time manager. He was also a manager at Barrow from 1957 to 1958, and at Oldham Athletic between 1958 and 1960.

Dodgin died in August 2000. Evidence of this can be found in the Family Records Centre BMD Index & the Rothmans Football Yearbook 2001/2002 Obituaries Page")
        );

    }

    public function testDeathDate()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            'April 13, 1960',
            $parser->extractDeathDate("{{Infobox officeholder
|name        = Muhammad Shahabuddin<br><small>محمد شہاب الدین</small>
|office      = [[Chief Justice of Pakistan]]
|appointer   = [[Ayub Khan (Field Marshal)|Ayub Khan]]
|term_start  = 3 May 1960
|term_end    = 12 May 1960
|predecessor = [[Muhammad Munir]]
|successor   = [[Alvin Robert Cornelius]]
|birth_date  = {{birth date|1895|5|13|df=y}}
|birth_place = 
|death_date  = April 13, 1960
|death_place = 
|alma_mater  = [[Madras Christian College|University of Madras]]<br>[[Dr. Ambedkar Government Law College, Chennai|Government Law College, Chennai]]
}}
'''Muhammad Shahabuddin''' ([[Urdu]]: '''محمد شہاب الدین''') was the Chief Justice of Pakistan and Governor of East Pakistan.

== Early life ==
Muhammad Shahabuddin was born on 13 May 1895 at [[Ellore]] in [[Madras]].  He graduated in Arts from [[Madras Christian College]] and in Law from ''Madras Law College''.<ref name=\":0\">{{Cite web|url=http://en.banglapedia.org/index.php?title=Shahabuddin,_Justice_Mohammad|title=Shahabuddin, Justice Mohammad – Banglapedia|website=en.banglapedia.org|access-date=2016-08-11}}</ref>
")
        );
    }

    public function testBioParser()
    {
        $parser = new \diplux\parser\Extractor();
        $this->assertEquals(
            "<p>Sir Joseph Dalton Hooker (30 June 1817 – 10 December 1911) was a British botanist and explorer in the 19th century. He was a founder of geographical botany and Charles Darwin's closest friend. For twenty years he served as director of the Royal Botanical Gardens, Kew, succeeding his father, William Jackson Hooker, and was awarded the highest honours of British science.</p>",
            $parser->extractBio("{{Use Australian English|date=February 2018}}
{{Use dmy dates|date=March 2013}}
{{Infobox scientist
| honorific_prefix = Sir
| name             = Joseph Dalton Hooker
|honorific_suffix = {{post-nominals|country=GBR|OM|GCSI|CB|PRS|size=100%}}
| image            = File:Joseph Dalton Hooker NLM3.jpg
| image_size       = 
| caption = Hooker in 1897
| birth_date       = {{birth date|df=yes|1817|6|30}}
| birth_place      = [[Halesworth]], [[Suffolk]], England
| death_date       = {{death date and age|1911|12|10|1817|6|30|df=y}}
| death_place      = [[Sunningdale]], [[Berkshire]], England
|nationality       = [[United Kingdom of Great Britain and Ireland|British]]
|alma_mater        = [[Glasgow University]] {{small|([[M.D.]], 1839)}}
|doctoral_advisor  =
|doctoral_students =
|known_for         =
|author_abbrev_bot =
|author_abbrev_zoo =
|influences        = [[William Jackson Hooker]]; [[Charles Darwin]]; [[George Bentham]]
|influenced        = [[William Thiselton-Dyer]]
|signature         = Joseph Dalton Hooker Signature.svg
|footnotes         =
|ethnicity         =
|field             = [[Botany]]
|work_institutions = [[Kew Gardens]]
|prizes            = {{unbulleted list
|[[Order of Merit]] {{small|(1907)}}
|[[Clarke Medal]] {{small|(1885)}}
|[[Order of the Star of India|Grand Cross Star of India]]
|[[Royal Society]]
|[[Copley Medal|Copley]] {{small|(1887)}}
|[[Darwin Medal]] {{small|(1892)}}
|[[Linnean Society]]
|[[Linnean Medal|Linnean]] {{small|(1888)}}
|[[Darwin–Wallace Medal]] {{small| (Silver, 1908)}}}}
|religion          =
}}

'''Sir Joseph Dalton Hooker''' {{post-nominals|country=GBR|OM|GCSI|CB|PRS}} (30 June 1817 – 10 December 1911) was a [[United Kingdom of Great Britain and Ireland|British]] [[botanist]] and [[explorer]] in the 19th century. He was a founder of geographical botany and [[Charles Darwin's]] closest friend. For twenty years he served as director of the [[Royal Botanical Gardens, Kew]], succeeding his father, [[William Jackson Hooker]], and was awarded the highest honours of British science.<ref>Huxley, Leonard 1918. ''Life and letters of Sir Joseph Dalton Hooker OM GCSI''. London, Murray.</ref><ref>Turrill W.B. 1963. ''Joseph Dalton Hooker: botanist, explorer and administrator''. Nelson, London.</ref>

==Biography==
[[File:Joseph Dalton Hooker by William Kilburn c1852.jpg|thumb|upright|Daguerreotype of Hooker by [[William Edward Kilburn]], circa 1852]]

===Early years===")
        );

        $this->assertEquals(
            "<p>Parillaud was born in Paris, France. While in school she studied ballet and her ambition was to become a lawyer, but a role during summer vacation – when she was only 16 – in Michel Lang's L'hôtel de la plage launched her into the world of film. She met director Luc Besson and married him in 1986, but the couple separated shortly after he directed her in Nikita. Nikita was an especially intense experience for Parillaud:</p><p><blockquote>\"For a while she was in me like a demon. I would do things I normally would not do. She was awkward, depressed, full of despair. But to me there was also a spiritual underline to Nikita. In a very excessive way she is a loudspeaker of the youth of society today. She destroys herself because she doesn't believe in anything on Earth.\"</p><p>In preparation for the role, she underwent three months of judo lessons and target practice to hone her skills as a government assassin: \"I hate guns, I hate violence, I hate judo.\" Her early ballet training also came in handy for one amusing scene though she modestly downplays her physical gifts, saying only, \"I have a chewing gum kind of body. I just forget about the bones.\" Despite the glamour and danger of her character, Parillaud cautions, \"It never happens to me, this kind of story.\"</blockquote></p><p>After the international success of Nikita, Parillaud left France to star in three films abroad: Map of the Human Heart, Innocent Blood, and Frankie Starlight. She has said regarding the experience of playing a vampire in John Landis's Innocent Blood:</p><p><blockquote>I fell in love with Marie in Innocent Blood because she wasn't born a vampire; she never decided she wanted to be. For me, it was a parable to talk about how you deal with this problem, which is when you are different. You think or you live or you want something different from everyone else. People don't follow you, because it's scary. You are quite alone in your choices.</blockquote></p><p>In 2010 she starred in the French psychological thriller In Their Sleep which was directed by Caroline du Potet and Eric du Potet.</p>",
            $parser->extractBio("{{Use dmy dates|date=December 2013}}

{{Infobox person
| name             = Anne Parillaud
| image            = Anne Parillaud Deauville 2014.jpg
| image_size       = 
| caption          = Parillaud in 2014
| birth_date       = {{Birth date and age|1960|5|6|df=y}}
| birth_place      = [[Paris]], [[France]]
| years_active     = 1977–present
| occupation       = Actress
| spouse           = {{marriage|[[Luc Besson]]|1986|1991}}<br>{{marriage|[[Jean Michel Jarre]]|2005|2010}}
| children         = 1
}}

'''Anne Parillaud''' ({{IPA-fr|an paʁiˈjo}}; born 6 May 1960) is a [[French people|French]] actress, who has appeared in 30 films since 1977.

She is best known internationally for her role as Nikita in the film ''[[Nikita (film)|Nikita]]''.<ref>{{cite web|url=http://www.dreadcentral.com/news/35306/four-clips-in-their-sleep-give-you-insomnia |title=Four Clips from in Their Sleep to Give You Insomnia |publisher=Dreadcentral.com |date= |accessdate=18 January 2011}}</ref>

==Biography==
Parillaud was born in [[Paris]], [[France]]. While in school she studied [[ballet]] and her ambition was to become a [[lawyer]], but a role during summer vacation – when she was only 16 – in [[Michel Lang]]'s ''[[Holiday Hotel|L'hôtel de la plage]]'' launched her into the world of film. She met director [[Luc Besson]] and married him in 1986, but the couple separated shortly after he directed her in ''[[Nikita (film)|Nikita]]''.<ref>{{cite web | url = http://www.dreadcentral.com/news/35774/new-stills-and-tiny-teaser-art-in-their-sleep |title=New Stills and Tiny Teaser Art: In Their Sleep |publisher= Dread Central |date= |accessdate= 18 January 2011}}</ref> ''Nikita'' was an especially intense experience for Parillaud:

{{quote |\"For a while she was in me like a demon. I would do things I normally would not do. She was awkward, depressed, full of despair. But to me there was also a spiritual underline to Nikita. In a very excessive way she is a loudspeaker of the youth of society today. She destroys herself because she doesn't believe in anything on Earth.\"

In preparation for the role, she underwent three months of judo lessons and target practice to hone her skills as a government assassin: \"I hate guns, I hate violence, I hate judo.\"  Her early ballet training also came in handy for one amusing scene though she modestly downplays her physical gifts, saying only, \"I have a chewing gum kind of body. I just forget about the bones.\"  Despite the glamour and danger of her character, Parillaud cautions, \"It never happens to me, this kind of story.\"}}

After the international success of ''Nikita,'' Parillaud left France to star in three films abroad: ''[[Map of the Human Heart]]'', ''[[Innocent Blood (film)|Innocent Blood]],'' and ''[[Frankie Starlight]]''. She has said regarding the experience of playing a vampire in [[John Landis]]'s ''Innocent Blood'':

{{quote |I fell in love with Marie in ''Innocent Blood'' because she wasn't born a vampire; she never decided she wanted to be. For me, it was a parable to talk about how you deal with this problem, which is when you are different.  You think or you live or you want something different from everyone else. People don't follow you, because it's scary.  You are quite alone in your choices.}}

In 2010 she starred in the French psychological thriller ''[[Dans ton sommeil|In Their Sleep]]''<ref>{{cite web|url= http://www.dreadcentral.com/news/36284/international-trailer-debut-french-chiller-in-their-sleep |title=International Trailer Debut for French Chiller in Their Sleep | publisher = Dread central | date = | accessdate = 18 January 2011}}</ref> which was directed by Caroline du Potet and Eric du Potet.<ref>{{cite web|url=http://www.dreadcentral.com/news/37099/new-sales-art-in-their-sleep | title = New Artwork: In Their Sleep | publisher = Dread central | date = 21 April 2010 | accessdate = 18 January 2011}}</ref>

==Personal life==")
        );

        $this->assertEquals(
            "<p>Helen Murray Free (born February 20, 1923, Pittsburgh, PA) is a retired American chemist and educator. She received a B.A. in chemistry from The College of Wooster in 1944 and an M.A. in management from Central Michigan University in 1978. In 1947 she married Alfred Free, a fellow researcher in urinalysis. She is most known for her creation of many self-testing systems for diabetes while working at Miles Laboratories, which is now Ascensia Diabetes Care. She currently is an Adjunct Professor of Management at Indiana University South Bend, and a Consultant for Bayer AG.</p>",
            $parser->extractBio("{{Infobox scientist
| name                    = Helen Murray Free
| image                   = 
| caption                 = 
| birth_date              = {{birth date and age|1923|2|20}}
| birth_place             = [[Pittsburgh, Pennsylvania]]
| nationality             = [[United States|American]] 
| field                   = Chemistry
| alma_mater              = [[The College of Wooster]]<br/>[[Central Michigan University]]
| known_for               = Self-Testing Systems for Diabetes
| awards                  = {{no wrap|[[Garvan–Olin Medal]] {{small|(1980)}}<br>[[Kilby International Awards|Kilby Award]] <small>(1996)</small><br />[[National Inventors Hall of Fame]] <small>(2000)</small><br />[[National Medal of Technology and Innovation]] <small>(2009)</small>}}
}}

    '''Helen Murray Free''' (born February 20, 1923, Pittsburgh, PA) is a retired American chemist and educator.  She received a B.A. in chemistry from [[The College of Wooster]] in 1944 and an M.A. in management from [[Central Michigan University]] in 1978.  In 1947 she married [[Alfred Free]], a fellow researcher in urinalysis.  She is most known for her creation of many self-testing systems for diabetes while working at [[Miles Laboratories]], which is now [http://www.ascensia.com/ Ascensia Diabetes Care].  She currently is an Adjunct Professor of Management at [[Indiana University South Bend]], and a Consultant for Bayer AG.<ref name=CHFOralHistory/>
    
    ==Biography==
    [[File:National Medals Org Helen M Free 2009.JPG|thumb|250px|right|Helen Free receiving the National Medal of Technology and Innovation from President Obama, 2009. [http://www.nationalmedals.org/about/contact_thanks.php National Science and Technology Medals Foundation, Photograph by Ryan K. Morris]]]
    
    ===Early life===")
        );

        $this->assertEquals(
            "<p>Urbain Jean Joseph Le Verrier ( 11 March 1811 – 23 September 1877) was a French mathematician who specialized in celestial mechanics and is best known for predicting the existence and position of Neptune using only mathematics. The calculations were made to explain discrepancies with Uranus's orbit and the laws of Kepler and Newton. Le Verrier sent the coordinates to Johann Gottfried Galle in Berlin, asking him to verify. Galle found Neptune in the same night he received Le Verrier's letter, within 1° of the predicted position. The discovery of Neptune is widely regarded as a dramatic validation of celestial mechanics, and is one of the most remarkable moments of 19th-century science.</p>",
            $parser->extractBio("{{redirect|Le Verrier|other uses|Le Verrier (disambiguation)}}
{{Infobox scientist
|name              = Urbain Le Verrier
|image             = Urbain Le Verrier.jpg
|image_size        =
|caption           =
|birth_date        = {{birth date|1811|03|11|df=y}}
|birth_place       = [[Saint-Lô]], France
|death_date        = {{Death date and age|1877|09|23|1811|03|11|df=y}}
|death_place       = Paris, France
|nationality       = French
|field             = Mathematics
|work_institutions =
|alma_mater        =
|doctoral_advisor  =
|doctoral_students =
|known_for         = [[Discovery of Neptune]]
|author_abbrev_bot =
|author_abbrev_zoo =
|influences        =
|influenced        =
|prizes            =
|religion          =
|footnotes         =
|signature         =
}}
'''Urbain Jean Joseph Le Verrier''' ({{IPA-fr|yʁbɛ̃ ʒɑ̃ ʒɔzɛf lə vɛʁje|lang}}; 11 March 1811 – 23 September 1877) was a French mathematician who specialized in [[celestial mechanics]] and is best known for predicting the existence and position of [[Neptune]] using only [[mathematics]]. The calculations were made to explain discrepancies with [[Uranus]]'s [[orbit]] and the [[physical law|laws]] of [[Johannes Kepler|Kepler]] and [[Isaac Newton|Newton]]. Le Verrier sent the coordinates to [[Johann Gottfried Galle]] in Berlin, asking him to verify. Galle found Neptune in the same night he received Le Verrier's letter, within 1° of the predicted position. The [[discovery of Neptune]] is widely regarded as a dramatic validation of [[celestial mechanics]], and is one of the most remarkable moments of 19th-century science.

==Biography==
[[File:P1010920 Paris XIV Obervatoire de Paris Statue de Le Verrier reductwk.JPG |thumb|Statue of LeVerrier at the Paris Observatory]]

===Early years===")
        );

        $this->assertEquals(
            "<p>Thomas Buck Reed (May 7, 1787 – November 26, 1829) was a United States Senator from Mississippi.</p>",
            $parser->extractBio("{{Infobox Officeholder
|name                = Thomas Buck Reed
|image = Thomas Buck Reed.jpg
|office = [[Attorney General of Mississippi]]
|term_start1 = 1821
|term_end1 = 1825
|predecessor1 = [[Edward Turner]]
|successor1 = [[Richard Stockton (attorney)|Richard Stockton]]
|jr/sr2             = United States Senator
|state2              = [[Mississippi]]
|term_start2          = January 28, 1826
|term_end2           = March 4, 1827
|predecessor2         = [[Powhatan Ellis]]
|successor2           = [[Powhatan Ellis]]
|term_start3 = March 4, 1829
|term_end3 = November 26, 1829
|predecessor3 = [[Thomas Hill Williams|Thomas H. Williams]]
|successor3 = [[Robert H. Adams]]
|birth_date         = {{birth date|1787|5|7}}
|birth_place        = [[Lexington, Kentucky|Lexington]], [[Kentucky]]
|death_date         = {{death date and age|1829|11|26|1787|5|7}}
|death_place        = [[Lexington, Kentucky|Lexington]], [[Kentucky]]
|party               = [[Jacksonian democracy|Jacksonian]]
}}
'''Thomas Buck Reed''' (May 7, 1787{{spaced ndash}}November 26, 1829) was a [[United States Senator]] from [[Mississippi]].

==Biography==
[[File:Linden, Natchez, Adams County, Mississippi.jpg|thumb|left|Linden, by Frances Benjamin Johnston, 1938. Builder is not known but Thomas B. Reed is known as the first occupant. In 1840, Linden was purchased by Mrs. Janr Gustine Connor, great grandmother of present owner]]

===Early life===")
        );

        $this->assertEquals(
            '<p>Senta Berger ( born 13 May 1941) is an Austrian film, stage and television actress, producer and author. She received many award nominations for her acting in theatre, film and television; her awards include three Bambi Awards, two Romys, an Adolf Grimme Award, both a Deutscher and a Bayerischer Fernsehpreis, and a Goldene Kamera.</p>',
            $parser->extractBio("{{Use dmy dates|date=September 2015}}
{{BLP sources|date=March 2013}}
{{Infobox person
| name           = Senta Berger
| image          = Senta Berger 1975.jpg
| image_size     = 
| caption        = Berger in 1975
| birth_name     = 
| birth_date     = {{Birth date and age|df=yes|1941|5|13}}
| birth_place    = [[Vienna, Austria]]
| death_date     = 
| death_place    = 
| other_names    = 
| years_active   = 1955–present
| occupation     = [[Actress]], [[Film producer|producer]], author
| spouse         = {{marriage|[[Michael Verhoeven]] <br>|1966}}
| children       = 2, including [[Simon Verhoeven]]}}

'''Senta Berger''' ({{IPA-de|ˈzɛnta ˈbɛʁɡɐ|-|De-at Senta Berger.ogg}}; born 13 May 1941) is an [[Austria]]n film, stage and television actress, producer and author. She received many award nominations for her acting in theatre, film and television; her awards include three [[Bambi (prize)|Bambi Awards]], two [[Romy (TV award)|Romys]], an [[Adolf Grimme Award]], both a [[Deutscher Fernsehpreis|Deutscher]] and a [[Bayerischer Fernsehpreis]], and a [[Goldene Kamera]].

==Early life==")
        );

        $this->assertEquals(
            '<p>Joan de Beauvoir de Havilland (October 22, 1917 – December 15, 2013), known professionally as Joan Fontaine, was a British-American actress best known for her starring roles in Hollywood films. Fontaine appeared in more than 45 feature films in a career that spanned five decades. She was the younger sister of actress Olivia de Havilland.</p><p>Born in Tokyo to British parents, Fontaine moved to California with her mother, Lilian Fontaine, and sister, the actress Olivia de Havilland, following her parents\' divorce. She was anaemic as a child, and her childhood was consequently marred by poor health, but she had improved by her teen years. After living in Japan and attending school there for a short while, she began her stage career in 1935, signing a film contract with RKO Pictures. Fontaine received her first major role in The Man Who Found Himself (1937); however, she failed to make a significant impression and her contract was not renewed.</p><p>Her career prospects improved greatly after her starring role in the Alfred Hitchcock-directed Rebecca (1940), for which she received the first of what would be three nominations for the Academy Award for Best Actress; the following year, she won for her role in Suspicion (1941). A third Oscar nomination came with the film The Constant Nymph. She appeared mostly in drama films through the 1940s—including Letter from an Unknown Woman, which is now considered a classic. In the next decade, her career began to decline and she moved into stage and television roles. She appeared in fewer films into the 1960s, her final feature film being The Witches (1966).</p><p>Fontaine was active in radio, television, and the stage for most of her middle to later life. She released an autobiography, No Bed of Roses, in 1978; she continued to act until her last performance in 1994. Fontaine lived in Carmel Highlands, California, where she owned a home, Villa Fontana. She died there of natural causes at the age of 96 in 2013. Having won an Academy Award for her role in Suspicion, Fontaine is the only actor to have won an Academy Award for acting in a Hitchcock film. Furthermore, she and her sister remain the only siblings to have won major acting Academy Awards.</p><p>Married four times, she had one child by birth and one child by adoption, from whom she was later estranged. Her relationship with her sister was long known to be acrimonious, and included long periods of estrangement, especially in later life.</p>',
            $parser->extractBio("{{Use American English|date=January 2018}}
{{Use mdy dates|date=January 2018}}
{{Infobox person
| name                      = Joan Fontaine
| image                     = Joan Fontaine 1951.jpg
| image_size                =
| alt                       =
| caption                   = Fontaine in 1951
| birth_name                = Joan de Beauvoir de{{nbsp}}Havilland
| birth_date                =  {{Birth date|1917|10|22|}}
| birth_place               = [[Tokyo]], Japan
| death_date                = {{death date and age|2013|12|15|1917|10|22|}}
| death_place               = [[Carmel Highlands, California]], U.S.
| other_names               = {{ubl|Joan Burfield|Joan St. John}}
| ethnicity                 =
| citizenship               = {{ubl|[[United Kingdom]]|[[United States]]<ref>Weatherford 2010, p. 302.</ref>}}
| education                 = {{ubl|[[Tokyo School for Foreign Children]]|[[Los Gatos High School]]}}
| alma_mater                =
| occupation                = Actress
| years_active              = 1935{{ndash}}1994
| known_for                 =
| spouse                    = {{ubl|{{marriage|[[Brian Aherne]]<br>|1939|1945|reason=divorced}}|{{marriage|[[William Dozier]]<br>|1946|1951|reason=divorced}}|{{marriage|[[Collier Young]]<br>|1952|1961|reason=divorced}}|{{marriage|Alfred Wright Jr.<br>|1964|1969|reason=divorced}}}}
| children                  = 2
| parents                   = {{Plainlist|
* [[Walter de Havilland]]
* [[Lilian Fontaine]]
}}
| relatives                 = [[Olivia de Havilland]] <small>(sister)</small>
| awards                    = [[Academy Award for Best Actress]] (1941)}}
'''Joan de Beauvoir de Havilland''' (October 22, 1917 &ndash; December 15, 2013), known professionally as '''Joan Fontaine''', was a British-American actress best known for her starring roles in [[Hollywood]] films. Fontaine appeared in more than 45 feature films in a career that spanned five decades. She was the younger sister of actress [[Olivia de Havilland]].

Born in [[Tokyo]] to British parents, Fontaine moved to [[California]] with her mother, [[Lilian Fontaine]], and sister, the actress [[Olivia de Havilland]], following her parents' divorce. She was [[Anemia|anaemic]] as a child, and her childhood was consequently marred by poor health, but she had improved by her teen years. After living in Japan and attending school there for a short while, she began her stage career in 1935, signing a film contract with [[RKO Pictures]]. Fontaine received her first major role in ''[[The Man Who Found Himself]]'' (1937); however, she failed to make a significant impression and her contract was not renewed.{{citation needed|date=August 2016}}

Her career prospects improved greatly after her starring role in the [[Alfred Hitchcock]]-directed ''[[Rebecca (1940 film)|Rebecca]]'' (1940), for which she received the first of what would be three nominations for the [[Academy Award for Best Actress]]; the following year, she won for her role in ''[[Suspicion (1941 film)|Suspicion]]'' (1941). A third Oscar nomination came with the film ''[[The Constant Nymph (1943 film)|The Constant Nymph]]''. She appeared mostly in drama films through the 1940s—including ''[[Letter from an Unknown Woman (1948 film)|Letter from an Unknown Woman]]'', which is now considered a classic. In the next decade, her career began to decline and she moved into stage and television roles. She appeared in fewer films into the 1960s, her final feature film being ''[[The Witches (1966 film)|The Witches]]'' (1966).

Fontaine was active in radio, television, and the stage for most of her middle to later life. She released an autobiography, ''No Bed of Roses'', in 1978; she continued to act until her last performance in 1994. Fontaine lived in [[Carmel Highlands, California]], where she owned a home, Villa Fontana. She died there of natural causes at the age of 96 in 2013. Having won an Academy Award for her role in ''Suspicion'', Fontaine is the only actor to have won an Academy Award for acting in a Hitchcock film. Furthermore, she and her sister remain the only [[List of Academy Award-winning families|siblings to have won major acting Academy Awards]].

Married four times, she had one child by birth and one child by adoption, from whom she was later estranged. Her relationship with her sister was long known to be acrimonious, and included long periods of estrangement, especially in later life.

{{TOC limit|limit=2}}

== Early life ==")
        );

        $this->assertEquals('<p>Paz Garcia was born in 1932 in La Arada, Goascoran, Valle, Honduras. He distinguished himself in the Football War, a brief war fought by El Salvador and Honduras in 1969.</p><p>Following a 1978 military coup that ousted General Juan Alberto Melgar as chief of state, a three-man junta headed by Paz Garcia took power and announced that it would begin preparations for a return to civilian rule. A constituent assembly was popularly elected in April 1980 to write a new constitution, and on July 20, 1980 the junta handed control to the Assembly.</p><p>The Assembly appointed General Paz Garcia provisional president until general elections were held. The elections, in November 1981, were won by Roberto Suazo, and his Liberal Party of Honduras.</p><p>Paz died on 16 April 2000 at age 67, due to kidney failure.</p>',
            $parser->extractBio("{{Use dmy dates|date=July 2013}}
{{Infobox Officeholder
| honorific-prefix = 
| name = Policarpo Paz García
| image = Policarpo Paz Garcia.jpg
| imagesize = 
| caption = Sketch of Policarpo Paz García
| order = 
| office = 46th [[President of Honduras]]
| term_start = 7 August 1978
| term_end = 27 January 1982
| predecessor = [[Juan Alberto Melgar Castro]] <br> <small>(Head of State)</small>
| successor = [[Roberto Suazo Córdova]]
| order2 = [[Military of Honduras]]
| term_start2 = 7 August 1978
| term_end2 = 27 January 1980
| predecessor2 = Juan Alberto Melgar Castro
| successor2 = [[Gustavo Álvarez Martínez]]
| birth_name = Policarpo Juan Paz García
| birth_date = {{birth date|df=yes|1932|12|7}}
| birth_place = [[Goascorán]], [[Honduras]]
| death_date = {{death date and age|df=yes|2000|4|16|1932|12|7}}
| death_place = [[Tegucigalpa]], Honduras
| nationality = Honduran
| profession = Physician, Politician
| party = Military
| spouse = Carlota Márquez de Paz García
| religion = Roman Catholic
| alma_mater = Escuela Militar de Honduras
| signature =
}}

'''Policarpo Juan Paz García''' (7 December 1932 – 16 April 2000) was a [[Honduras|Honduran]] military leader who served as [[President of Honduras]] from 7 August 1978 until 27 January 1982.

==Biography==
Paz Garcia was born in 1932 in [[La Arada]], [[Goascoran]], [[Valle department|Valle]], [[Honduras]]. He distinguished himself in the [[Football War]], a brief war fought by El Salvador and Honduras in 1969.<ref>[https://global.britannica.com/biography/Policarpo-Paz-Garcia|Encyclopedia Brittancia, \"Policarpo Paz-Garcia\"]</ref>

Following a 1978 military coup that ousted General [[Juan Alberto Melgar Castro|Juan Alberto Melgar]] as chief of state, a three-man junta headed by Paz Garcia took power and announced that it would begin preparations for a return to civilian rule. A constituent assembly was popularly elected in April 1980 to write a new constitution, and on July 20, 1980 the junta handed control to the Assembly.<ref>[http://uca.edu/politicalscience/dadm-project/western-hemisphere-region/honduras-1902-present/ \"Honduras, 1902-present]</ref>

The Assembly appointed General Paz Garcia provisional president until general elections were held. The elections, in November 1981, were won by [[Roberto Suazo Córdova|Roberto Suazo]], and his [[Liberal Party of Honduras]].

Paz died on 16 April 2000 at age 67, due to [[kidney failure]].

==References=="));

        $this->assertEquals(
            '<p>James Hillier Blount (born 22 February 1974), better known by his stage name James Blunt, is an English singer-songwriter and former British Army Officer. He originally signed to EMI Music Publishing and is currently signed to Custard Records and Atlantic Records.</p><p>Blunt rose to fame in 2004 with the release of his debut album Back to Bedlam, achieving worldwide fame with the singles "You\'re Beautiful" and "Goodbye My Lover". The album has sold over 11 million copies worldwide, topping the UK Albums Chart and peaking at number two in the US. "You\'re Beautiful" was number one in the UK, the US and a dozen other countries. Back to Bedlam was the best-selling album of the 2000s in the UK.</p><p>Blunt has sold over 20 million records worldwide. He has received several awards, including two Brit Awards—winning Best British Male in 2006—two MTV Video Music Awards and two Ivor Novello Awards, as well as receiving five Grammy Award nominations.</p><p>Blunt was a reconnaissance officer in the Life Guards, a cavalry regiment of the British Army, and served under NATO in the Kosovo War in 1999. He was awarded an Honorary Doctorate for Music in 2016 by University of Bristol.</p>',
            $parser->extractBio('\'\'\'James Hillier Blount\'\'\'<!-- NB - the family name is correctly spelled \'Blount\' - this is not a typo. --> (born 22 February 1974),<ref>National Archives, England & Wales, Birth Index: 1916–2005 volume 6b, page 446 confirms birth as Q1, 1974.</ref> better known by his stage name \'\'\'James Blunt\'\'\', is an English singer-songwriter and former British Army Officer. He originally signed to [[EMI Music Publishing]] and is currently signed to [[Custard Records]] and [[Atlantic Records]].

Blunt rose to fame in 2004 with the release of his debut album \'\'[[Back to Bedlam]]\'\', achieving worldwide fame with the singles "[[You\'re Beautiful]]" and "[[Goodbye My Lover]]". The album has sold over 11 million copies worldwide, topping the [[UK Albums Chart]] and peaking at number two in the US. "You\'re Beautiful" was number one in the UK, the US and a dozen other countries. \'\'Back to Bedlam\'\' was [[List of best-selling albums of the 2000s (decade) in the United Kingdom|the best-selling album of the 2000s in the UK]].<ref>{{cite web|url=https://www.theguardian.com/music/2009/dec/30/james-blunt-top-album|title=James Blunt makes decade\'s best-selling album|publisher=The Guardian|author=Sean Michaels|accessdate=23 October 2013}}</ref>

Blunt has sold over 20 million records worldwide.<ref>{{cite web|last=Reeves |first=Verity |url=http://www.express.co.uk/news/showbiz/438308/James-Blunt-The-Marmite-ndustry |title=James Blunt: The Marmite of the pop industry is back and he means business &#124; Showbiz &#124; News &#124; Daily Express |publisher=Express.co.uk |date=2013-10-21 |accessdate=2014-08-06}}</ref><ref>{{cite web|author= |url=http://www.ilkestonadvertiser.co.uk/what-s-on/out-about/blunt-heads-back-to-basics-again-1-6605388 |title=Blunt heads back to basics again |publisher=Ilkeston Advertiser |date=2014-05-12 |accessdate=2014-08-06}}</ref> He has received several awards, including two [[Brit Awards]]—winning Best British Male in 2006—two [[MTV Video Music Awards]] and two [[Ivor Novello Awards]], as well as receiving five [[48th Annual Grammy Awards|Grammy Award nominations]].

Blunt was a reconnaissance officer in the [[Life Guards (British Army)|Life Guards]], a [[Cavalry regiments of the British Army|cavalry regiment of the British Army]], and served under [[NATO]] in the [[Kosovo War]] in 1999. He was awarded an Honorary Doctorate for Music in 2016 by [[University of Bristol]].

==Early life and education=='));

        $this->assertEquals(
            '<p>Kazimir Severinovich Malevich (February 23, 1878 – May 15, 1935) was a Russian painter and art theoretician. He was a pioneer of geometric abstract art and the originator of the avant-garde Suprematist movement. He was a devout Christian mystic who believed the central task of an artist was that of rendering spiritual feeling.</p>',
            $parser->extractBio('\'\'\'Kazimir Severinovich Malevich\'\'\'{{#tag:ref|{{lang-ru|Казими́р Севери́нович Мале́вич}} {{IPA-ru|kəzʲɪˈmʲir sʲɪvʲɪˈrʲinəvʲɪtɕ mɐˈlʲevʲɪtɕ|}}, {{lang-pl|Kazimierz Malewicz}}, {{lang-uk|Казимир Северинович Малевич}} {{IPA-uk|kazɪˈmɪr sɛwɛˈrɪnɔwɪtʃ mɑˈlɛwɪtʃ|}}, {{lang-be|Казімер Сэвэрынавіч Малевіч}} {{IPA-be|kaziˈmʲer sɛwɛrˈɪnawʲitʃ mɑˈlɛwitʃ|}}, {{lang-de|Kasimir Malewitsch}}|group=nb}} (February 23, 1878 – May 15, 1935) was a [[Russian Empire|Russian]] painter and art [[:wikt:theoretician|theoretician]].<ref name="Schwartz p. 84">Milner and Malevich 1996, p. X; Néret 2003, p. 7; Shatskikh and Schwartz, p. 84.</ref> He was a pioneer of [[geometric abstraction|geometric abstract art]] and the originator of the [[avant-garde]] [[Suprematism|Suprematist]] movement.<ref>{{Britannica|360045|Kazimir Malevich}}</ref><ref>{{cite web|url=http://www.encyclopedia.com/topic/Kazimir_Severinovich_Malevich.aspx |title=Malevich, Kasimir — A Dictionary of Twentieth-Century Art |publisher=Encyclopedia.com |date= |accessdate=2014-03-18}}</ref><ref>{{cite web|url=http://www.encyclopedia.com/doc/1E1-Malevich.html |title=Casimir Malevich — The Columbia Encyclopedia, Sixth Edition |publisher=Encyclopedia.com |date= |accessdate=2014-03-18}}</ref> He was a devout Christian mystic who believed the central task of an artist was that of rendering spiritual feeling.<ref>{{cite book|last1=Chave|first1=Anna|title=Mark Rothko: Subjects in Abstraction|publisher=Yale University Press|page=191}}</ref><ref>{{cite book|last1=hamilton|first1=george|title=Painting and Sculpture in Europe, 1880-1940, Volume 29|publisher=Yale University Press}}</ref>

==Early life==
'));

        $this->assertEquals(
            '<p>Juliana Hatfield (born July 27, 1967) is an American musician and singer-songwriter from the Boston area, formerly of the indie rock bands Blake Babies, The Juliana Hatfield Three, Some Girls, and The Lemonheads. She\'s best known for several singles released in the 1990s, including the alternative hit "My Sister."</p><p>Hatfield has also performed and recorded as a solo artist and as one half of Minor Alps alongside Matthew Caws of Nada Surf. In December 2014, Paste Magazine named her cover of the song "Needle in the Hay" by Elliott Smith as number 10 in a list of the "20 Best Cover Songs of 2014."</p><p>In 2014, she reformed The Juliana Hatfield Three, announcing the new album Whatever, My Love for 2015. In late December, Stereogum named the album "one of their most anticipated albums of 2015," and on January 4, 2015, Consequence of Sound named it "one of the 50 most anticipated albums of 2015." The band toured the US in February and March 2015 in support of the album.</p>',
            $parser->extractBio("'''Juliana Hatfield''' (born July 27, 1967) is an American musician and singer-songwriter from the [[Boston]] area, formerly of the [[indie rock]] bands [[Blake Babies]], '''The Juliana Hatfield Three,''' [[Some Girls (band)|Some Girls]],<ref name=SPIN-OralHistory>{{cite news |last=Grow |first=Kory |title=She's Such a Bitch: The Oral History of Juliana Hatfield Three's 'My Sister' |url=http://www.spin.com/articles/juliana-hatfield-three-my-sister-history-violent-femmes-del-fuegos/ |accessdate=November 2, 2013 |newspaper=SPIN Magazine |date=August 28, 2013}}</ref> and [[The Lemonheads]]. She's best known for several singles released in the 1990s, including the alternative hit \"My Sister.\"

Hatfield has also performed and recorded as a solo artist and as one half of [[Get There (Minor Alps album)|Minor Alps]] alongside [[Matthew Caws]] of [[Nada Surf]]. In December 2014, ''[[Paste Magazine]]'' named her cover of the song \"[[Needle in the Hay]]\" by [[Elliott Smith]] as number 10 in a list of the \"20 Best Cover Songs of 2014.\"<ref name=\"alrnewfpaste\" />

In 2014, she reformed The Juliana Hatfield Three, announcing the new album ''[[Whatever, My Love]]'' for 2015. In late December, ''[[Stereogum]]'' named the album \"one of their most anticipated albums of 2015,\"<ref name=\"alrnewc\" /> and on January 4, 2015, ''[[Consequence of Sound]]'' named it \"one of the 50 most anticipated albums of 2015.\"<ref name=\"alrnewbcos\" /> The band toured the US in February and March 2015 in support of the album.<ref name=\"alrnewamxdown\" />{{better source|date=November 2016}}")
        );


        $this->assertEquals(
            '<p>Georgy Stepanovich Shonin (August 3, 1935 – April 7, 1997; born in Rovenky, Luhansk Oblast, (now Ukraine) but grew up in Balta of Ukrainian SSR) was a Soviet cosmonaut, who flew on the Soyuz 6 space mission.</p><p>Shonin was part of the original group of cosmonauts selected in 1960. He left the space programme in 1979 for medical reasons.</p><p>Shonin\'s family hid a Jewish family from the Nazis during WWII.</p><p>Shonin later worked as the director of the 30th Central Scientific Research Institute, Ministry of Defence (Russia).</p><p>He died of a heart attack in 1997.</p><p>He was awarded:</p><p>Hero of the Soviet Union</p><p>Pilot-Cosmonaut of the USSR</p><p>Order of Lenin</p><p>Order of the October Revolution</p><p>Order of the Red Banner of Labour</p><p>Order of the Red Star</p><p>Ten commemorative medals</p><p>Medal "25 Years of People\'s Power" (Bulgaria)</p><p>Three medals from the Mongolian People\'s Republic</p><p>Five medals from the Czechoslovak Socialist Republic</p>',
            $parser->extractBio("{{Refimprove|date=March 2017}}
{{Infobox astronaut
| name =Georgy Stepanovich Shonin
| image =The Soviet Union 1969 CPA 3809 stamp (Georgi Shonin and Valeri Kubasov (Soyuz 6)) cropped Shonin.jpg
| type =Cosmonaut
| nationality =[[Soviet Union|Soviet]]
|birth_date    ={{Birth date|1935|8|3}}
|death_date    ={{Death date and age|1997|4|7|1935|8|3}}
| birth_place =[[Rovenky]], [[Soviet Union]] (now [[Ukraine]])
| death_place =[[Zvyozdny gorodok (urban-type settlement)|Zvyozdny]], Russia
| occupation =[[Aviator|Pilot]]
| rank =[[Lieutenant General]], [[Soviet Air Force]]
| selection =[[List of astronauts by selection#1960|Air Force Group 1]]
| time =4d 22h 42m
| mission =[[Soyuz 6]]
| insignia =
|}}
'''Georgy Stepanovich Shonin''' ({{Lang-uk|Гео́ргій Степа́нович Шо́нін}}) (August 3, 1935 – April 7, 1997; born in [[Rovenky]], [[Luhansk Oblast]], (now [[Ukraine]]) but grew up in [[Balta, Ukraine|Balta]] of [[Ukrainian SSR]]) was a [[Soviet Union|Soviet]] [[cosmonaut]], who flew on the [[Soyuz 6]] [[manned space mission|space mission]].

Shonin was part of the original group of cosmonauts selected in 1960. He left the space programme in 1979 for medical reasons.

Shonin's family hid a [[Jewish]] family from the [[Nazi]]s during WWII.<ref>http://www.jpress.nli.org.il/Olive/APA/NLI_heb/SharedView.Article.aspx?href=MAR%2F1969%2F10%2F20&id=Ar01000&sk=E6842B9F</ref>

Shonin later worked as the director of the [[30th Central Scientific Research Institute, Ministry of Defence (Russia)]].

He died of a heart attack in 1997.

He was awarded:
* [[Hero of the Soviet Union]]
* [[Pilot-Cosmonaut of the USSR]]
* [[Order of Lenin]]
* [[Order of the October Revolution]]
* [[Order of the Red Banner of Labour]]
* [[Order of the Red Star]]
* Ten commemorative medals
* Medal \"25 Years of People's Power\" (Bulgaria)
* Three medals from the Mongolian People's Republic
* Five medals from the Czechoslovak Socialist Republic
")
        );

        $this->assertEquals(
            '<p>Stephen D. Crocker (born October 15, 1944, in Pasadena, California) is the inventor of the Request for Comments series, authoring the very first RFC and many more. He received his bachelor\'s degree (1968) and PhD (1977) from the University of California, Los Angeles. Crocker is chair of the board of the Internet Corporation for Assigned Names and Numbers, ICANN.</p><p>Steve Crocker has worked in the Internet community since its inception. As a UCLA graduate student in the 1960s, he was part of the team that developed the protocols for the ARPANET which were the foundation for today\'s Internet. For this work, Crocker was awarded the 2002 IEEE Internet Award.</p><p>While at UCLA Crocker taught an extension course on computer programming (for the IBM 7094 mainframe computer). The class was intended to teach digital processing and assembly language programming to high school teachers, so that they could offer such courses in their high schools. A number of high school students were also admitted to the course, to ensure that they would be able to understand this new discipline. Crocker was also active in the newly formed UCLA Computer Club.</p><p>Crocker has been a program manager at Defense Advanced Research Projects Agency (DARPA), a senior researcher at USC\'s Information Sciences Institute, founder and director of the Computer Science Laboratory at The Aerospace Corporation and a vice president at Trusted Information Systems. In 1994, Crocker was one of the founders and chief technology officer of CyberCash, Inc. In 1998, he founded and ran Executive DSL, a DSL-based ISP. In 1999 he cofounded and was CEO of Longitude Systems. He is currently CEO of Shinkuro, a research and development company.</p><p>Steve Crocker was instrumental in creating the ARPA "Network Working Group", which later was the context in which the IETF was created.</p><p>He has also been an IETF security area director, a member of the Internet Architecture Board, chair of the ICANN Security and Stability Advisory Committee, a board member of the Internet Society and numerous other Internet-related volunteer positions.</p><p>In 2012, Crocker was inducted into the Internet Hall of Fame by the Internet Society.</p>',
            $parser->extractBio("{{Infobox person
| name          = Stephen D. Crocker
| image         = Steve Crocker (square crop).jpg
| alt           = <!-- descriptive text for use by speech synthesis (text-to-speech) software -->
| caption       = Steve Crocker in 2005
| birth_date         =  {{birth date and age|1944|10|15}}
| birth_place   = 
| death_date    = <!-- {{Death date and age|YYYY|MM|DD|YYYY|MM|DD}} (death date then birth date)  -->
| death_place   =
| nationality   = United States
| other_names   = 
| occupation    = Internet engineer
| years_active  = 
| known_for     = 
| notable_works = 
}}
[[Image:SteveCrockerJI1.jpg|right|thumb|Steve Crocker]]
'''Stephen D. Crocker''' (born October 15, 1944, in [[Pasadena, California]]) is the inventor of the [[Request for Comments]] series,<ref>\"I Remember IANA\", V. Cerf, RFC 2468, October 17, 1998.</ref> authoring the very first RFC<ref>Host Software, S. Crocker, RFC 0001, April 1969.</ref> and many more.<ref>[http://www.ietf.org/download/rfc-index.txt \"RFC Index\"], Internet Engineering Task Force. Retrieved 14 September 2013.</ref>  He received his [[bachelor's degree]] (1968) and [[PhD]] (1977) from the [[University of California, Los Angeles]].<ref>{{cite web|url=http://www.magazine.ucla.edu/year1997/fall97_03.html|title=Wired!|author=Matthew Lyon|publisher=UCLA Magazine|date=Fall 1997}}</ref> Crocker is chair of the board of the Internet Corporation for Assigned Names and Numbers, [[ICANN]].<ref>{{cite web|url=http://www.icann.org/en/announcements/announcement-1-24jun11-en.htm|title=ICANN news release|date=June 2011}}</ref>

Steve Crocker has worked in the Internet community since its inception.  As a UCLA graduate student in the 1960s, he was part of the team that developed the protocols for the [[ARPANET]] which were the foundation for today's [[Internet]].<ref>[http://internethalloffame.org/inductees/steve-crocker \"Official Biography: Steve Crocker\"], Internet Hall of Fame, Internet Society, retrieved 14 September 2013.</ref> For this work, Crocker was awarded the 2002 [[IEEE Internet Award]].<ref name=\"IEEE Internet Award Recipients\">{{cite web|title=IEEE Internet Award Recipients|url=http://www.ieee.org/about/awards/bios/internet_recipients.html#sect12|publisher=[[IEEE]]|accessdate=23 August 2013}}</ref>

While at UCLA Crocker taught an extension course on computer programming (for the [[IBM 7094]] [[mainframe computer]]).  The class was intended to teach digital processing and assembly language programming to high school teachers, so that they could offer such courses in their high schools.  A number of high school students were also admitted to the course, to ensure that they would be able to understand this new discipline.  Crocker was also active in the newly formed UCLA Computer Club.

Crocker has been a program manager at [[Defense Advanced Research Projects Agency]] (DARPA), a senior researcher at [[University of Southern California|USC]]'s [[Information Sciences Institute]], founder and director of the Computer Science Laboratory at [[The Aerospace Corporation]] and a vice president at [[Trusted Information Systems]]. In 1994, Crocker was one of the founders and chief technology officer of [[CyberCash]], Inc. In 1998, he founded and ran Executive DSL, a [[Digital subscriber line|DSL-based]] ISP. In 1999 he cofounded and was CEO of Longitude Systems. He is currently CEO of [https://web.archive.org/web/20020723010257/http://www.shinkuro.com/ Shinkuro], a research and development company.

Steve Crocker was instrumental in creating the ARPA \"Network Working Group\", which later was the context in which the [[IETF]] was created.

He has also been an [[IETF]] security area director, a member of the [[Internet Architecture Board]], chair of the [[ICANN]] Security and Stability Advisory Committee, a board member of the [[Internet Society]] and numerous other Internet-related volunteer positions.

In 2012, Crocker was inducted into the [[Internet Hall of Fame]] by the [[Internet Society]].<ref>[http://www.internethalloffame.org/inductees/year/2012 2012 Inductees], [[Internet Hall of Fame]] website. Last accessed April 24, 2012</ref>

==References==")
        );

        $this->assertEquals(
            "<p>James Silk Buckingham (25 August 1786 – 30 June 1855) was a Cornish-born author, journalist and traveller, who infused a new light to Indian Journalism. He was the pioneer among the Europeans who fought for a liberal press in India.</p>",
            $parser->extractBio("{{Use dmy dates|date=April 2013}}
{{infobox person |name = James Silk Buckingham |image = James Silk Buckingham by Clara S. Lane.jpg |caption = ''James Silk Buckingham'' by Clara S. Lane |nationality = British |occupation = author, journalist, traveller |birth_date = {{birth date|1786|8|25|df=yes}} |birth_place = Flushing, Cornwall |death_date = {{death date and age|1855|6|30|1786|8|25|df=yes}} |death_place = London, England }}

'''James Silk Buckingham''' (25 August 1786 – 30 June 1855) was a [[Cornwall|Cornish]]-born author, journalist and traveller, who infused a new light to Indian Journalism. He was the pioneer among the Europeans who fought for a liberal press in India. 

==Early Life==")
        );

        $this->assertEquals(
            "<p>Jean-Claude Camille François Van Varenberg (born 18 October 1960), professionally known as Jean-Claude Van Damme and abbreviated as JCVD, is a Belgian actor, martial artist, screenwriter, film producer, and director best known for his martial arts action films. The most successful of these films include Bloodsport (1988), Kickboxer (1989), Lionheart (1990), Double Impact (1991), Universal Soldier (1992), Hard Target (1993), Street Fighter (1994), Timecop (1994), Sudden Death (1995), JCVD (2008) and The Expendables 2 (2012).</p>",
            $parser->extractBio("{{Redirect2|Van Damme|JCVD|the film|JCVD (film)|other uses|Van Damme (disambiguation)}}
{{pp-semi-blp|small=yes}}
{{Infobox martial artist
|name = Jean-Claude Van Damme
|other_names = \"The Muscles from Brussels\"
|image = File:Jean-Claude Van Damme 2012.jpg
|imagesize =
|caption = Van Damme in Paris at the French premiere of ''[[The Expendables 2]]'' in 2012
|birth_name = Jean-Claude Camille François Van Varenberg
|birth_date = {{birth date and age|df=yes|1960|10|18}}
|birth_place = [[Sint-Agatha-Berchem]], [[Brussels]], Belgium
|nationality = {{flagcountry|BEL}}
| occupation = Actor, martial artist, screenwriter, film producer, director
| height = 1.77 m
| weight =
| weight_class = [[Middleweight]]
| reach =
| style = [[Karate]], [[Kickboxing]], [[Muay Thai]], [[Taekwondo]]
| fighting_out_of = Brussels, Belgium
| team = Team Goetz
| rank ={{color box|black}} 2nd Dan Black Belt in [[Shotokan]]
| trainer = Claude Goetz <br /> Dominique Valera
| kickbox_win = 18
| kickbox_kowin = 18
| kickbox_loss = 1
| kickbox_koloss =
| kickbox_draw =
| kickbox_nc =
| am_win = 44
| am_kowin =
| am_subwin =
| am_loss = 4
| am_koloss =
| am_subloss =
| am_draw =
| am_nc =
| url =
| sherdog =
| footnotes =
| updated =
|years_active = 1976–1982 <small>(martial arts)</small><br /> 1979–present <small>(acting)</small>
|spouse = {{marriage|Maria Rodriguez|1980|1984}}<br />{{marriage|Cynthia Derderian|1985|1986}}<br />{{marriage|[[Darcy LaPier]]<br />|1994|1997}}<br />{{marriage|[[Gladys Portugues]]|1987|1992}};<br>(1999–Present)
|children = 3
}}{{Use dmy dates|date=October 2012}}
'''Jean-Claude Camille François Van Varenberg''' (born 18 October 1960), professionally known as '''Jean-Claude Van Damme'''{{efn|{{IPAc-en|lang|pron|ˈ|ʒ|ɑː|n|_|ˈ|k|l|ɔː|d|_|v|æ|n|ˈ|d|æ|m}}<br>{{IPA-fr|ʒɑ̃klod vandam|lang}}<br>{{IPA-nl|ʒɑ̃ːˈkloːd vɑn ˈdɑmə|lang}}}} and abbreviated as '''JCVD''', is a Belgian [[actor]], [[Martial arts|martial artist]], screenwriter, film producer, and director best known for his [[martial arts film|martial arts]] [[action film]]s. The most successful of these films include ''[[Bloodsport (film)|Bloodsport]]'' (1988), ''[[Kickboxer (1989 film)|Kickboxer]]'' (1989), ''[[Lionheart (1990 film)|Lionheart]]'' (1990), ''[[Double Impact]]'' (1991), ''[[Universal Soldier (1992 film)|Universal Soldier]]'' (1992), ''[[Hard Target]]'' (1993), ''[[Street Fighter (1994 film)|Street Fighter]]'' (1994), ''[[Timecop]]'' (1994), ''[[Sudden Death (1995 film)|Sudden Death]]'' (1995), ''[[JCVD (film)|JCVD]]'' (2008) and ''[[The Expendables 2]]'' (2012).

==Early life==")
        );

        $this->assertEquals(
            "<p>John II (Portuguese: João II; 3 March 1455 – 25 October 1495), the Perfect Prince , was the king of Portugal and the Algarves in 1477/1481–1495.</p><p>He is known for re-establishing the power of the Portuguese throne, reinvigorating the Portuguese economy, and renewing his country's exploration of Africa and the Orient.</p>",
            $parser->extractBio("{{Use dmy dates|date=July 2013}}
{{Infobox royalty|monarch
| name         = John II
| image        = Portrait of John II of Portugal.jpg
| succession   = [[List of Portuguese monarchs|King of Portugal and the Algarves]]
| reign        = 28 August 1481 – {{nowrap|25 October 1495}}{{efn|name=note |Reigned briefly for four days — from 11 to 15 November 1477 — during [[Afonso V of Portugal|his father]]'s short-lived abdication.}}
| cor-type     = Acclamation
| coronation   = 31 August 1481
| predecessor  = [[Afonso V of Portugal|Afonso V]]
| successor    = [[Manuel I of Portugal|Manuel I]]
| birth_date   = {{Birth date|1455|3|3|df=y}}
| birth_place  = [[Castle of São Jorge]], [[Kingdom of Portugal|Portugal]]
| death_date   = {{Death date and age|1495|10|25|1455|3|3|df=y}}
| death_place  = [[Alvor (Portimão)|Alvor]], [[Kingdom of the Algarve|Algarve]]
| burial_place = [[Monastery of Batalha]]
| spouse       = [[Eleanor of Viseu]]
| issue        = [[Afonso, Prince of Portugal]]
| issue-link   = #Marriage and descendants
| issue-pipe   = among others...
| house        = [[House of Aviz|Aviz]]
| father       = [[Afonso V of Portugal]]
| mother       = [[Isabella of Coimbra]]
| religion     = [[Catholic Church|Roman Catholicism]]
}}

'''John II''' (Portuguese: '''João II''',<ref>Rendered as Joam in Archaic Portuguese</ref> {{IPA-pt|ʒuˈɐ̃w̃}}; 3 March 1455 – 25 October 1495), ''the Perfect Prince'' ({{lang-pt|o Príncipe Perfeito}}), was the [[List of Portuguese monarchs|king of Portugal]] and the [[Kingdom of the Algarves|Algarves]] in 1477/1481–1495.

He is known for re-establishing the power of the Portuguese throne, reinvigorating the Portuguese economy, and renewing his country's exploration of Africa and the Orient.

==Early life==")
        );

        $this->assertEquals(
            "<p>Dražen Budiša (born 25 July 1948) is a retired Croatian politician who used to be leading opposition figure in the 1990s and a two-time presidential candidate. As leader of the Croatian Social Liberal Party through the 1990s he remains to date the only Leader of the Opposition not to have been from either the Croatian Democratic Union or Social Democratic Party.</p>",
            $parser->extractBio("{{BLP sources|date=April 2015}}
{{Infobox Officeholder
|name          = Dražen Budiša
|image         = Pd croatian drazen budisa 9Feb02 932.jpg
|office        = [[Member of Parliament of Croatia|Member of Parliament]]
|term_start    = 7 September 1992
|term_end      = 23 December 2003
|primeminister = 
|constituency  = 
|office3       = 2nd [[Opposition (Croatia)#Leader of the Opposition|Leader of the Opposition]]
|term_start3   = 12 August 1992
|term_end3     = 27 January 2000
|primeminister3 =[[Hrvoje Šarinić]] (1992-1993)<br />[[Nikica Valentić]] (1993-1995)<br />[[Zlatko Mateša]] (1995-2000)
|predecessor3  = ''vacant'' ([[Cabinet of Franjo Gregurić|National unity government]]) 
|successor3    = [[Vladimir Šeks]] <small>(Acting)</small>
|office4       = President of the <br/>[[Croatian Social Liberal Party]]
|term_start4   = 2 February 2002<ref>{{hr icon}} [http://www.hsls.hr/index.php?option=com_content&view=article&id=31&Itemid=10 HSLS: Povijest i program]</ref> 
|term_end4     = 7 December 2003
|predecessor4  = [[Jozo Radoš]] <small>(Acting)</small>
|successor4    = [[Ivan Čehok]] <small>(Acting)</small>
|term_start5   = November 1997
|term_end5     = 11 July 2001
|predecessor5  = [[Vlado Gotovac]]
|successor5    = [[Jozo Radoš]] <small>(Acting)</small>
|term_start6   = 1990
|term_end6     = February 1996
|predecessor6  = [[Slavko Goldstein]]
|successor6    = [[Vlado Gotovac]]
|birth_date    = {{birth date and age|1948|7|25|df=y}}
|birth_place   = [[Drniš]], [[Socialist Federal Republic of Yugoslavia|Yugoslavia]]
}}

'''Dražen Budiša''' (born 25 July 1948) is a retired [[Croatia]]n politician who used to be leading opposition figure in the 1990s and a two-time presidential candidate. As leader of the [[Croatian Social Liberal Party]] through the 1990s he remains to date the only Leader of the Opposition not to have been from either the [[Croatian Democratic Union]] or [[Social Democratic Party of Croatia|Social Democratic Party]].

==Biography==

===During Yugoslavia===")
        );
    }

    public function testFirstDataParser()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals(
            "<p>William Henry Pferinger Elkins (1883–1964) was a Canadian soldier. He was a Commandant of the RMC.</p>",
            $parser->firstParagraph("{{Infobox Officeholder
| honorific-prefix    = Major General
| name                = William Henry Pferinger Elkins
| honorific-suffix    = {{post-nominals|post-noms=CB CBE DSO}} 
| image               = 624 Brigadier William Henry Pferinger Elkins.jpg
| imagesize           =150px
| order               =
| office              = 
| term_start          = 
| term_end            = 
| predecessor         =
| successor           =
<!-- Personal data from here down -->
| birth_date          = {{birth date|df=yes|1883|06|13}}
| birth_place         = Sherbrooke, Quebec
| death_date          = 1964
| death_place         = 
| restingplace        =
| restingplacecoordinates =
| birthname           =
| nationality         = Canadian
| party               =
| otherparty          = <!--For additional political affiliations -->
| spouse              = 
| partner             = <!--For those with a domestic partner and not married -->
| relations           = 
| children            =
| residence           =
| alma_mater          = [[Royal Military College of Canada]]
| occupation          = 
| profession          = Soldier
| cabinet             =
| committees          =
| portfolio           =
| religion            = 
| signature           =
| website             =
| footnotes           =
| blank1              =
| data1               =
| blank2              =
| data2               =
| blank3              =
| data3               =
| blank4              =
| data4               =
| blank5              =
| data5               =
<!-- Military data -->
| nickname            =
| allegiance          = Canada
| branch              = [[Royal Canadian Horse Artillery|RCHA]]
| serviceyears        = 
| rank                = [[Major General]]
| unit                = 
| commands            = 
| battles             =
| awards              =
| military_blank1     =
| military_data1      =
| military_blank2     =
| military_data2      =
| military_blank3     =
| military_data3      =
| military_blank4     =
| military_data4      =
| military_blank5     =
| military_data5      =
}}
Major General '''William Henry Pferinger Elkins''' {{post-nominals|country=GBR-cats|CB|CBE|DSO}} (1883–1964) was a Canadian soldier. He was a Commandant of the [[Royal Military College of Canada|RMC]].

==Education==

624 Major General William Henry Pferinger Elkins was born on 13 June 1883 at [[Sherbrooke]], Quebec. He graduated from the [[Royal Military College of Canada]] in [[Kingston, Ontario]] in June 1905.

==Career==")
        );
    }
}