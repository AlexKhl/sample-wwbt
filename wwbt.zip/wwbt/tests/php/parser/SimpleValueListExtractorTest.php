<?php

use PHPUnit\Framework\TestCase;

require_once __DIR__."/../../../vendor/autoload.php";

/**
 * @covers Email
 */
final class SimpleValueListExtractorTest extends \diplux\tests\DipluxTestCase
{
    public function testSimpleValueListParser()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals("poet", $parser->simpleValueListParser('[[Poet]]'));
        $this->assertEquals("poet", $parser->simpleValueListParser('Poet'));
        $this->assertEquals("voice actor", $parser->simpleValueListParser('Voice actor'));

        //http://localhost:8852/person/ed-mcmahon-1923-03-06/
        //http://localhost:8852/person/robert-towne-1934-11-23/
        //http://localhost:8852/person/elizabeth-jane-cochran-1864-05-05/
        $this->assertEquals([
            'alyce ferrill (1945–1974)',
            'victoria valentine (1976–1989)',
            'pam hurn (1992–2009)'
        ], $parser->extractSpouse('Alyce Ferrill (1945–1974)Victoria Valentine (1976–1989)Pam Hurn (1992–2009)'));

        $this->assertEquals([
            'harpsichord',
            'harpsichordist',
            'pianist',
        ], $parser->simpleValueListParser('[[Harpsichord]]ist and [[pianist]]'));

        $this->assertEquals([
            'attorney',
            'lawyer',
        ], $parser->simpleValueListParser('[[Lawyer|Attorney]]'));

        $this->assertEquals([
            'author',
            'philosopher',
        ], $parser->simpleValueListParser('[[author]], [[philosopher]]'));

        $this->assertEquals([
            'consultant',
            'consultant microsoft',
            'former president sega',
            'microsoft',
            'president',
            'sega',
            'virgin play',
        ], $parser->simpleValueListParser('[[Consultant]] [[Microsoft]], Virgin Play, Former [[President]] [[Sega]]'));

        $this->assertEquals([
            'rapper',
            'singer-songwriter',
        ], $parser->simpleValueListParser('{{hlist|Singer-songwriter|rapper}}'));

        $this->assertEquals([
            'abolitionism in the united states',
            'abolitionist',
            'educator',
            'farmer',
            'journalist',
            'lecturer',
            'physician',
            'suffragist',
            'women\'s rights',
            'women\'s rights activist',
        ], $parser->simpleValueListParser('[[Abolitionism in the United States|abolitionist]], [[women\'s rights]] activist, [[suffragist]], lecturer, educator, journalist, farmer, physician<ref name=wasm/>'));

        $this->assertEquals([
            'author',
            'evangelism',
            'evangelist',
            'pastor',
            'radio host',
        ], $parser->simpleValueListParser('Radio Host, [[Evangelism|Evangelist]], Pastor, Author'));

        $this->assertEquals([
            'author',
            'magazine editor',
        ], $parser->simpleValueListParser('[[Author]]<br>[[magazine editor]]'));

        $this->assertEquals([
            'concert promoter',
            'director',
            'producer',
            'tour promoter',
        ], $parser->simpleValueListParser('[[Tour promoter|Concert promoter]], director, producer'));

        $this->assertEquals([
            'chief client platform architect at intel',
            'intel',
        ], $parser->simpleValueListParser('Chief Client Platform Architect at [[Intel]]<ref> {{cite web|url=http://www.intel.com/pressroom/kits/bios/abhatt.htm|accessdate=September 23, 2009|title=Intel Fellow – Ajay V. Bhatt|date=July 22, 2009|archiveurl=https://web.archive.org/web/20091104041719/http://www.intel.com/pressroom/kits/bios/abhatt.htm|archivedate=4 November 2009 <!--DASHBot-->|deadurl=no}} </ref>'));

        $this->assertEquals([
            'community organizer',
            'newspaper owner',
        ], $parser->simpleValueListParser('Newspaper owner<br>
[[Community organizer]]'));

        $this->assertEquals([
            'actress',
            'singer',
            'songwriter',
        ], $parser->simpleValueListParser('{{flat list|*Singer
*songwriter
*actress}}'));

        $this->assertEquals([
            'actress',
            'comedian',
            'dancer',
            'model',
            'rapper',
            'singer',
            'songwriter',
            'television host',
            'television producer',
        ], $parser->simpleValueListParser('{{flatlist|*Actress
*comedian
*model
*singer
*songwriter
*rapper
*dancer
*television producer
*television host}}'));

        $this->assertEquals([
            'actor',
            'actress',
            'businessman',
            'businesswoman',
            'dance',
            'dancer',
            'model',
            'model (people)',
            'singer',
            'singing',
        ], $parser->simpleValueListParser('{{flatlist|* [[Singing|Singer]]
* [[dance]]r
* [[Model (people)|model]]
* [[Actor|actress]]
* [[Businessman|businesswoman]]}}'));

        $this->assertEquals([
            'academic teacher',
            'choral conductor',
        ], $parser->simpleValueListParser('{{plainlist|* Choral conductor
* Academic teacher}}'));

        $this->assertEquals([
            "beer",
            "beer and liquor distributor",
//            "beer distributor",
            "business owner",
            "entrepreneur",
            "liquor distributor",
            "produce wholesaler",
        ], $parser->simpleValueListParser('[[business owner]], [[entrepreneur]], [[produce wholesaler]], [[beer and liquor distributor]]
<gallery>
File:D. Canale and Co. Produce Wagon - 1907.jpg'));
        $this->assertEquals([
            'independence fighter',
            'karachi',
            'lawyer',
            'mayor of karachi',
            'politician',
        ], $parser->simpleValueListParser('{{Plainlist|*Lawyer
*Politician
*Independence fighter
*Mayor of [[Karachi]]<ref name="nadeemf.paracha"> {{cite web|url=http://www.dawn.com/news/1134284|title=Visual Karachi: From Paris of Asia, to City of Lights, to Hell on Earth|author=Nadeem F. Paracha|work=dawn.com|accessdate=10 March 2016}} </ref>}}'));

        $this->assertEquals([
            'center for democracy',
            'center for democracy and technology',
            'ceo',
            'president',
            'technology',
        ], $parser->simpleValueListParser('President and CEO, [[Center for Democracy and Technology]]'));
    }

    public function testSimpleValueListParser_TODO()
    {
        $parser = new \diplux\parser\Extractor();

        $this->assertEquals([
            'author',
            'librarian',
            'master of library and information science educator',
            'master of library and information science',
            'mlis',
            'mlis educator',
            'public librarian',
        ], $parser->simpleValueListParser('Public [[Librarian]], [[Master of Library and Information Science|MLIS]] educator, and [[author]]'));

        $this->assertEquals(['campaign manager', 'campaign manager', 'city of pittsburgh', 'city of pittsburgh treasurer ', 'duquesne gardens', 'hockey referee in the western pennsylvania hockey league|wphl', 'hockey referee in the wphl', 'manager of the duquesne gardens', 'owner of the pittsburgh yellow jackets', 'pennsylvania', 'pittsburgh', 'pittsburgh yellow jackets', 'pittsburgh, pennsylvania treasurer ', 'treasurer of the usaha', 'united states amateur hockey association', 'usaha', 'western pennsylvania hockey league', 'wphl'], $parser->simpleValueListParser('* Hockey referee in the [[Western Pennsylvania Hockey League|WPHL]]
* Treasurer of the [[United States Amateur Hockey Association|USAHA]]
* Manager of the [[Duquesne Gardens]]
* Owner of the [[Pittsburgh Yellow Jackets]]
* [[Pittsburgh, Pennsylvania|City of Pittsburgh]] Treasurer 
* Campaign Manager'));
        $this->assertEquals(['actress', 'voice acting in japan', 'voice actress'], $parser->simpleValueListParser('{{flatlist|*Actress
*[[Voice acting in Japan|voice actress]]}}'));
        $this->assertEquals(['actress', 'author'], $parser->simpleValueListParser('{{Flat list|*[[Actress]]
*[[author]]}}'));
        $this->assertEquals(['actress', 'media trainer', 'performance coach', 'spokesperson', 'host',], $parser->simpleValueListParser('{{Flatlist|* Actress
* Media Trainer/Performance Coach
* Spokesperson/Host}}'));

    }
}

