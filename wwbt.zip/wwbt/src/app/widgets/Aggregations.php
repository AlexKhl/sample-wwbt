<?php

namespace diplux\app\widgets;

use DateTime;
use DateTimeZone;
use diplux\app\entity\PersonWrapper;
use Silex\Application;

class Aggregations
{
    private $app;
    private $person;

    /**
     * Aggregations constructor.
     * @param $app Application
     * @param $person PersonWrapper
     */
    public function __construct($app, $person)
    {
        $this->app = $app;
        $this->person = $person;
    }

    public function bornOn()
    {
        $tz = new DateTimeZone('Europe/London');
        $dateTimeParsed = DateTime::createFromFormat('Y-m-d', $this->person->birth_date["date"], $tz);
        if (is_bool($dateTimeParsed)) {
            return '';
        }

        $birth_date = $this->person->birth_date;

        $day = date('j', strtotime($birth_date['date']));
        $month = date('n', strtotime($birth_date['date']));

        $dateFilters = [];
        if ($month) {
            $dateFilters[] = ['term' => ["birth_date.month" => ["value" => (int)$month]]];
        }
        if ($day) {
            $dateFilters[] = ['term' => ["birth_date.day" => ["value" => (int)$day]]];
        }

        $daoPerson = \GetDao::Person();
        $daoPerson->loadByQuery([
            'size' => 0,
            'query' => ["bool" => ["must" => $dateFilters]],
        ], $result);

        return $this->app['twig']->render('@responsive/widgets/born-on.twig', array(
            'birth_date' => $birth_date['date'],
            'quantity' => $result['hits']['total'],
        ));
    }

    public function yearsOld()
    {
        if ($this->person->death_place == null && $this->person->death_date == null) {
            $birth_date = $this->person->birth_date;
            $birth_year = $birth_date["year"];

            $mustFilters[] = ['term' => ["birth_date.year" => ["value" => (int)$birth_year]]];
            $mustNotFilters[] = ['exists' => ["field" => "death_date"]];
            $mustNotFilters[] = ['exists' => ["field" => "death_place"]];
            $mustNotFilters[] = ['exists' => ["field" => "death_cause"]];
            $mustNotFilters[] = ["term" => ["alive" => ["value" => "dead"]]];
            $mustNotFilters[] = ["term" => ["alive" => ["value" => "unknown"]]];

            $daoPerson = \GetDao::Person();
            $daoPerson->loadByQuery([
                'size' => 0,
                'query' => ["bool" => ["must" => $mustFilters, "must_not" => $mustNotFilters]],
            ], $result);

            $tz = new DateTimeZone('Europe/London');
            $dateTimeParsed = DateTime::createFromFormat('Y-m-d', $this->person->birth_date["date"], $tz);
            if (is_bool($dateTimeParsed)) {
                return '';
            }
            $age = $dateTimeParsed
                ->diff(new DateTime('now', $tz))
                ->y;

            return $this->app['twig']->render('@responsive/widgets/years-old.twig', array(
                'age' => $age,
                'quantity' => $result['hits']['total'],
            ));
        } else {
            return "";
        }
    }

    public function birthYear()
    {
        $tz = new DateTimeZone('Europe/London');
        $dateTimeParsed = DateTime::createFromFormat('Y-m-d', $this->person->birth_date["date"], $tz);
        if (is_bool($dateTimeParsed)) {
            return '';
        }

        $birth_date = $this->person->birth_date;

        $year = date('Y', strtotime($birth_date['date']));

        $dateFilters = [];
        if ($year) {
            $dateFilters[] = ['term' => ["birth_date.year" => ["value" => (int)$year]]];
        }

        $daoPerson = \GetDao::Person();
        $daoPerson->loadByQuery([
            'size' => 0,
            'query' => ["bool" => ["must" => $dateFilters]],
        ], $result);

        return $this->app['twig']->render('@responsive/widgets/birth-year.twig', array(
            'birth_year' => $year,
            'quantity' => $result['hits']['total'],
        ));
    }

    public function deathYear()
    {
        $tz = new DateTimeZone('Europe/London');
        $dateTimeParsed = DateTime::createFromFormat('Y-m-d', $this->person->death_date["date"], $tz);
        if (is_bool($dateTimeParsed)) {
            return '';
        }

        $year = $this->person->death_date['year'];

        if (!empty($year)) {
            $dateFilters = [];
            if ($year) {
                $dateFilters[] = ['term' => ["death_date.year" => ["value" => (int)$year]]];
            }

            $daoPerson = \GetDao::Person();
            $daoPerson->loadByQuery([
                'size' => 0,
                'query' => ["bool" => ["must" => $dateFilters]],
            ], $result);

            return $this->app['twig']->render('@responsive/widgets/death-year.twig', array(
                'death_year' => $year,
                'quantity' => $result['hits']['total'],
            ));
        } else {
            return "";
        }
    }

    public function club27()
    {
        $aged = $this->person->aged;

        if (!empty($aged) && $aged == 27) {
            $daoPerson = \GetDao::Person();
            $daoPerson->loadByQuery([
                'size' => 0,
                'query' => [
                    "bool" => [
                        "must" => [
                            "term" => ["aged" => 27],
                        ],
                        "must_not" => [
                            ["term" => ["alive" => ["value" => "alive"]]],
                            ["term" => ["alive" => ["value" => "unknown"]]],
                        ]
                    ]
                ],
            ], $result);

            return $this->app['twig']->render('@responsive/widgets/club27.twig', array(
                'quantity' => $result['hits']['total'],
            ));
        } else {
            return "";
        }
    }

    public function centenarian()
    {
        $b_year = $this->person->birth_date["year"];
        $age = 100;
        $bound_year = (int)date("Y", strtotime("-$age year"));

        if (($bound_year > $b_year) && ($this->person->alive === "alive")) {
            $boundary = date("d/m/Y", strtotime("-$age year"));
            $daoPerson = \GetDao::Person();
            $daoPerson->loadByQuery([
                'size' => 0,
                'query' => [
                    "bool" => [
                        "must" => [
                            ["range" =>
                                ["birth_date.date" =>
                                    [
                                        "lte" => $boundary,
                                        "format" => "dd/MM/yyyy||yyyy"
                                    ]
                                ]
                            ]
                        ],
                        "must_not" => [
                            ["exists" => ["field" => "death_date"]],
                            ["exists" => ["field" => "death_place"]],
                            ["exists" => ["field" => "death_cause"]],
                            ["terms" => ["alive" => ["_null_", "unknown", "dead", "null"]]],
                        ]
                    ]
                ]
            ], $result);

            return $this->app['twig']->render('@responsive/widgets/centenarian.twig', array(
                'quantity' => $result['hits']['total'],
            ));
        } else {
            return "";
        }
    }

    public function name()
    {
        $name = $this->person->full_name["first_name"];

        if (!empty($name)) {
            $daoPerson = \GetDao::Person();
            $daoPerson->loadByQuery([
                'size' => 0,
                'query' => [
                    "match" => [
                        "full_name.first_name" => [
                            "query" => $name
                        ]
                    ]
                ],
            ], $result);

            return $this->app['twig']->render('@responsive/widgets/name.twig', array(
                'name' => $name,
                'quantity' => $result['hits']['total'],
            ));
        } else {
            return "";
        }
    }
}