<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 16/01/18
 * Time: 8:51 PM
 */

namespace diplux\app\entity;


/**
 * Class PersonWrapper
 * @package diplux\app\entity
 *
 * @property array page_metadata
 * @property string name
 * @property string full_name
 * @property string birth_name
 * @property array he_she_counters
 * @property array birth_date
 * @property array death_date
 * @property array birth_place
 * @property array country
 * @property string birth_place_raw
 * @property array death_place
 * @property string death_place_raw
 * @property string death_cause
 * @property string nationality
 * @property string nationality_raw
 * @property string religion
 * @property string religion_raw
 * @property string native_name
 * @property string native_name_lang
 * @property array occupation
 * @property string occupation_raw
 * @property string known_for
 * @property string caption
 * @property string image_orig
 * @property string children
 * @property string children_raw
 * @property array awards
 * @property string awards_raw
 * @property string spouse
 * @property string spouse_raw
 * @property string image
 * @property string image_path
 * @property string infobox
 * @property string full_text
 * @property string full_xml
 * @property null|string[] links
 * @property string $source_page_title
 * @property int $counter_in
 * @property int $counter_out
 * @property array death_cause_raw
 * @property string macros
 * @property string wiki_link
 * @property string gender
 * @property string bio
 * @property array bio_stat
 * @property string alive
 */
class PersonWrapper extends EntityWrapper
{
    /**
     * @return string
     */
    public function anyName(): string
    {
        $strings = array_values(array_filter([
            $this->name,
            $this->birth_name,
            $this->native_name,
            $this->source_page_title
        ]));
        $name = $strings[0] ?? \_::error("name is not defined", $this);
        $name = \_::stripMacrosses($name);
        return $name;
    }

    public function getOccupations()
    {
        $occ_array = [];
        $occupations = $this->occupation;
        if (!is_array($occupations)) {
            $occupations = [$occupations];
        }
        foreach ($occupations as $occupation) {
            $occ_array[] = [
                "name" => $occupation,
                "link" => $occupation,//preg_replace('/\s+/', '-', $occupation)
            ];
        }
        return $occ_array;
    }

    public function getCoverPath(){
        $imageWrapper = new ImageWrapper();
        return $imageWrapper->getRealPath($this->image);
    }

//    /**
//     * @return string
//     */
//    /*public function getGender()
//    {
//        if ($this->he_she_counters['he'] > $this->he_she_counters['she']) $gender = 'M';
//        elseif ($this->he_she_counters['she'] > $this->he_she_counters['he']) $gender = 'W';
//        else $gender = null;
//
//        return $gender;
//    }*/


    /**
     * @param string $type
     * @return string
     */
    public function renderUrl($type = 'view')
    {
        switch ($type) {
            case 'view':
                return "/person/{$this->url[0]}/";
                break;
            default:
                return parent::renderUrl($type);
                break;
        }
    }

}