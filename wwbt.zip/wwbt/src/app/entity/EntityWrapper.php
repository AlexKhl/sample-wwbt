<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 16/01/18
 * Time: 8:49 PM
 */

namespace diplux\app\entity;

/**
 * Class EntityWrapper
 * @package diplux\app\entity
 *
 * @property array url
 */
class EntityWrapper
{
    protected $data = [];
    protected $meta = [];

    public function __isset($name)
    {
        return isset($this->data[$name]);
    }

    public function __get($name)
    {
        return $this->data[$name] ?? null;
    }

    public function __set($name, $value)
    {
        $this->data[$name] = $value;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * @param array $data
     */
    public function setData(array $data)
    {
        $this->data = $data;
    }

    /**
     * @return array
     */
    public function getMeta(): array
    {
        return $this->meta;
    }

    /**
     * @param array $meta
     */
    public function setMeta(array $meta)
    {
        $this->meta = $meta;
    }

    public function renderUrl($type = 'view')
    {
        switch ($type) {
            case 'view:absolute':
                return "https://www.whowasborn.today" . $this->renderUrl('view');
                break;
            default:
                assert(false, "'$type' is not known url type");
                return '';
                break;
        }
    }

}