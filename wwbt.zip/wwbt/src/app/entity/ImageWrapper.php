<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 16/01/18
 * Time: 8:51 PM
 */

namespace diplux\app\entity;


/**
 * Class ImageWrapper
 * @package diplux\app\entity
 */

class ImageWrapper
{


    public function extractName($string, $extension = false)
    {
        $name = basename($string);
        preg_match('#^(?<archive>\d+!)?(?<filename>.*)$#', $name, $matches);
        return $extension ? $matches['filename'] : pathinfo($matches['filename'], PATHINFO_FILENAME);
    }

    public function extractExt($string)
    {
        return pathinfo($string, PATHINFO_EXTENSION);
    }

    public function getHash($string)
    {
        return md5($this->extractName($string));
    }

    public function getRealPath($string)
    {
        $ext = strtolower($this->extractExt($string));
        if (!empty($ext)) {
            $ext = '.' . $ext;
        }
        $hash = $this->getHash($string);
        preg_match('#^(?<level1>.)(?<level2>..).*$#', $hash, $matches);
        return "{$matches['level1']}/{$matches['level2']}/{$hash}{$ext}";
    }
}