<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 16/01/18
 * Time: 8:51 PM
 */

namespace diplux\app\entity;


class LocationWrapper extends EntityWrapper
{

}