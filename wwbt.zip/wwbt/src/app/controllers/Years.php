<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Years implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "main"]);

        return $factory;
    }

    public function main(Request $request, Application $app, $page = 0)
    {
        $client = ClientBuilder::create()->build();
        $size = 0;
        $result = $client->search([
            'index' => 'person',
            'body' => [
                'size' => $size,
                'query' => [
                    'bool' => [
                        'must' => [
                            'range' => [
                                "birth_date.year" => [
                                    "lte" => '2017',
                                    "format" => "dd/MM/yyyy||yyyy",
                                ]
                            ]
                        ]
                    ],
                ],
                'aggs' => [
                    "birth_date.year" => [
                        "terms" => [
                            "field" => "birth_date.year",
                            "size" => 2000,
                            "order" => [
                                "_key" => "desc"
                            ]
                        ]
                    ]
                ],
            ]
        ]);

        if (empty($result['aggregations']['birth_date.year']["buckets"])) {
            $app->abort(404, "Page does not exist.");
        }

        $years = [];
        foreach ($result['aggregations']['birth_date.year']["buckets"] as $item) {
            $years[] = $item;
        }

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Years', '/years'],
        ]);

        return $app['twig']->render('@responsive/Years.twig', [
            'title' => 'List of Years',
            'years' => $years,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['today', 'born by years', 'people', 'famous people'],
            'page_description' => ["List of years with quantity of persons in a year."],
        ]);
    }
}