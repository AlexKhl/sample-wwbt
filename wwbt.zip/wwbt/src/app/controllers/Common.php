<?php
/**
 * Created by IntelliJ IDEA.
 * User: alex
 * Date: 04.02.18
 * Time: 13:10
 */

namespace diplux\app\controllers;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Yaml\Parser;

abstract class Common
{
    public function renderBreadcrumbs(Request $request, $depth = 0)
    {
        $path = array_filter(explode('/', $request->getRequestUri()));
        $bc_names = $this->getRegisteredPaths();

        $breadcrumbs = ['Home' => '/']; //breadcrumbs
        $route = "/"; //route of breadcrumb
        foreach (array_slice($path, 0, $depth) as $elem) {
            $elem = $this->substituteRoute($elem);
            $route .= $elem . '/';
            $title = array_search($elem, $bc_names['breadcrumbs']) ?: ucfirst($this->cleanString($elem));
            $breadcrumbs[$title] = $route;
        }
        return $breadcrumbs;
    }

    private function getRegisteredPaths()
    {
        $yaml = new Parser();
        $data = $yaml->parse(file_get_contents('../configs/paths.yml'));
        return $data;
    }

    private function cleanString($str)
    {
        $str = str_replace(["-", "–"], ' ', $str);
        $str = preg_replace('/[0-9]+/', '', $str);
        $str = trim($str);

        return $str;
    }

    private function substituteRoute(&$route)
    {
        //TODO should redirect: occupations -> categories, person -> persons
        $substitutions = [
            'person' => 'persons',
            'categories' => 'occupations'
        ];
        if (isset($substitutions[$route]))
            return $substitutions[$route];
        else
            return $route;
    }
}