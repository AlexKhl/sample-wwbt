<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Persons extends Common implements ControllerProviderInterface
{
    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "persons"]);

        return $factory;
    }

    public function persons(Request $request, Application $app, $char = 'all', $page = 0)
    {
        $daoPerson = \GetDao::Person();
        $size = 30;


        if ($char !== 'all') {
            if (in_array($char, range('a', 'z'))) {
                $query = ["bool" => ["filter" => ['bool' => ['should' => []]]]];
                $query['bool']['filter']['bool']['should'][] = ['prefix' => ["name" => strtolower($char)]];
            }
            $persons = $daoPerson->loadByQuery([
                'size' => $size,
                'from' => $page * $size,
                'query' => $query,
                "sort" => [[
                    "counter_in" => [
                        "order" => "desc"
                    ]]
                ],
            ], $result);
        } else {
            $persons = $daoPerson->loadByQuery([
                'size' => $size,
                'from' => $page * $size,
                "sort" => [[
                    "counter_in" => [
                        "order" => "desc"
                    ]]
                ],
            ], $result);
        }

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        $page_address = "/persons";

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Persons', '/persons/'],
            [$char, $char],
        ]);

        return $app['twig']->render('@responsive/Persons.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/persons/$char", $result['hits']['total'], $page, $size),
            'title' => "List of persons",
            'breadcrumbs' => $breadcrumbs,
            'alphas' => range('a', 'z'),
            'page_address' => $page_address,
            'char' => $char,
            'page_keywords' => ['famous persons', 'famous birthdays', 'famous people', 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people is here. Filter people by first letter ans use the pagination to find needed info.'],
        ]);
    }
}