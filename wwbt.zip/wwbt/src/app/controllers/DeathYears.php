<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class DeathYears implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "main"]);

        return $factory;
    }

    public function main(Request $request, Application $app, $page = 0)
    {
        $client = ClientBuilder::create()->build();
        $size = 0;
        $result = $client->search([
            'index' => 'person',
            'body' => [
                'size' => $size,
                'aggs' => [
                    "death_date.year" => [
                        "terms" => [
                            "field" => "death_date.year",
                            "size" => 2000,
                            "order" => [
                                "_key" => "desc"
                            ]
                        ]
                    ]
                ],
            ]
        ]);
        if (empty($result['aggregations']['death_date.year']["buckets"])) {
            $app->abort(404, "Page does not exist.");
        }

        $years = $result['aggregations']['death_date.year']["buckets"];

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Years', '/death-years'],
        ]);

        return $app['twig']->render('@responsive/DeathYears.twig', [
            'title' => 'List of Death Years',
            'years' => $years,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['this year', 'dead by years', 'people', 'famous people'],
            'page_description' => ["List of years with quantity of persons in a year."],
        ]);
    }
}