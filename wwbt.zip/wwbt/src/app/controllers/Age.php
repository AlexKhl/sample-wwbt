<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Age implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'age']);

        return $factory;
    }

    public function age(Request $request, Application $app, int $age, int $page = 0)
    {
        $pager_age = (int)$age;
        //check list https://en.wikipedia.org/wiki/Oldest_people
        if ($age > 120) $age = 120;
        $daoPerson = \GetDao::Person();
        $size = 30;
        $title = "Age: $age years old";
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Ages', '/ages/'],
            [$age . ' years old', '/age/' . $age],
        ]);

        $boundary_age = $age;
        $top_boundary = date("d/m/Y", strtotime("-$boundary_age year"));
        $boundary_age++;
        $bottom_boundary = date("d/m/Y", strtotime("-$boundary_age year"));

        $query =
            ["bool" => [
                "must" =>[
                    ["range" =>
                        ["birth_date.date" =>
                            [
                                "gte" => $bottom_boundary,
                                "lte" => $top_boundary,
                                "format" => "dd/MM/yyyy||yyyy"
                            ]
                        ]
                    ]
                ],
                "must_not" => [
                    ["exists" => ["field" => "death_date"]],
                    ["exists" => ["field" => "death_place"]],
                    ["exists" => ["field" => "death_cause"]],
                    ["term"   => ["alive" => ["value" => "dead"]]],
                    ["term"   => ["alive" => ["value" => "unknown"]]],
                ]
            ]];

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ],
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        return $app['twig']->render('@responsive/Persons.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/age/$pager_age", $result['hits']['total'], $page, $size),
            'title' => $title,
            'breadcrumbs' => $breadcrumbs,
            'page_address' => "/ages",
            'page_keywords' => ['famous persons', 'famous birthdays', 'famous people', 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people is here. Filter people by first letter ans use the pagination to find needed info.'],
        ]);
    }
}