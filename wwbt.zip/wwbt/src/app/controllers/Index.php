<?php

namespace diplux\app\controllers;

use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Index implements ControllerProviderInterface
{
    private $day;
    private $month;

    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];
        // Any routes
        $factory->get('/', [$this, "home"]);
        return $factory;
    }

    public function home(Request $request, Application $app)
    {
        $this->day = date('j', strtotime('today'));
        $this->month = date('n', strtotime('today'));

        $daoPerson = \GetDao::Person();
        $size = 36 + 6;
        $occ_size = 20;

        $dateFilters = [];
        $dateFilters[] = ['term' => ["birth_date.month" => ["value" => (int)($this->month)]]];
        $dateFilters[] = ['term' => ["birth_date.day" => ["value" => (int)($this->day)]]];

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'query' => ["bool" => ["must" => $dateFilters]],
            "sort" => [[
                "extra_datasets.celebs-initials.celebrity" => [
                    "order" => "desc",
                    "unmapped_type" => "long"// TODO: fast fix, better to create mapping before import starts https://www.elastic.co/guide/en/elasticsearch/reference/current/search-request-sort.html#_ignoring_unmapped_fields
                ]]
            ],
            'aggs' => [
                "occupation" => [
                    "terms" => [
                        "field" => "occupation.keyword",
                        "size" => $occ_size,
                    ]],
                "birth_place" => [
                    "terms" => [
                        "field" => "birth_place.keyword",
                        "size" => $occ_size,
                    ]]
            ],
        ], $result);

        $items = array_slice($persons, 0, 6);
        $names = array_slice($persons, 6);
        $occupations = $result['aggregations']['occupation']["buckets"];
        $places = $result['aggregations']['birth_place']["buckets"];

        return $app['twig']->render('@responsive/Main.twig', [
            'page' => "Main page is here",
            'items' => $items,
            'names' => $names,
            'occupations' => $occupations,
            'places' => $places,
            'month' => $this->month,
            'day' => $this->day,
            'page_keywords' => ['today born', 'birthdays', 'celebs birthdays', 'birthday', 'born'],
            'page_description' => ['The most complete source of famous people\'s birthdays, their biographies, and other info! We have more than 500 records.'],
        ]);
    }
}