<?php


namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Silex\Provider\AssetServiceProvider;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class TreeMap implements ControllerProviderInterface
{

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'main']);

        return $factory;
    }

    public function main(Request $request, Application $app, $page = 0)
    {
        $daoPerson = \GetDao::Person();
        $size = 30;
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Tree Map', '/treemap/'],
        ]);

        $from = 1900;
        $to = 1999;
        $birth_place = "germany";

        //https://stackoverflow.com/questions/52099453/d3-treemap-make-each-rectangle-size-represent-its-value
        //https://www.d3-graph-gallery.com/treemap.html
        $query =
            [
                "bool" => [
                    "must" => [
                        ["range" =>
                            ["birth_date.year" =>
                                [
                                    "gte" => $from,
                                    "lte" => $to
                                ]
                            ]
                        ],
                        ['term' => ['birth_place.keyword' => $birth_place]],
                    ]
                ]
            ];

        $aggs = [
                "occupations" => [
                    "terms" => [
                        "field" => "occupation.keyword",
                        "size" => 20,
                        "min_doc_count" => 2
                    ]
                ]
            ];

        $persons = $daoPerson->loadByQuery([
            "size" => 0,
            'aggs' => $aggs,
            'query' => $query,
        ], $result);

        $rough_data = $result["aggregations"]["occupations"]["buckets"];

        array_unshift($rough_data, array("key"=>"Origin", "doc_count"=>""));

        foreach ($rough_data as $k=>$v){
            if ($k==0){
                $rough_data[$k] = array(
                    'key' => 'Origin',
                    'parent'=>'',
                    'doc_count'=> '',
                );
            }
            elseif ($k!=0){
                $rough_data[$k] = array(
                    'key' => $v['key'],
                    'parent'=>'Origin',
                    'doc_count'=> $v['doc_count'],
                );
            }
        }

        $prepared = array_map(function($tag) {
            return array(
                'name' => $tag['key'],
                'parent'=>$tag['parent'],
                'value' => $tag['doc_count']
            );
        }, $rough_data);

        if (empty($result["aggregations"]["occupations"]["buckets"])) {
            $app->abort(404, "This page does not exist.");
        }

        if ($page === 'json'){
            return $app->json($prepared);
        }else{
            return $app['twig']->render('@responsive/TreeMap.twig', [
                'result' => 'Tree map',
                'title' => 'Tree map',
                'breadcrumbs' => $breadcrumbs,
                'page_keywords' => ['famous persons', 'famous centenarians', 'famous people', 'celebs centenarians', 'celebrities', 'centenarians', 'hundred years people'],
                'page_description' => ['The list of famous people who are more than 100 years old.'],
                'js_files' => ['https://d3js.org/d3.v5.min.js', 'static/js/TreeMap.js']
            ]);
        }
    }
}