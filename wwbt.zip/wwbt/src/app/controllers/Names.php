<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Names extends Common implements ControllerProviderInterface
{
    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "names"]);

        return $factory;
    }

    public function names(Request $request, Application $app, $char = 'all', $page = 0)
    {
        $daoPerson = \GetDao::Person();
        $size = 30;
        $size_2 = 100;


        if ($char !== 'all') {
            if (in_array($char, range('a', 'z'))) {
                $query = ["bool" => ["filter" => ['bool' => ['should' => []]]]];
                $query['bool']['filter']['bool']['should'][] = ['prefix' => ["full_name.first_name" => strtolower($char)]];
            }
            $persons = $daoPerson->loadByQuery([
                'size' => $size,
                'from' => $page * $size,
                'query' => $query,
                "sort" => [[
                    "counter_in" => [
                        "order" => "desc"
                    ]]
                ],
                'aggs' => [
                    "names" => [
                        "terms" => [
                            "field" => "full_name.first_name.keyword",
                            "size" => $size_2,
                        ]
                    ]
                ],
            ], $result);
        } else {
            $persons = $daoPerson->loadByQuery([
                'size' => $size,
                'from' => $page * $size,
                "sort" => [[
                    "counter_in" => [
                        "order" => "desc"
                    ]]
                ],
                'aggs' => [
                    "names" => [
                        "terms" => [
                            "field" => "full_name.first_name.keyword",
                            "size" => $size_2,
                        ]
                    ]
                ],
            ], $result);
        }

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        $page_address = "/names";

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Names', '/names/'],
            [$char, $char],
        ]);

        return $app['twig']->render('@responsive/Names.twig', [
            'names' => $result['aggregations']['names']['buckets'],
            'title' => "List of celebs names",
            'breadcrumbs' => $breadcrumbs,
            'alphas' => range('a', 'z'),
            'page_address' => $page_address,
            'char' => $char,
            'page_keywords' => ['famous persons names', 'popular names', 'famous people', 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people names.'],
        ]);
    }
}