<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Year implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "main"]);

        return $factory;
    }

    public function main(Request $request, Application $app, $year, $page = 0)
    {
        $size = 30;
        $persons = \GetDao::Person()->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => [
                'term' => [
                    'birth_date.year' => $year
                ],
            ]
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        $page_address = "/persons";

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Years', '/years/'],
            [$year, $year],
        ]);

        return $app['twig']->render('@responsive/Year.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/year/$year", $result['hits']['total'], $page, $size),
            'title' => "Who Was Born In $year",
            'breadcrumbs' => $breadcrumbs,
            'page_address' => $page_address,
            'char' => $year,
            'page_keywords' => ['famous persons born in '.$year, 'famous birthday years', 'famous people born in '.$year, 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people is here. You can see people who born in specific year. Here you can see information about '.$year.' year.'],
        ]);
    }
}