<?php

namespace diplux\app\controllers;

use diplux\app\entity\PersonWrapper;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

class CountriesByOneOccupation extends Common implements ControllerProviderInterface
{
    private $day;
    private $month;

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'country_by_one_occupation']);

        return $factory;
    }

    public function country_by_one_occupation(Request $request, Application $app, $term = null, $page = null, $num = null)
    {
        $daoPerson = \GetDao::Person();

        $term_label = strip_tags($term);

        if (!$page){
            $page = 1;
        }

        if (!is_numeric($num) || $num == null || $num == false){
            $num = 30;
        }

        $query =
            [
                "bool" => [
                    "must" => [
                        ['term' => ['occupation.keyword' => ['value' => $term]]],
                    ]
                ]
            ];

        $aggs = [
            "birth_places" => [
                "terms" => [
                    "field" => "country.country.keyword",
                    "size" => $num,
                    "min_doc_count" => 2
                ]
            ]
        ];

        $persons = $daoPerson->loadByQuery([
            "size" => 0,
            'aggs' => $aggs,
            'query' => $query,
        ], $result);


        //The data for TreeMap
        $rough_data = $result["aggregations"]["birth_places"]["buckets"];
        array_unshift($rough_data, array("key"=>"Origin", "doc_count"=>""));

        foreach ($rough_data as $k=>$v){
            if ($k==0){
                $rough_data[$k] = array(
                    'key' => 'Origin',
                    'parent'=>'',
                    'doc_count'=> '',
                );
            }
            elseif ($k!=0){
                $rough_data[$k] = array(
                    'key' => $v['key'],
                    'parent'=>'Origin',
                    'doc_count'=> $v['doc_count'],
                );
            }
        }

        $prepared = array_map(function($tag) {
            return array(
                'name' => $tag['key'],
                'parent'=>$tag['parent'],
                'value' => $tag['doc_count']
            );
        }, $rough_data);

        //The data for word cloud
        $rough_data_cloud = $result["aggregations"]["birth_places"]["buckets"];
        $cloud = array_map(function($tag) {
            return array(
                'word' => $tag['key'],
                'size' => $tag['doc_count']
            );
        }, $rough_data_cloud);

        $rough_data_bar = $result["aggregations"]["birth_places"]["buckets"];
        $bar_data = array_map(function($tag) {
            return array(
                'word' => $tag['key'],
                'size' => $tag['doc_count']
            );
        }, $rough_data_bar);

        $page_title = "Statistics and diagrams. List of occupations in ".ucfirst($term_label);
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Birth places by occupations', '/birth_places-by-occupations/'],
            [$term_label, "/birth_places-by-one-occupation/$term_label/"],
        ]);

        if (empty($result["aggregations"]["birth_places"]["buckets"])) {
            $app->abort(404, "Post $term_label does not exist.");
        }

//        $paginator = new Paginator($basePath, $result['hits']['total'], $page, $size);

        //Get few names for list in description
        $top_birth_places = array_map(function ($p) {
            /** @var PersonWrapper $p */
            return $p["key"];
        }, \array_slice($result["aggregations"]["birth_places"]["buckets"], 0, 10));

        $seo_birth_places = implode(", ", $top_birth_places);

        if ($page === '_json'){
            return $app->json($prepared);
        }elseif ($page === '_cloud'){
            return $app->json($cloud);
        }elseif ($page === '_bar'){
            return $app->json($bar_data);
        }else {
            return $app['twig']->render('@responsive/CountriesByOneOccupation.twig', [
//                'paginator' => $paginator,
                'occupation_name' => $term,
                'num' => $num,
                'birth_places' => $result["aggregations"]["birth_places"]["buckets"],
                'page_title' => $page_title,
                'breadcrumbs' => $breadcrumbs,
                'page_keywords' => ['birth places', $term_label, "birth places in $term_label", "$term_label profession", $seo_birth_places],
                'page_description' => ["Statistics of birth places in $term_label. Main birth places in $term_label: $seo_birth_places"],
                'js_files' => ['static/js/d3.js', 'static/js/CountriesByOneOccupation.js', 'static/js/d3.layout.cloud.js']
            ]);
        }
    }
}