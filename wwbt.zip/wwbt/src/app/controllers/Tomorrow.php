<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Tomorrow extends DayList
{
    private $month = null;
    private $day = null;

    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "today"]);

        return $factory;
    }

    public function getTodayTimestamp()
    {
        return strtotime('tomorrow');
    }

    public function today(Request $request, Application $app, $page = 0)
    {
        $pageSize = 50;
        $persons = $this->getItems($page, $pageSize, $result);
        $paginator = new Paginator('/tomorrow/', $result['hits']['total'], $page, $pageSize);
        if (empty($persons)) {
            return $app['twig']->render('@responsive/List.twig', [
                'title' => 'Nobody Was Born Tomorrow',
                'persons' => [],
            ]);
        }

        $this->day = date('j', strtotime('tomorrow'));
        $this->month = date('n', strtotime('tomorrow'));

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Tomorrow', '/tomorrow'],
        ]);

        return $app['twig']->render('@responsive/List.twig', [
            'title' => 'Who Was Born Tomorrow',
            'persons' => $persons,
            'paginator' => $paginator,
            'month' => $this->month,
            'day' => $this->day,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['tomorrow', 'born tomorrow', 'people', 'famous people'],
            'page_description' => ["List of persons who was born tomorrow"],
        ]);
    }
}