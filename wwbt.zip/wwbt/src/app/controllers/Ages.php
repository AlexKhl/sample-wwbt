<?php

namespace diplux\app\controllers;

use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Ages implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'ages']);

        return $factory;
    }

    public function ages(Request $request, Application $app)
    {
        $cur_year = (int)date("Y");
        $year = $cur_year - 120;
        $query =
            ["bool" =>
                [
                    "must" => [
                        ["range" =>
                            [
                                "birth_date.year" => [
                                    "gte" => $year,
                                    "format" => "dd/MM/yyyy||yyyy",
                                ]
                            ]
                        ],
                        //["term" => ["alive" => "alive"]]
                    ],
                    "must_not" => [
                        ["exists" => ["field" => "death_date"]],
                        ["exists" => ["field" => "death_place"]],
                        ["exists" => ["field" => "death_cause"]],
                        ["term"   => ["alive" => ["value" => "dead"]]],
                        ["term"   => ["alive" => ["value" => "unknown"]]],
                    ]
                ]
            ];

        $result = ClientBuilder::create()->build()->search([
            'index' => 'person',
            'body' => [
                'size' => 0,
                'query' => $query,
                'aggs' => [
                    "birth_date.year" => [
                        "terms" => [
                            "field" => "birth_date.year",
                            "size" => 2000,
                            "order" => [
                                "_key" => "desc"
                            ]
                        ]
                    ]
                ],
            ]
        ]);
        $ages_result = $result['aggregations']['birth_date.year']['buckets'];
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Ages', '/ages/']
        ]);

        return $app['twig']->render('@responsive/Ages.twig', [
            'ages' => $ages_result,
            'title' => "Ages",
            'breadcrumbs' => $breadcrumbs,
            'page_address' => "/ages",
            'page_keywords' => ['famous persons', 'famous birthdays', 'famous people', 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people is here. Filter people by first letter ans use the pagination to find needed info.'],
        ]);
    }
}