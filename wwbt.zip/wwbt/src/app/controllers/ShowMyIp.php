<?php


namespace diplux\app\controllers;


use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

class ShowMyIp extends Common implements ControllerProviderInterface
{


    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "handleAddress"]);

        return $factory;
    }

    public function handleAddress(Request $request, Application $app){
        return $_SERVER['REMOTE_ADDR'];
    }

}