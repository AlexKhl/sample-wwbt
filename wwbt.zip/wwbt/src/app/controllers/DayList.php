<?php

namespace diplux\app\controllers;

use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Yaml\Parser;

abstract class DayList extends Common implements ControllerProviderInterface
{
    abstract public function getTodayTimestamp();

    abstract public function today(Request $request, Application $app, $page = 0);

    public function getItems($page = 0, $pageSize = 50, &$result)
    {
        if (empty($page) || !intval($page)) {
            $page = 0;
        }
        if ($page > 100) {
            $page = 0;
        }

        $personDao = \GetDao::Person();
        $entities = $personDao->loadByQuery([
            'size' => $pageSize,
            'from' => $pageSize * $page,
            'query' => ["bool" => ["must" => [
                ["term" => ["birth_date.month" => ["value" => date('n', $this->getTodayTimestamp())]]],
                ["term" => ["birth_date.day" => ["value" => date('j', $this->getTodayTimestamp())]]]
            ]]],
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ]
        ], $result);
        return $entities;
    }
}