<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Today extends DayList
{
    private $month = null;
    private $day = null;

    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "today"]);

        return $factory;
    }

    public function getTodayTimestamp()
    {
        return strtotime('today');
    }

    public function today(Request $request, Application $app, $page = 0)
    {
        $pageSize = 50;
        $persons = $this->getItems($page, $pageSize, $result);
        $paginator = new Paginator('/today/', $result['hits']['total'], $page, $pageSize);
        if (empty($persons)) {
            return $app['twig']->render('@responsive/List.twig', [
                'title' => 'Nobody Was Born Today',
                'persons' => [],
            ]);
        }

        $this->day = date('j', strtotime('today'));
        $this->month = date('n', strtotime('today'));

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Today', '/today'],
        ]);

        return $app['twig']->render('@responsive/List.twig', [
            'title' => 'Who Was Born Today',
            'persons' => $persons,
            'paginator' => $paginator,
            'month' => $this->month,
            'day' => $this->day,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['today', 'born today', 'people', 'famous people'],
            'page_description' => ["List of persons who was born today"],
        ]);
    }
}