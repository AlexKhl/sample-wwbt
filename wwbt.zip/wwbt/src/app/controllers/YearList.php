<?php

namespace diplux\app\controllers;

use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

abstract class YearList implements ControllerProviderInterface
{
    abstract public function main(Request $request, Application $app, $page = 0);

    public function getTodayTimestamp()
    {
        return strtotime('today');
    }

    public function getItems($page = 0, $pageSize = 50, &$result)
    {
        if (empty($page) || !(int)$page) {
            $page = 0;
        }
        if ($page > 100) {
            $page = 0;
        }

        $personDao = \GetDao::Person();
        $entities = $personDao->loadByQuery([
            'size' => $pageSize,
            'from' => $pageSize * $page,
            'query' => ["bool" => ["must" => [
                ["term" => ["birth_date.year" => ["value" => date('y', $this->getTodayTimestamp())]]],
                ["term" => ["birth_date.day" => ["value" => date('j', $this->getTodayTimestamp())]]]
            ]]],
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ]
        ], $result);
        return $entities;
    }

}