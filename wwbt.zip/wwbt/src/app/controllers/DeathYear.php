<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class DeathYear implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "main"]);

        return $factory;
    }

    public function main(Request $request, Application $app, $year, $page = 0)
    {
        $size = 30;
        $persons = \GetDao::Person()->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => [
                'term' => [
                    'death_date.year' => $year
                ],
            ]
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        $page_address = "/persons";

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Death Years', '/death-years/'],
            [$year, $year],
        ]);

        return $app['twig']->render('@responsive/DeathYear.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/death-year/$year", $result['hits']['total'], $page, $size),
            'title' => "Who Was Dead In $year",
            'breadcrumbs' => $breadcrumbs,
            'page_address' => $page_address,
            'char' => $year,
            'page_keywords' => ['famous persons dead in ' . $year, 'famous death years', 'famous people dead in ' . $year, 'celebs deaths', 'celebrities'],
            'page_description' => ['The list of famous people is here. You can see people who dead in specific year. Here you can see information about ' . $year . ' year.'],
        ]);
    }
}