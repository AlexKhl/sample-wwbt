<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Search implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "search"]);
        $factory->post('/', [$this, "search"]);

        return $factory;
    }

    public function search(Request $request, Application $app, $query = '', $page = 0)
    {
        if ($request->getMethod() == 'POST') {
            $query = trim($request->request->get('query'));
            return $app->redirect("/search/" . urlencode($query));
        }
        $query = urldecode($query);
        $query = trim($query);
        $size = 30;
        if (empty($query)) {
            $persons = [];
            $total = 0;
        } else {
            $query2 = strtolower($query);
            $persons = \GetDao::Person()->loadByQuery([
                'size' => $size,
                'from' => $page * $size,
                'query' => [
                    'multi_match' => [
                        "query" => $query2,
                        "fields" => [
                            'name',
                            'page_metadata.title',
                            'birth_name',
                            'native_name',
                            'source_page_title',
                            'url',
                        ]
                    ],
                ]
            ], $result);
            $total = $result['hits']['total'];
        }

        $page_address = "/search";

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Search', '/search/'],
            [$query, "/search/$query/"],
        ]);

        return $app['twig']->render('@responsive/Year.twig', [
            'persons' => $persons,
            'search_query' => $query,
            'paginator' => new Paginator("/search/$query", $total, $page, $size),
            'title' => "Search results for '$query'",
            'breadcrumbs' => $breadcrumbs,
            'page_address' => $page_address,
            'page_keywords' => ["famous persons born for $query", 'famous birthday years', "famous people born in $query", 'celebs birthdays', 'celebrities'],
            'page_description' => ["The list of famous people is here. You can see people who born in specific year. Here you can see information about $query"],
        ]);
    }
}