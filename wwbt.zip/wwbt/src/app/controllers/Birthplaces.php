<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Birthplaces implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'birthplaces']);

        return $factory;
    }

    public function birthplaces(Request $request, Application $app)
    {
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Birth places', '/birthplaces/'],
        ]);

        $size = 1500;
        $result = ClientBuilder::create()->build()->search([
            'index' => 'person',
            'body' => [
                'size' => 0,
                'aggs' => [
                    "birth_place" => [
                        "terms" => [
                            "field" => "birth_place.keyword",
                            "size" => $size,
                        ]
                    ]
                ],
            ]
        ]);
        if (empty($result['aggregations']['birth_place']["buckets"])) {
            $app->abort(404, "Page does not exist.");
        }
        $categories = [];
        foreach ($result['aggregations']['birth_place']["buckets"] as $k => $item) {
            $categories[$k] = $item;
        }
        $title = "List of birth places";

        $top_categories = [];
        foreach (array_slice($categories, 0, 20) as $c) {
            $top_categories[] = $c["key"];
        }
        $seo_categories = implode(", ", $top_categories);
        return $app['twig']->render('@responsive/Birthplaces.twig', [
            'title' => $title,
            'categories' => $categories,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['countries of births', 'states of births', 'cities of births', 'countries', 'cities'],
            'page_description' => ["List of birthplaces of famous persons. For example: $seo_categories"],
        ]);
    }

}