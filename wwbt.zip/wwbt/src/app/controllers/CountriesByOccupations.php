<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class CountriesByOccupations extends Common implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'countries_by_occupations']);

        return $factory;
    }

    public function countries_by_occupations(Request $request, Application $app, $page = 0)
    {
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Birth places by occupations', '/birth_places-by-occupations/'],
        ]);

        $size = 150;
        $result = ClientBuilder::create()->build()->search([
            'index' => 'person',
            'body' => [
                'size' => 0,
                'aggs' => [
                    "birth_place" => [
                        "terms" => [
                            "field" => "occupation.keyword",
                            "size" => $size,
                        ]
                    ]
                ],
            ]
        ]);
        if (empty($result['aggregations']['birth_place']["buckets"])) {
            $app->abort(404, "Page does not exist.");
        }
        $birth_place = $result['aggregations']['birth_place']["buckets"];
        $title = "List of countries";
        $top_birth_places = array_map(function ($c) {
            return $c["key"];
        }, array_slice($birth_place, 0, 20));
        $seo_birth_places = implode(", ", $top_birth_places);
        return $app['twig']->render('@responsive/CountriesByOccupations.twig', [
            'title' => $title,
            'birth_places' => $birth_place,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['occupations', 'different professions', 'find occupation'],
            'page_description' => ["List of occupations With statistics in countries. For example: $seo_birth_places"],
        ]);
    }
}