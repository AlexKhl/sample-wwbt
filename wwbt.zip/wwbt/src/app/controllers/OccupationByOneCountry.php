<?php

namespace diplux\app\controllers;

use diplux\app\entity\PersonWrapper;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

class OccupationByOneCountry extends Common implements ControllerProviderInterface
{
    private $day;
    private $month;

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'occupation_by_one']);

        return $factory;
    }

    public function occupation_by_one(Request $request, Application $app, $term = null, $page = null, $num = null)
    {
        $daoPerson = \GetDao::Person();

        $term_label = strip_tags($term);

        if (!$page){
            $page = 1;
        }

        if (!is_numeric($num) || $num == null || $num == false){
            $num = 30;
        }

        $query =
            [
                "bool" => [
                    "must" => [
                        ['term' => ['country.country.keyword' => ['value' => $term]]],
                    ]
                ]
            ];

        $aggs = [
            "occupations" => [
                "terms" => [
                    "field" => "occupation.keyword",
                    "size" => $num,
                    "min_doc_count" => 2
                ]
            ]
        ];

        $persons = $daoPerson->loadByQuery([
            "size" => 0,
            'aggs' => $aggs,
            'query' => $query,
        ], $result);


        //The data for TreeMap
        $rough_data = $result["aggregations"]["occupations"]["buckets"];
        array_unshift($rough_data, array("key"=>"Origin", "doc_count"=>""));

        foreach ($rough_data as $k=>$v){
            if ($k==0){
                $rough_data[$k] = array(
                    'key' => 'Origin',
                    'parent'=>'',
                    'doc_count'=> '',
                );
            }
            elseif ($k!=0){
                $rough_data[$k] = array(
                    'key' => $v['key'],
                    'parent'=>'Origin',
                    'doc_count'=> $v['doc_count'],
                );
            }
        }

        $prepared = array_map(function($tag) {
            return array(
                'name' => $tag['key'],
                'parent'=>$tag['parent'],
                'value' => $tag['doc_count']
            );
        }, $rough_data);

        //The data for word cloud
        $rough_data_cloud = $result["aggregations"]["occupations"]["buckets"];
        $cloud = array_map(function($tag) {
            return array(
                'word' => $tag['key'],
                'size' => $tag['doc_count']
            );
        }, $rough_data_cloud);

        $rough_data_bar = $result["aggregations"]["occupations"]["buckets"];
        $bar_data = array_map(function($tag) {
            return array(
                'word' => $tag['key'],
                'size' => $tag['doc_count']
            );
        }, $rough_data_bar);

        $page_title = "Statistics and diagrams. List of occupations in ".ucfirst($term_label);
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Occupations by countries', '/occupations-by-countries/'],
            [$term_label, "/occupation-by-one/$term_label/"],
        ]);

        if (empty($result["aggregations"]["occupations"]["buckets"])) {
            $app->abort(404, "Post $term_label does not exist.");
        }

//        $paginator = new Paginator($basePath, $result['hits']['total'], $page, $size);

        //Get few names for list in description
        $top_occupations = array_map(function ($p) {
            /** @var PersonWrapper $p */
            return $p["key"];
        }, \array_slice($result["aggregations"]["occupations"]["buckets"], 0, 10));

        $seo_occupations = implode(", ", $top_occupations);

        if ($page === '_json'){
            return $app->json($prepared);
        }elseif ($page === '_cloud'){
            return $app->json($cloud);
        }elseif ($page === '_bar'){
            return $app->json($bar_data);
        }else {
            return $app['twig']->render('@responsive/OccupationByOneCountry.twig', [
//                'paginator' => $paginator,
                'country_name' => $term,
                'num' => $num,
                'occupations' => $result["aggregations"]["occupations"]["buckets"],
                'page_title' => $page_title,
                'breadcrumbs' => $breadcrumbs,
                'page_keywords' => ['occupations', $term_label, "occupations in $term_label", "$term_label profession", $seo_occupations],
                'page_description' => ["Statistics of occupations in $term_label. Main occupations in $term_label: $seo_occupations"],
                'js_files' => ['static/js/d3.js', 'static/js/OccupationByOneCountry.js', 'static/js/d3.layout.cloud.js']
            ]);
        }
    }
}