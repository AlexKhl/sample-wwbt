<?php

namespace diplux\app\controllers;

use diplux\app\entity\PersonWrapper;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

class Occupation extends Common implements ControllerProviderInterface
{
    private $day;
    private $month;

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'occupation']);

        return $factory;
    }

    public function occupation(Request $request, Application $app, $term = null, $day = null, $page = null)
    {
        $size = 30;
        $term_label = strip_tags($term);
        if (!is_numeric($page)) {
            $page = 0;
        }

        //Switching of days filter "today", "tomorrow"
        switch ($day) {
            //TODO: add to UI
            case 'today':
            case 'tomorrow':
            case 'yesterday':
                $this->day = date('j', strtotime($day));
                $this->month = date('n', strtotime($day));

                $query = ["bool" => ["must" => [
                    ['term' => ["birth_date.month" => ["value" => intval($this->month)]]],
                    ['term' => ["birth_date.day" => ["value" => intval($this->day)]]],
                    ['term' => ['occupation.keyword' => $term_label]],
                ]]];

                $basePath = "/occupation/$term_label/$day/";
                $page_title = "List of $term_label who was born today";

                $breadcrumbs = new BreadCrumbs([
                    ['Home', '/'],
                    ['Occupation', '/occupation/'],
                    [$term_label, "/occupation/$term_label/"],
                    [ucwords($day), "/occupation/$term_label/$day/"],
                ]);

                break;
            default:
                $query = [
                    'term' => [
                        'occupation.keyword' => $term_label
                    ],
                ];

                $basePath = "/occupation/$term_label/";
                $page_title = "List of $term_label";
                $breadcrumbs = new BreadCrumbs([
                    ['Home', '/'],
                    ['Occupation', '/occupation/'],
                    [$term_label, "/occupation/$term_label/"],
                ]);
                break;
        }

        $persons = \GetDao::Person()->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "Post $term_label does not exist.");
        }

        $paginator = new Paginator($basePath, $result['hits']['total'], $page, $size);

        //Get few names for list in description
        $top_persons = array_map(function ($p) {
            /** @var PersonWrapper $p */
            return $p->anyName();
        }, \array_slice($persons, 0, 10));

        $seo_persons = implode(", ", $top_persons);

        return $app['twig']->render('@responsive/Occupation.twig', [
            'paginator' => $paginator,
            'persons' => $persons,
            'page_title' => $page_title,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['occupation', $term_label, "people of $term_label profession", "$term_label person"],
            'page_description' => ["List of persons in $term_label occupation. Look at them and find useful information. For example: $seo_persons"],
        ]);
    }
}