<?php

namespace diplux\app\controllers;


use diplux\app\entity\PersonWrapper;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Birthplace implements ControllerProviderInterface
{
    private $day;
    private $month;

    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'birthplaces']);

        return $factory;
    }

    public function birthplaces(Request $request, Application $app, $term = null, $day = null, $page = null)
    {
        $size = 30;
        $term_label = strip_tags($term);
        if (!is_numeric($page)) {
            $page = 0;
        }

        //Switching of days filter "today", "tomorrow"
        switch ($day) {
            //TODO: add to UI
            case 'today':
            case 'tomorrow':
            case 'yesterday':
                $this->day = date('j', strtotime($day));
                $this->month = date('n', strtotime($day));

                $query = ["bool" =>
                    ["must" => [
                        ['term' => ["birth_date.month" => ["value" => intval($this->month)]]],
                        ['term' => ["birth_date.day" => ["value" => intval($this->day)]]],
                        ['term' => ['birth_place.keyword' => $term_label]],
                    ]]];

                $basePath = "/birthplaces/$term_label/$day/";
                $page_title = "Who was born $day in $term_label";

                $breadcrumbs = new BreadCrumbs([
                    ['Home', '/'],
                    ['Birthplaces', '/birthplaces/'],
                    [$term_label, "/birthplaces/$term_label/"],
                    [ucwords($day), $basePath],
                ]);
                break;

            default:
                $query = [
                    'term' => [
                        'birth_place.keyword' => $term_label
                    ],
                ];

                $basePath = "/birthplaces/$term_label/";
                $page_title = "Who was born in $term_label";

                $breadcrumbs = new BreadCrumbs([
                    ['Home', '/'],
                    ['Birthplaces', '/birthplaces/'],
                    [$term_label, $basePath],
                ]);

                break;
        }

        $persons = \GetDao::Person()->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query
        ], $result);


        if (empty($persons)) {
            $app->abort(404, "Post $term does not exist.");
        }

        $paginator = new Paginator($basePath, $result['hits']['total'], $page, $size);

        //Get few names for list in description
        $per = array_map(function ($p) {
            /** @var PersonWrapper $p */
            return $p->anyName();
        }, \array_slice($persons, 0, 15));
        $few_persons = implode(", ", $per);
        //Page description
        $page_description = ["List of persons was born in " . $term_label . " . For example: " . $few_persons];
        //Page keywords
        $page_keywords = ['birth place', $term_label, 'people born in ' . $term_label . '', 'who was born in ' . $term_label];

        return $app['twig']->render('@responsive/Birthplace.twig', [
            'paginator' => $paginator,
            'persons' => $persons,
            'page_title' => $page_title,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => $page_keywords,
            'page_description' => $page_description,
        ]);
    }

}