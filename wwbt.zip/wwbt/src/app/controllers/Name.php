<?php

namespace diplux\app\controllers;

use diplux\app\entity\PersonWrapper;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

class Name extends Common implements ControllerProviderInterface
{
    private $day;
    private $month;

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'name']);

        return $factory;
    }

    public function name(Request $request, Application $app, $name = null, $page = null)
    {
        $size = 30;
        $term_label = strip_tags($name);
        if (!is_numeric($page)) {
            $page = 0;
        }

        $query = [
            'term' => [
                'full_name.first_name.keyword' => $term_label
            ],
        ];

        $basePath = "/name/$term_label/";
        $page_title = "List of $term_label";
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Names', '/names/'],
            [$term_label, "/name/$term_label/"],
        ]);



        $persons = \GetDao::Person()->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "Post $term_label does not exist.");
        }

        $paginator = new Paginator($basePath, $result['hits']['total'], $page, $size);

        //Get few names for list in description
        $top_persons = array_map(function ($p) {
            /** @var PersonWrapper $p */
            return $p->anyName();
        }, \array_slice($persons, 0, 10));

        $seo_persons = implode(", ", $top_persons);

        return $app['twig']->render('@responsive/Name.twig', [
            'paginator' => $paginator,
            'persons' => $persons,
            'page_title' => $page_title,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['name', $term_label, "people of $term_label profession", "$term_label person"],
            'page_description' => ["List of persons in $term_label name. Look at them and find useful information. For example: $seo_persons"],
        ]);
    }
}