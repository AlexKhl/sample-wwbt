<?php

namespace diplux\app\controllers;

use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;

class Club27 implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'main']);

        return $factory;
    }

    public function main(Request $request, Application $app, $page = 0){
        $daoPerson = \GetDao::Person();
        $size = 30;
        $title = 'Club 27';
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Club 27', '/club27/'],
        ]);

        $query =
            [
                "bool" =>[
                    "must" => [
                        [
                            'term' => [
                                'aged' => ["value" => 27],
                            ]
                        ],
                    ],
                    "must_not" => [
                        ["term"   => ["alive" => ["value" => "alive"]]],
                        ["term"   => ["alive" => ["value" => "unknown"]]],
                    ]
                ],
            ];

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
            "sort" => [[
                "birth_date.date" => [
                    "order" => "desc"
                ]]
            ],
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        return $app['twig']->render('@responsive/Club27.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/club27", $result['hits']['total'], $page, $size),
            'title' => $title,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['famous persons', 'famous centenarians', 'famous people', 'celebs centenarians', 'celebrities', 'centenarians', 'hundred years people'],
            'page_description' => ['The list of famous people who are more than 100 years old.'],
        ]);
    }
}