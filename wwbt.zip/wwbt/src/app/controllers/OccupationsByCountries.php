<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use Elasticsearch\ClientBuilder;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class OccupationsByCountries extends Common implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'occupations_by_countries']);

        return $factory;
    }

    public function occupations_by_countries(Request $request, Application $app, $page = 0)
    {
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Occupations by countries', '/occupations-by-countries/'],
        ]);

        $size = 150;
        $result = ClientBuilder::create()->build()->search([
            'index' => 'person',
            'body' => [
                'size' => 0,
                'aggs' => [
                    "occupation" => [
                        "terms" => [
                            "field" => "country.country.keyword",
                            "size" => $size,
                        ]
                    ]
                ],
            ]
        ]);
        if (empty($result['aggregations']['occupation']["buckets"])) {
            $app->abort(404, "Page does not exist.");
        }
        $occupations = $result['aggregations']['occupation']["buckets"];
        $title = "List of countries";
        $top_occupations = array_map(function ($c) {
            return $c["key"];
        }, array_slice($occupations, 0, 20));
        $seo_occupations = implode(", ", $top_occupations);
        return $app['twig']->render('@responsive/OccupationsByCountries.twig', [
            'title' => $title,
            'occupations' => $occupations,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['occupations', 'different professions', 'find occupation'],
            'page_description' => ["List of countries With statistics in occupations. For example: $seo_occupations"],
        ]);
    }
}