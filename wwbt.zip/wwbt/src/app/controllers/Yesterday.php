<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class Yesterday extends DayList
{
    private $month = null;
    private $day = null;

    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "today"]);

        return $factory;
    }

    public function getTodayTimestamp()
    {
        return strtotime('yesterday');
    }

    public function today(Request $request, Application $app, $page = 0)
    {
        $pageSize = 50;
        $persons = $this->getItems($page, $pageSize, $result);
        $paginator = new Paginator('/yesterday/', $result['hits']['total'], $page, $pageSize);
        if (empty($persons)) {
            return $app['twig']->render('@responsive/List.twig', [
                'title' => 'Nobody Was Born Yesterday',
                'persons' => [],
            ]);
        }

        $this->day = date('j', strtotime('yesterday'));
        $this->month = date('n', strtotime('yesterday'));

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Yesterday', '/yesterday'],
        ]);

        return $app['twig']->render('@responsive/List.twig', [
            'title' => 'Who Was Born Yesterday',
            'persons' => $persons,
            'paginator' => $paginator,
            'month' => $this->month,
            'day' => $this->day,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['yesterday', 'born yesterday', 'people', 'famous people'],
            'page_description' => ["List of persons who was born yesterday"],
        ]);
    }
}