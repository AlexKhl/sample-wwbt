<?php

namespace diplux\app\controllers;


use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;
use Symfony\Component\HttpFoundation\Request;

use diplux\templates\Paginator;

class Development extends Common implements ControllerProviderInterface
{

    /**
     * Returns routes to connect to the given application.
     *
     * @param Application $app An Application instance
     *
     * @return ControllerCollection A ControllerCollection instance
     */
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "devel"]);

        return $factory;
    }

    public function devel(Request $request, Application $app, $page = 0)
    {
        $breadcrumbs = $this->renderBreadcrumbs($request, 2);
        $daoPerson = \GetDao::Person();
        $size = 20;

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ],
            'aggs' => [
                "occupation" => [
                    "terms" => [
                        "field" => "occupation.keyword",
                        "size" => 50,
                    ]
                ]
            ],
        ], $result);

        /*$app->register(new FormServiceProvider());
        $data = array(
            'name' => 'Your name',
            'email' => 'Your email',
        );

        $form = $app['form.factory']->createBuilder(FormType::class, $data)
            ->add('name')
            ->add('email')
            ->add('billing_plan', ChoiceType::class, array(
                'choices' => array('free' => 1, 'small business' => 2, 'corporate' => 3),
                'expanded' => true,
            ))
            ->add('submit', SubmitType::class, [
                'label' => 'Save',
            ])
            ->getForm();
        $form->handleRequest($request);

        if ($form->isValid()) {
            $data = $form->getData();

            // do something with the data

            // redirect somewhere
            return $app->redirect('/devel');
        }*/

        $paginator = new Paginator("/devel/", $result['hits']['total'], $page, $size);
        $title = "Development section";

        $occups = $result['aggregations']['occupation']["buckets"];

        return $app['twig']->render('@responsive/Devel.twig', [
            'persons' => $persons,
            'paginator' => $paginator,
            'title' => $title,
            //'form' => $form->createView(),
            'breadcrumbs' => $breadcrumbs,
            'occups' => $occups,
        ]);
    }
}