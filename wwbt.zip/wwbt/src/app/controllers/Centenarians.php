<?php

namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Centenarians implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, 'main']);

        return $factory;
    }

    public function main(Request $request, Application $app, $page = 0)
    {
        $daoPerson = \GetDao::Person();
        $size = 30;
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Centenarians', '/centenarians/'],
        ]);

        $age = 100;
        $boundary = date("d/m/Y", strtotime("-$age year"));

        $query =
            [
                "bool" => [
                    "must" => [
                        ["range" =>
                            ["birth_date.date" =>
                                [
                                    "lte" => $boundary,
                                    "format" => "dd/MM/yyyy||yyyy"
                                ]
                            ]
                        ]
                    ],
                    "must_not" => [
                        ["exists" => ["field" => "death_date"]],
                        ["exists" => ["field" => "death_place"]],
                        ["exists" => ["field" => "death_cause"]],
//                        ["term" => ["alive" => ["value" => "dead"]]],
//                        ["term" => ["alive" => ["value" => "unknown"]]],
                        ["terms" => ["alive" => ["_null_", "unknown", "dead", "null"]]],
                    ]
                ]
            ];

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ],
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        return $app['twig']->render('@responsive/Centenarians.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/centenarians", $result['hits']['total'], $page, $size),
            'title' => 'Centenarians',
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['famous persons', 'famous centenarians', 'famous people', 'celebs centenarians', 'celebrities', 'centenarians', 'hundred years people'],
            'page_description' => ['The list of famous people who are more than 100 years old.'],
        ]);
    }
}