<?php

namespace diplux\app\controllers;

use diplux\app\entity\PersonWrapper;
use diplux\app\widgets\Aggregations;
use diplux\templates\BreadCrumbs;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class Person extends Common implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "handleAddress"]);

        return $factory;
    }

    public function handleAddress(Request $request, Application $app, $id)
    {
        /** @var PersonWrapper[] $personsWithSameUrlCode */
        $personsWithSameUrlCode = \GetDao::Person()->loadByQuery([
            'query' => [
                'term' => [
                    'url.keyword' => [
                        'value' => $id
                    ]
                ]
            ]]);

        if (empty($personsWithSameUrlCode)) {
            return $this->returnAlternatives($request, $app, $id);
        }

        return $this->person($personsWithSameUrlCode, $app);
    }

    /**
     * @param PersonWrapper[] $personsWithSameUrlCode
     * @param Application $app
     * @return mixed
     */
    private function person($personsWithSameUrlCode, Application $app)
    {

        if (count($personsWithSameUrlCode) > 1) {
            //\d($personsWithSameUrlCode);//TODO:Deploy
            //TODO: put log warning
            assert(true);
        }

        //Name to keyword
        $page_keywords = [$personsWithSameUrlCode[0]->anyName(), 'biography', 'personality', 'famous person'];

        //Occupations to keyword
        foreach ($personsWithSameUrlCode[0]->getOccupations() as $occ) {
            $page_keywords[] = $occ['name'];
        }

        //Birthplace to keyword
        $birth_place = $personsWithSameUrlCode[0]->__get("birth_place");
        if ($birth_place !== null && is_array($birth_place)) {
            foreach ($birth_place as $bp) {
                $page_keywords[] = $bp;
            }
        } elseif (!is_array($birth_place) && is_string($birth_place)) {
            $page_keywords = [$birth_place];
        }

        //Page description
        $page_description = [$personsWithSameUrlCode[0]->anyName()];
        //Sentence description
        $array = explode('.', $personsWithSameUrlCode[0]->__get('bio'));
        $sentence = strip_tags($array[0]);
        $page_description[] = $sentence;

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Persons', '/persons/'],
            [$personsWithSameUrlCode[0]->anyName(), $personsWithSameUrlCode[0]->__get('url')[0]],
        ]);
        $person = $personsWithSameUrlCode[0];

        $widgets = new Aggregations($app, $person);
        $born_on_widget = $widgets->bornOn();
        $years_old_widget = $widgets->yearsOld();
        $birth_year_widget = $widgets->birthYear();
        $death_year_widget = $widgets->deathYear();
        $club27_widget = $widgets->club27();
        $centenarian = $widgets->centenarian();
        $name_widget = $widgets->name();

        return $app['twig']->render('@responsive/Person.twig', [
            'person' => $person,
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => $page_keywords,
            'page_description' => $page_description,
            'born_on_widget' => $born_on_widget,
            'years_old_widget' => $years_old_widget,
            'birth_year_widget' => $birth_year_widget,
            'death_year_widget' => $death_year_widget,
            'club27_widget' => $club27_widget,
            'centenarian' => $centenarian,
            'name_widget' => $name_widget,
        ]);
    }

    private function returnAlternatives(Request $request, Application $app, $id)
    {
        $args = array_filter(explode('/', $request->getPathInfo()));
        $str = $args[2];

        $daoPerson = \GetDao::Person();
        $size = 150;

        $query = [
            "bool" => [
                "should" => [[
                    'regexp' => [
                        'url.keyword' => ".*$str.*",
                    ]
                ],
                ],
            ],
        ];

        /**
         * @var PersonWrapper[] $persons
         */
        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'query' => $query,
            "sort" => [[
                "name" => [
                    "order" => "desc"
                ]]
            ],
        ], $result);

        switch (count($persons)) {
            case 0:
                return $app->abort(404, 'Your link couldn\'t return any page on the site');
            case 1:
                return $app->redirect($persons[0]->renderUrl('view'));
            default:
                $categories = [];
                foreach ($result['hits']['hits'] as $k => $item) {
                    $categories[$k] = $item;
                }
                $title = "Search results";
                $no_person = "Your link couldn't return any page on the site. There are alternative results below.";
                $breadcrumbs = new BreadCrumbs([
                    ['Home', '/'],
                    ['Persons', '/persons/'],
                    ['Search results', '/persons/'],
                ]);
                return $app['twig']->render('@responsive/AltPage.twig', [
                    'title' => $title,
                    'persons' => $persons,
                    'no_person' => $no_person,
                    'breadcrumbs' => $breadcrumbs,
                ]);
        }
    }
}