<?php


namespace diplux\app\controllers;

use diplux\templates\BreadCrumbs;
use diplux\templates\Paginator;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;

class BirthDead implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];

        $factory->get('/', [$this, "birthDead"]);

        return $factory;
    }

    public function birthDead(Request $request, Application $app, int $page = 0)
    {
        $daoPerson = \GetDao::Person();
        $size = 30;
        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Died in birthday', '/died-in-birthday/'],
        ]);

        $query =
            ["bool" => [
                "must" => [
                    ["script" =>
                        [
                            "script" => "doc['birth_date.month'].value == doc['death_date.month'].value && doc['birth_date.day'].value == doc['death_date.day'].value"
                        ]
                    ]
                ]
            ]];

        $persons = $daoPerson->loadByQuery([
            'size' => $size,
            'from' => $page * $size,
            'query' => $query,
            "sort" => [[
                "counter_in" => [
                    "order" => "desc"
                ]]
            ],
        ], $result);

        if (empty($persons)) {
            $app->abort(404, "This page does not exist.");
        }

        return $app['twig']->render('@responsive/Persons.twig', [
            'persons' => $persons,
            'paginator' => new Paginator("/died-in-birthday", $result['hits']['total'], $page, $size),
            'title' => 'People died in their birthdays',
            'breadcrumbs' => $breadcrumbs,
            'page_keywords' => ['famous persons', 'famous birthdays', 'famous people', 'celebs birthdays', 'celebrities'],
            'page_description' => ['The list of famous people is here. Filter people by first letter ans use the pagination to find needed info.'],
        ]);
    }

}