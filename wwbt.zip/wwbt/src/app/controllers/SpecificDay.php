<?php

namespace diplux\app\controllers;

use diplux\templates\Paginator;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use diplux\templates\BreadCrumbs;

class SpecificDay extends DayList
{
    private $month = null;
    private $day = null;
    private $basePath = '';


    public function connect(Application $app)
    {
        $factory = $app['controllers_factory'];
        $factory->get('/', [$this, "today2"]);
        return $factory;
    }

    public function getTodayTimestamp()
    {
        return strtotime("2018-{$this->month}-{$this->day}");
    }

    public function today2(Request $request, Application $app, $monthday = null, $page = 0)
    {
        if (!isset($monthday) || $monthday == null || $monthday == '') {
            $rand_timestamp = mt_rand(-13093183090, 1517748157);
            $monthday = strtolower(date('M', $rand_timestamp));
        }
        $monthNames = [
            'jan' => 1,
            'january' => 1,
            'feb' => 2,
            'february' => 2,
            'mar' => 3,
            'march' => 3,
            'apr' => 4,
            'april' => 4,
            'may' => 5,
            'jun' => 6,
            'june' => 6,
            'jul' => 7,
            'july' => 7,
            'aug' => 8,
            'august' => 8,
            'sep' => 9,
            'september' => 9,
            'oct' => 10,
            'october' => 10,
            'nov' => 11,
            'november' => 11,
            'dec' => 12,
            'december' => 12,
        ];

        $md = $this->transferDate($monthday);
        $month = ltrim($md['m'], '0');
        $day = ltrim($md['d'], '0');

        if (is_numeric($month) && 1 <= (int)($month) && (int)($month) <= 12) {
            $this->month = $month;
        } elseif (in_array($month, array_keys($monthNames))) {
            $this->month = $monthNames[$month];
        } else {
            $app->abort(404, "Failed to recognize the date.");
        }

        if (is_numeric($day) && 1 <= (int)($day) && (int)($day) <= 31) {
            $this->day = $day;
            $path = implode("-", [$month, $day]);
        } else {
            $this->day = null;
            $path = $month;
        }
        $this->basePath = "/day/$path/";

        return $this->today($request, $app, $page);
    }

    public function today(Request $request, Application $app, $page = 0)
    {
        $date = [
            'm' => $this->month,
            'd' => $this->day,
        ];
        $pageSize = 50;
        $persons = $this->getItems($page, $pageSize, $result, $date);
        $paginator = new Paginator($this->basePath, $result['hits']['total'], $page, $pageSize);
        if (empty($result['hits']['hits'])) {
            return $app['twig']->render('@responsive/List.twig', [
                'title' => 'Nobody Was Born Tomorrow',
                'persons' => [],
            ]);
        }

        $breadcrumbs = new BreadCrumbs([
            ['Home', '/'],
            ['Day', '/day/'],
            [$this->month . "-" . $this->day, $this->month . "-" . $this->day],
        ]);

        return $app['twig']->render('@responsive/List.twig', [
            'title' => 'Who Was Born This Day',
            'persons' => $persons,
            'paginator' => $paginator,
            'month' => $this->month,
            'day' => $this->day,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function getItems($page = 0, $pageSize = 50, &$result, $params = array())
    {
        if (empty($page) || !intval($page)) {
            $page = 0;
        }
        if ($page > 100) {
            $page = 0;
        }

        $dateFilters = [];
        if ($this->month) {
            $dateFilters[] = ['term' => ["birth_date.month" => ["value" => intval($this->month)]]];
        }
        if ($this->day) {
            $dateFilters[] = ['term' => ["birth_date.day" => ["value" => intval($this->day)]]];
        }

        $personDao = \GetDao::Person();
        $entities = $personDao->loadByQuery([
            'size' => $pageSize,
            'from' => $pageSize * $page,
            'query' => ["bool" => ["must" => $dateFilters]],
            "sort" => [
                [
                    "name.keyword" => [
                        "order" => "asc"
                    ]
                ]
            ]
        ], $result);
        return $entities;
    }

    private function transferDate($monthday)
    {
        $monthday = explode('-', $monthday);

        if (!is_numeric($monthday[0])) {
            $month = date('m', strtotime($monthday[0]));
        } else
            $month = $monthday[0];

        $day = isset($monthday[1]) ? $monthday[1] : null;
        $date = array(
            'm' => $month,
            'd' => $day,
        );
        return $date;
    }
}