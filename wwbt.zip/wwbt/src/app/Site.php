<?php

namespace diplux\app;

use diplux\app\controllers\Club27;
use Silex;
use Symfony\Component\Debug\Debug;
use Symfony\Component\Debug\DebugClassLoader;
use Symfony\Component\Debug\ErrorHandler;
use Symfony\Component\Debug\ExceptionHandler;


class Site
{
    public function main($debug = false)
    {
        $app = new Silex\Application();

        if ($debug) {
            $app['debug'] = true;
            $app->register(new \Sorien\Provider\PimpleDumpProvider());
            Debug::enable();
            ErrorHandler::register();
            ExceptionHandler::register();
            DebugClassLoader::enable();
        }

        $app->register(new Silex\Provider\ServiceControllerServiceProvider());
        $app->register(new Silex\Provider\HttpFragmentServiceProvider());

        $app->register(new Silex\Provider\TwigServiceProvider(), [
            'twig.path' => [
                '../templates/responsive' => 'responsive',
                '../templates/amp' => 'amp',
                '../templates/sitemap' => 'sitemap',
            ],
            'twig.options' => [
                'strict_variables' => false
            ]
        ]);

        $app->register(new Silex\Provider\AssetServiceProvider(), [
            //'assets.version' => 'v1',
            //'assets.version_format' => '%s?version=%s',
            'assets.named_packages' => [
                'css' => ['version' => 'css3', 'base_path' => '/'],
                //'images' => array('base_urls' => array('images')),
                'js' => ['base_path' => '/']
            ],
        ]);

        $app->mount('/', new controllers\Index());

        $app->mount('/showmyip-Uph2quanFarr0', new controllers\ShowMyIp());

        $app->mount('person/{id}', new controllers\Person());
        $app->mount('persons', new controllers\Persons());
        $app->mount('persons/{char}', new controllers\Persons());
        $app->mount('persons/{char}/{page}', new controllers\Persons());

        $app->mount('occupation', new controllers\Occupations());
        //$app->mount('occupation', new controllers\Occupation());
        $app->mount('occupation/{term}', new controllers\Occupation());
        $app->mount('occupation/{term}/{page}', new controllers\Occupation());
        $app->mount('occupation/{term}/{day}', new controllers\Occupation());
        $app->mount('occupation/{term}/{day}/{page}', new controllers\Occupation());

        $app->mount('birthplaces', new controllers\Birthplaces());
        $app->mount('birthplaces/{term}', new controllers\Birthplace());
        $app->mount('birthplaces/{term}/{page}', new controllers\Birthplace());
        $app->mount('birthplaces/{term}/{day}', new controllers\Birthplace());
        $app->mount('birthplaces/{term}/{day}/{page}', new controllers\Birthplace());

        $app->mount('today', new controllers\Today());
        $app->mount('today/{page}', new controllers\Today());

        $app->mount('tomorrow', new controllers\Tomorrow());
        $app->mount('tomorrow/{page}', new controllers\Tomorrow());

        $app->mount('yesterday', new controllers\Yesterday());
        $app->mount('yesterday/{page}', new controllers\Yesterday());

        $app->mount('day', new controllers\SpecificDay());
        $app->mount('day/{monthday}', new controllers\SpecificDay());
        $app->mount('day/{monthday}/{page}', new controllers\SpecificDay());

        $app->mount('ages', new controllers\Ages());

        $app->mount('age/{age}', new controllers\Age());
        $app->mount('age/{age}/{page}', new controllers\Age());

        $app->mount('years', new controllers\Years());
        $app->mount('year/{year}', new controllers\Year());
        $app->mount('year/{year}/{page}', new controllers\Year());

        $app->mount('death-years', new controllers\DeathYears());
        $app->mount('death-year/{year}', new controllers\DeathYear());
        $app->mount('death-year/{year}/{page}', new controllers\DeathYear());

        $app->mount('centenarians', new controllers\Centenarians());
        $app->mount('centenarians/{page}', new controllers\Centenarians());

        $app->mount('club27', new controllers\Club27());
        $app->mount('club27/{page}', new controllers\Club27());

        $app->mount('died-in-birthday', new controllers\BirthDead());
        $app->mount('died-in-birthday/{page}', new controllers\BirthDead());

        $app->mount('name', new controllers\Name());
        $app->mount('name/{name}', new controllers\Name());
        $app->mount('name/{name}/{page}', new controllers\Name());
        $app->mount('names', new controllers\Names());
        $app->mount('names/{char}', new controllers\Names());
        $app->mount('names/{char}/{page}', new controllers\Names());

        $app->mount('search', new controllers\Search());
        $app->mount('search/{query}', new controllers\Search());
        $app->mount('search/{query}/{page}', new controllers\Search());

        //Statistics
        $app->mount('treemap', new controllers\TreeMap());
        $app->mount('treemap/{page}', new controllers\TreeMap());

        $app->mount('occupations-by-countries', new controllers\OccupationsByCountries());
        $app->mount('occupation-by-one-country/{term}', new controllers\OccupationByOneCountry());
        $app->mount('occupation-by-one-country/{term}/{page}', new controllers\OccupationByOneCountry());
        $app->mount('occupation-by-one-country/{term}/{page}/{num}', new controllers\OccupationByOneCountry());

        $app->mount('birth_places-by-occupations', new controllers\CountriesByOccupations());
        $app->mount('birth_places-by-one-occupation/{term}', new controllers\CountriesByOneOccupation());
        $app->mount('birth_places-by-one-occupation/{term}/{page}', new controllers\CountriesByOneOccupation());
        $app->mount('birth_places-by-one-occupation/{term}/{page}/{num}', new controllers\CountriesByOneOccupation());


//TODO: make them work on dev environment only
//        $app->mount('devel', new controllers\Development());
//        $app->mount('devel/{page}', new controllers\Development());

        $app->run();
    }
}
