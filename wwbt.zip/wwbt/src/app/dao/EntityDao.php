<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 17/01/18
 * Time: 12:21 PM
 */

namespace diplux\app\dao;


use diplux\app\entity\EntityWrapper;
use Elasticsearch\ClientBuilder;

abstract class EntityDao
{

    protected $index = '';
    protected $type = '';

    /**
     * @return EntityWrapper
     */
    abstract public function createEntity();

    public function loadByQuery($query, &$result = null)
    {
        $client = ClientBuilder::create()->build();
        $request = [
            'body' => $query
        ];
        if ($this->index) {
            $request['index'] = $this->index;
        }
        if ($this->type) {
            $request['type'] = $this->type;
        }
        $result = $client->search($request);
        $entities = [];
        foreach ($result['hits']['hits'] as $k => $item) {
            $entity = $this->createEntity();
            $entity->setData($item['_source']);
            $entity->setMeta($item);
            $entities[] = $entity;
        }

        $result['query'] = $query;
        $result['query_str'] = json_encode($query);
        return $entities;
    }

    public function scroll($query, $callback)
    {
        assert(is_callable($callback), "second argument is not callable");
        $this->scrollRaw($query, function ($doc) use ($callback) {
            $entity = $this->createEntity();
            $entity->setData($doc['_source']);
            $entity->setMeta($doc);
            $callback($entity);
        });
    }

    public function scrollRaw($query, $callback)
    {
        assert(is_callable($callback), "second argument is not callable");

        $client = ClientBuilder::create()->build();
        $request = [
            "scroll" => "30s",
            "size" => 1000,
            'body' => $query
        ];
        if ($this->index) {
            $request['index'] = $this->index;
        }
        if ($this->type) {
            $request['type'] = $this->type;
        }
        $response = $client->search($request);
        while (count($response['hits']['hits'])) {
            foreach ($response['hits']['hits'] as $doc) {
                $callback($doc);
            }
            $scrollParams = [
                'scroll_id' => $response['_scroll_id'],
                'scroll' => '30s'
            ];
            $response = $client->scroll($scrollParams);
        }

    }
}