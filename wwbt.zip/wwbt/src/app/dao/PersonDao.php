<?php

namespace diplux\app\dao;


use diplux\app\entity\EntityWrapper;
use diplux\app\entity\PersonWrapper;
use Elasticsearch\ClientBuilder;

class PersonDao extends EntityDao
{
    protected $index = 'person';
    protected $type = 'person';

    /**
     * @return EntityWrapper
     */
    public function createEntity(){
        return new PersonWrapper();
    }

}