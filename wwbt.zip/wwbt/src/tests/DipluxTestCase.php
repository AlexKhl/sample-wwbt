<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 30/12/17
 * Time: 1:49 PM
 */

namespace diplux\tests;


use PHPUnit\Framework\TestCase;


class DipluxTestCase extends TestCase
{
    protected function assertTextEquals($expectedText, $text, $message = '')
    {
        $expectedText = $this->normalizeText($expectedText);
        $text = $this->normalizeText($text);

        $this->assertEquals($expectedText, $text, $message);
    }

    protected function normalizeText($text)
    {
        $text = preg_replace('#=#', ' = ', $text);
        $text = preg_replace('#\|#', ' | ', $text);
        $text = preg_replace('#{{#', ' {{ ', $text);
        $text = preg_replace('#}}#', ' }} ', $text);
        $text = preg_replace('#[\s\t\n]+#', ' ', $text);

        return $text;
    }
}