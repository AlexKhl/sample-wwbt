<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 21/03/18
 * Time: 8:28 PM
 */

namespace diplux\parser;


class AstParserFactory
{
    public static function getAstParser()
    {
        if (class_exists('\Parser\AstParser')) {
            return new \Parser\AstParser();
        }
        echo 'nope';
        return new AstParser();
    }
}