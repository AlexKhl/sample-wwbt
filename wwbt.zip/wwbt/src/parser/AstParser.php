<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 18/03/18
 * Time: 8:16 PM
 */

namespace diplux\parser;


class AstParser
{

    public function parseText($text)
    {
        $tree = [];

        $matches = null;
        preg_match_all('#{{|}}#', $text, $matches);

        $stack = [];
        $posStart = 0;
        $posEnd = 0;
        foreach ($matches[0] as $match) {
            switch ($match) {
                case '{{':
                    $posEnd = strpos($text, $match, $posEnd);
                    if (count($stack) == 0) {
                        if ($posEnd != $posStart) {
                            $tree[] = trim(substr($text, $posStart, $posEnd - $posStart));
                        }
                        $posStart = $posEnd;
                    }
                    $posEnd += 2;
                    array_push($stack, $match);
                    break;
                case '}}':
                    array_pop($stack);
                    $posEnd = strpos($text, $match, $posEnd) + 2;
                    if (count($stack) == 0) {
                        $macrosText = trim(substr($text, $posStart, $posEnd - $posStart));
                        $tree[] = [
                            'type' => 'macros',
                            'text' => $macrosText,
                            'args' => $this->parseMacros(substr($macrosText, 2, -2)),
                        ];
                        $posStart = $posEnd;
                    }
                    break;
            }
        }
        if ($posEnd < strlen($text)) {
            $tree[] = trim(substr($text, $posStart));
        }

        if (count($tree) == 1 && array_key_exists(0, $tree) && !is_array($tree[0])) {
            return $tree[0];
        }

        return $tree;
    }

    public function parseMacros($text)
    {
        $matches = null;
        preg_match_all('#{{|\||}}|\[\[|\]\]#', $text, $matches);

        $macrosRawArguments = [];
        $macrosParsedArguments = [];
        $stack = [];
        $posStart = 0;
        $posEnd = 0;
        $pos = 0;
        foreach ($matches[0] as $match) {
            switch ($match) {
                case '{{':
                case '[[':
                    $pos = strpos($text, $match, $pos);
                    array_push($stack, $match);
                    break;
                case '}}':
                case ']]':
                    array_pop($stack);
                    $pos = strpos($text, $match, $pos) + 2;
                    break;
                case '|':
                    $pos = strpos($text, $match, $pos);
                    if (count($stack) == 0) {
                        $macrosRawArguments[] = trim(substr($text, $posStart, $pos - $posStart));
                        $pos += 1;
                        $posEnd = $pos;
                        $posStart = $posEnd;
                    }
                    break;
            }
        }
        if ($posEnd < strlen($text)) {
            $macrosRawArguments[] = substr($text, $posStart);
        }
        foreach ($macrosRawArguments as $arg) {
            $data = explode('=', $arg, 2);
            if (count($data) > 1 && !preg_match("#\[|\{#", $data[0])) {
                $parseText = $this->parseText(trim($data[1]));
                if (is_array($parseText) && count($parseText) == 1 && key_exists(0, $parseText)) {
                    $parseText = $parseText[0];
                }
                if (is_array($parseText) && count($parseText) == 0) {
                    $parseText = '';
                }
                $trimmed = trim($data[0]);
                $macrosParsedArguments[$trimmed] = $parseText;
            } else {
                $macrosParsedArguments[] = $this->parseText(trim($arg));
            }
        }
        $tree = $macrosParsedArguments;
        return $tree;
    }

}