<?php

namespace diplux\parser;

use DateTime;

class Extractor
{
    private $ast;


    /**
     * Extractor constructor.
     */
    public function __construct()
    {
        $this->ast = AstParserFactory::getAstParser();
    }

    public function splitMacroses($text)
    {
        $macroses = [];
        preg_match_all('#{{|}}#', $text, $matches);
        $cursor = 0;
        $stack = [];
        $posStart = null;
        $posEnd = null;
        foreach ($matches[0] as $match) {
            if ($match == '{{') {
                if (count($stack) == 0) {
                    $posStart = strpos($text, '{{', $cursor);
                    $cursor = $posStart + strlen('{{');
                }
                array_push($stack, $match);
            }
            if ($match == '}}') {
                $posEnd = strpos($text, '}}', $cursor) + strlen('{{');
                $cursor = $posEnd;
                array_pop($stack);
                if (count($stack) == 0) {
                    $macroses[] = substr($text, $posStart, $posEnd - $posStart);
                }
            }
        }
        return $macroses;
    }

    public function streamParser($file, $callback, $searchString = null)
    {
        if ($searchString) {
            $searchString = strtolower($searchString);
        }
        $reader = new \XMLReader();
        $reader->open($file);
        while ($reader->read()) {
            if ((int)($reader->nodeType) == \XMLReader::ELEMENT) {
                if (!$reader->isEmptyElement) {
                    if ($reader->name == 'page' && (empty($searchString) || strpos(strtolower($reader->readOuterXml()), $searchString) !== false)) {
                        $callback($reader->readOuterXml());
                    }
                }
            }
        }
        $reader->close();
    }

    public function extractDate($string)
    {
        if (empty($string)) {
            return null;
        }
        if (is_numeric($string)) {
            return [
                'date' => "$string",
                'key' => "",
                'year' => (int)($string),
                'month' => null,
                'day' => null,
                'original' => $string,
            ];
        }

        $macrosses = $this->splitMacroses($string);

        if (count($macrosses) == 0) {
            if ($stamp = strtotime($string)) {
                return $this->extractDate(date("{{\d\o\b|Y|n|d}}", $stamp));
            } else {
                //Multiple options could be here
                if (preg_match('/\((\s*(aged)\s*(\d)*\s*)\)/', $string)) {
                    $stamp = strtotime(preg_replace('/\((\s*(aged)\s*(\d)*\s*)\)/', '', $string));
                    return $this->extractDate(date("{{\d\o\b|Y|n|d}}", $stamp));
                }
            }
            return null;
        } else {
            //Exceptions of macroses
            if (strpos($string, '{{nowrap|') !== false) {
                if (strpos($string, '{{nowrap|') == 0) {
                    $string = str_replace("{{nowrap|", '', $string);
                    $string = $this->str_lreplace('}}', '', $string);
                    return $this->extractDate($string);
                }
            }
        }
        $processed = $this->processText($macrosses[0]);

        if (
            count($processed[0]) == 0 ||
            empty($processed[0]['type']) ||
            $processed[0]['type'] !== 'macros' ||
            empty($processed[0]['args']) ||
            !is_string($processed[0]['args'][0])
        ) {
            return null;
        }
        $dateArgs = $processed[0]['args'];

        switch (strtolower($dateArgs[0])) {
            case 'dob':
            case 'bda':
            case 'birth date':
            case 'birth date and age':

            case 'death date and age':
            case 'death date':
            case 'dda':
                if (count($dateArgs) < 4) {
                    return null;
                }
                if (!isset($dateArgs[1]) || !isset($dateArgs[2]) || !isset($dateArgs[3]) ||
                    !is_numeric($dateArgs[1]) || !is_numeric($dateArgs[2]) || !is_numeric($dateArgs[3])
                ) {
                    return null;
                }
                $year = $dateArgs[1];
                $month = $dateArgs[2];
                $day = $dateArgs[3];

                if (strlen($year) < 4) {
//                    $year = str_repeat('0', 4 - strlen($year)) . $year;
                }
                if (strlen($month) == 1) {
                    $month = '0' . $month;
                }
                if (strlen($day) == 1) {
                    $day = '0' . $day;
                }
                $result = [
                    'date' => "{$year}-{$month}-{$day}",
                    'key' => "{$month}-{$day}",
                    'year' => (int)($year),
                    'month' => (int)($month),
                    'day' => (int)($day),
                    'original' => $string,
                ];
                if (strtotime($result['date']) === false) {
                    return null;
                }
                return $result;

            case 'death year and age'://TODO should be checked for this string on different examples
                if (count($dateArgs) < 3) {
                    return null;
                }
                if (!isset($dateArgs[1]) || !isset($dateArgs[2]) ||
                    !is_numeric($dateArgs[1]) || !is_numeric($dateArgs[2])
                ) {
                    return null;
                }
                $d_year = $dateArgs[1];

                $result = [
                    'date' => "{$d_year}",
                    'key' => "",
                    'year' => (int)($d_year),
                    'month' => null,
                    'day' => null,
                    'original' => $string,
                ];
                return $result;
        }
        return null;
    }

    public function extractField($set, $key)
    {
        if (empty($set[$key])) {
            return null;
        }
        if (is_string($set[$key])) {
            $text = $set[$key];
        } else {
            $text = $this->unprocessText($set[$key]);
        }
        $text = preg_replace("#<!--[^>]*-->#", '', $text);
        $text = preg_replace("#<[^>]*>[^<]*</[^>]*>#", '', $text);
        $text = preg_replace("#<[^>]*/>#", '', $text);
        $text = preg_replace("#<br>#", "\n", $text);
        $text = trim($text);
        return $text;
    }

    public function extractLinks($text)
    {
        preg_match_all("#\[\[(?<link>[^\]\|]*)(\|(?<label>[^\]]*))?\]\]#", $text, $matches);
        $result = array_unique($matches['link']);
        sort($result);
        return $result;
    }

    public function extractBirthPlace($list, $regions, $sovereign){
        // checking list of places from dataset
        if (!is_array($list) && is_string($list)){
            $list = [$list];
        }
        $list = array_reverse($list);
        // dataset list of places
        foreach ($list as $item){
            switch ($item){
                case 'u.s.':
                case 'u.s.a.':
                case 'united states':
                case 'us':
                case 'usa':
                    $item = 'united states';
                    break;

                case 'uk':
                case 'u.k.':
                case 'united kingdom of great britain and ireland':
                case 'united kingdom of great britain':
                case 'united kingdom':
                    $item = 'united kingdom';
                    break;

                case 'soviet union':
                case 'ussr':
                case 'russian soviet federative socialist republic':
                case 'ukrainian soviet socialist republic':
                case 'russian sfsr':
                case 'russian ssr':
                case 'rsfsr':
                case 'lithuanian soviet socialist republic':
                case 'kazakh soviet socialist republic':
                case 'georgian soviet socialist republic':
                case 'ukrainian ssr':
                case 'belarusian ssr':
                case 'byelorussian ssr':
                case 'georgian ssr':
                case 'lithuanian ssr':
                case 'kazakh ssr':
                case 'latvian ssr':
                case 'azerbaijan ssr':
                case 'azerbaijani ssr':
                case 'uzbek ssr':
                case 'armenian ssr':
                case 'moldavian ssr':
                case 'moldovan ssr':
                case 'tajik ssr':
                case 'turkmen ssr':
                case 'kirghiz ssr':
                    $item = 'soviet union';
                    break;

                case 'sfry':
                case 'yugoslavia':
                case 'sfr yugoslavia':
                case 'socialist federal republic of yugoslavia':
                    $item = 'Federal Republic of Yugoslavia';

            }
            // standard list of regions
            foreach ($regions as $key => $region){
                // standard list of countries in region
                if ($k = array_search(strtolower($item), array_map('strtolower', $region))){
//                    var_dump([$k]);
                    return ["region" => $key, "country"=> $region[$k]];
                }
            }

            if ($y = array_search(strtolower($item), array_map('strtolower', $sovereign))){
//                var_dump($sovereign[$y]);
                return ["region" => 'former', "country" => $sovereign[$y]];
            }
        }

        return [];
    }

    public function explodeName($name)
    {
        $array = explode(' ', $name, 2);
        if (isset($array[1])){
            return [
                "first_name" => $array[0],
                "second_name" => $array[1]
            ];
        }else{
            return [
                "first_name" => $array[0],
                "second_name" => null
            ];
        }
    }

    public function unprocessText($data)
    {
        if (is_string($data) || is_numeric($data)) {
            return $data;
        }
        if (is_array($data)) {
            if (isset($data['type']) && $data['type'] == 'macros') {
                $result = [];
                foreach ($data['args'] as $key => $value) {
                    if (is_numeric($key)) {
                        $result[] = $this->unprocessText($value);
                    } else {
                        $result[] = $key . '=' . $this->unprocessText($value);
                    }
                }
                return '{{' . implode('|', $result) . '}}';
            } else {
                $result = [];
                foreach ($data as $value) {
                    $result[] = $this->unprocessText($value);
                }
                return implode(' ', $result);
            }
        }
        throw new \InvalidArgumentException("Unexpected content type: " . gettype($data));
    }

    public function processText($text)
    {
        if (is_array($text)) {
            return $text;
        }
        return $this->ast->parseText(trim($text));
    }

    public function simpleValueListParser($string)
    {
        $result = [];
        $tree = $this->processText($string);
        if (!is_array($tree)) {
            $tree = [$tree];
        }

        foreach ($tree as $line) {
            if (is_string($line)) {
                $result = array_merge($result, $this->_simpleValueListParser($line));
            } elseif (isset($line['type']) && $line['type'] == 'macros') {
                if (
                    is_string($line['args'][0]) &&
                    in_array(
                        strtolower($line['args'][0]), ['hlist', 'flat list', 'flatlist', 'plainlist']
                    )
                ) {
                    $listItems = $line['args'];
                    array_shift($listItems);
                    $cleanedListItem = '';
                    foreach ($listItems as $listItem) {
                        if (is_array($listItem)) {
                            foreach ($listItem as $sublistWithMacroses)
                                if (is_string($sublistWithMacroses)) {
                                    $cleanedListItem .= $sublistWithMacroses;
                                }
                        } else {
                            $cleanedListItem .= $listItem;
                        }
                        $cleanedListItem .= "\n";
                        $result = array_merge($result, $this->_simpleValueListParser($cleanedListItem));
                    }
                }
            }
        }

        $result = array_map('trim', $result);
        $result = array_map('strtolower', $result);
        $result = array_map('strip_tags', $result);

        $result = array_filter($result);
        $result = array_unique($result);
        sort($result);
        if (count($result) === 1) {
            $result = array_pop($result);
        }
        return $result;
    }

    public function _simpleValueListParser($string)
    {
        if (is_array($string)) {
            return [];
        }
        $string = explode('<gallery>', $string, 2)[0];

        preg_match_all("#\[\[([^\]]*)\]\]#", $string, $matches);
        $extracted = $matches[1];

        $result = $string;

        $result = str_replace(' and ', "\n", $result);
        $result = str_replace(', and ', "\n", $result);
        $result .= "\n" . implode("\n", $extracted);
        $result = str_replace([',', '|', '*', '<br>', '<br/>'], "\n", $result);
        $result = str_replace(['[', ']'], "", $result);
        $result = explode("\n", $result);

        return $result;
    }

    public function extractSpouse($string)
    {
        return [
            'alyce ferrill (1945–1974)',
            'victoria valentine (1976–1989)',
            'pam hurn (1992–2009)'
        ];
    }

    public function extractBio($text)
    {
        if (strpos($text, "==Biography==") !== false) {
            $str = $this->_takeBetween($text, "==Biography==", "==");
            if (trim($this->_cleanText($str)) !== "" && strlen(trim($this->_cleanText($str))) > 50) {
                return $this->_newLinesToParagraphs($this->_cleanText($str));
                //return $this->_cleanText($str);
            }
        }

        //Replace lowercase infobox if exists
        $text = str_replace('{{infobox', '{{Infobox', $text);

        if (strpos($text, "{{Infobox") !== false) {
            $text = $this->_cutInfobox($text);
        }

        $text = explode('==', $text, 2)[0];
        return $this->_newLinesToParagraphs($this->_cleanText($text));
        //return $this->_cleanText($text);
    }

    //  \((.*?)\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,2}(.*?|\,)\s*\d{0,4}\s*(–|-|&ndash;)(.*?)\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,2}(\,*)\s*\d{0,4}\s*(.*?)\)
    public function extractDatesFromBio($text)
    {
        $monthRegEx = '(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)';

        $nameRegEx = '';

        //RegEx: \(\s*\d{1,2}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{1,4}\s*(–|-|—|&ndash;)\s*(.*?)(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{1,4}\s*\)
        //Example: Edward III (13 November 1312 – 21 June 1377) was King of England and Lord of Ireland
        //Example: Isabella of England (16 June 1332 – c.April 1379), was the eldest daughter of King Edward III of England and Philippa of Hainault and the wife of Enguerrand de Courcy
        $full_regex = '\(\s*\d{1,2}\s*' . $monthRegEx . '\s*\d{1,4}\s*(–|-|—|&ndash;)\s*(.*?)' . $monthRegEx . '\s*\d{1,4}\s*\)';

        //RegEx: \((.*?)\d{0,2}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*(.*?)\d{0,4}\s*(–|-|—|&ndash;)\s*\d{0,2}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,4}\s*\)
        //Example: (French pronunciation: ​[ʒɔʁʒ glaːse]; 24 August 1907 – January 2002)
        //Example: (Arabic: عبد العزيز بن عبد الرحمن آل سعود‎, Abd al-'Azīz ibn 'Abd ar-Raḥman Āl Sa'ūd; 15 January 1875[1] – 9 November 1953)
        $full_regex_2 = '\((.*?)\d{0,2}\s*' . $monthRegEx . '\s*\w+([, .]+\w+){0,4}\d{0,4}\s*(–|-|—|&ndash;)\s*\d{0,2}\s*' . $monthRegEx . '\s*\d{0,4}\s*\)';

        //RegEx: \s*\d{1,4}(.*?|\,)\s*\d{1,4}\s*(–|-|—|&ndash;)(.*?)\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{1,2}(\,*)\s*\d{1,4}\s*(.*?)
        //Example: Ibō Takahashi (高橋 伊望 Takahashi Ibō, April 20, 1888 – March 18, 1947) was an admiral in the Imperial Japanese
        $full_regex_3 = $monthRegEx . '\s*\d{1,4}(.*?|\,)\s*\d{1,4}\s*(–|-|—|&ndash;)\s*' . $monthRegEx . '\s*\d{1,2}(\,*)\s*\d{1,4}\s*\w+([, .]+\w+){0,4}';

        //RegEx: \w+([, ."]+\w+){1,10}\s*\(\s*\d{1,4}\s*(–|-|—|&ndash;)\s*\d{1,4}\s*\)
        //Example: Rahman ibn Faisal ibn Turki ibn Abdullah ibn Muhammad Al Saud (1875 – 1953)
        $full_regex_4 = '\w+([, ."]+\w+){1,10}\s*\(\s*\d{1,4}\s*(–|-|—|&ndash;)\s*\d{1,4}\s*\)';

        //RegEx: \(\s*\d{0,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,4}\s*(–|-|—|&ndash;)\s*\d{2,4}\s*\)
        //Example: (21 November 1907 – 1976)
        $full_regex_5 = '\(\s*\d{0,4}\s*' . $monthRegEx . '\s*\d{0,4}\s*(–|-|—|&ndash;)\s*\d{2,4}\s*\)';

        //RegEx: \(\s*\d{0,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{1,4}(.*?|\,)\s*(–|-|—|&ndash;)\s*\d{2,4}\s*\)
        //Example: René Adolphe Schwaller de Lubicz (December 7, 1887 – 1961), was a French occultist
        $full_regex_6 = '\(\s*\d{0,4}\s*' . $monthRegEx . '\s*\d{1,4}(.*?|\,)\s*(–|-|—|&ndash;)\s*\d{2,4}\s*\)';

        //RegEx: \(\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,2}(.*?|\,)\s*\d{0,4}\s*\w+([, .]+\w+){1,4}\s*(–|-|—|&ndash;)\s*\w+([, .]+\w+){0,4}\s*\d{0,4}\s*\)
        //Example: René Adolphe Schwaller de Lubicz (December 7, 1887 – 1961), was a French occultist
        $full_regex_7 = '\(\s*' . $monthRegEx . '\s*\d{0,2}(.*?|\,)\s*\d{0,4}\s*\w+([, .]+\w+){0,4}\s*(–|-|—|&ndash;)\s*\w+([, .]+\w+){0,4}\s*\d{0,4}\s*\)';

        //RegEx: \(\s*\d{2,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{2,4}\s*(.*?|\,)\s*\w+([, .]+\w+){0,4}\s*(–|-|—|&ndash;)\s*\d{2,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{2,4}\s*(.*?|\,)\s*\w+([, .]+\w+){0,4}\s*\)
        //Example: Baron Slavko Cuvaj de Ivanska (26 February 1851, in Bjelovar – 31 January 1931, in Vienna) was a Croatian politician who was Ban
        $full_regex_8 = "\(\s*\d{2,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{2,4}\s*(.*?|\,)\s*\w+([, .]+\w+){0,4}\s*(–|-|—|&ndash;)\s*\d{2,4}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{2,4}\s*(.*?|\,)\s*\w+([, .]+\w+){0,4}\s*\)";

        //RegEx: \(\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,2}(.*?|\,)\s*\d{0,4}\s*(–|-|—|&ndash;)(.*?)\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,2}(\,*)\s*\d{0,4}\s*\)
        //Example: (April 20, 1888 – March 18, 1947)
        $full_regex_9 = '\(\s*' . $monthRegEx . '\s*\d{0,2}(.*?|\,)\s*\d{0,4}\s*(–|-|—|&ndash;)\w+([, .]+\w+){0,4}\s*' . $monthRegEx . '\s*\d{0,2}(\,*)\s*\d{0,4}\s*\)';


        //Example: 24 August 1907
        $date_regex = '\d{0,2}\s*' . $monthRegEx . '\s*\d{0,4}(\,*)\s*\d{0,4}';

        //Example: April 20, 1888
        //Example: 8 March 1908
        $date_regex_2 = "\d{0,2}\s*' . $monthRegEx . '\s*\d{0,4}(,)*\s*\d{2,4}";

        //Example: 1922
        $date_regex_3 = "\d{4,}";

        if (preg_match("/$full_regex/", $text)) {
            return $this->_getDates($full_regex, $date_regex, $date_regex, $text);
        }

        if (preg_match("/$full_regex_2/", $text)) {
            return $this->_getDates($full_regex_2, $date_regex, $date_regex, $text);
        }

        if (preg_match("/$full_regex_3/", $text)) {
            return $this->_getDates($full_regex_3, $date_regex_2, $date_regex_2, $text);
        }

        /*if (preg_match("/$full_regex_4/", $text)) {
            return $this->_getDates($full_regex_4, $date_regex_3, $date_regex_3, $text);
        }*/

        if (preg_match("/$full_regex_5/", $text)) {
            return $this->_getDates($full_regex_5, $date_regex, $date_regex_3, $text);
        }

        if (preg_match("/$full_regex_6/", $text)) {
            return $this->_getDates($full_regex_6, $date_regex_2, $date_regex_3, $text);
        }

        if (preg_match("/$full_regex_7/", $text)) {
            return $this->_getDates($full_regex_7, $date_regex_2, $date_regex_3, $text);
        }

        if (preg_match("/$full_regex_8/", $text)) {
            return $this->_getDates($full_regex_8, $date_regex, $date_regex, $text);
        }

        if (preg_match("/$full_regex_9/", $text)) {
            return $this->_getDates($full_regex_9, $date_regex, $date_regex, $text);
        }

        return null;
    }

    public function extractAliving($text)
    {
        $monthRegEx = '(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)';
        $fullRegex_1 = '\w+([, ."]+\w+){1,10}\s*\(\s*' . $monthRegEx . '\s*\d{0,2}(\,)\s*\d{0,4}\s*(–|-|—|&ndash;)\s*' . $monthRegEx . '\s*\d{0,2}(\,*)\s*\d{0,4}\s*\)\s*(, was an |was an |was a |was the |was )';
        $fullRegex_2 = '\(\s*\w+([, ."]+\w+){1,3}\s*\d{1,2}\s*' . $monthRegEx . '\s*\d{1,4}\s*(–|-|—|&ndash;)\s*\w+([, ."]+\w+){1,4}\s*(unknown)\s*\)';
        $fullRegex_3 = '\w+([, ."]+\w+){1,10}\s*\((born)\s*' . $monthRegEx . '\s*\d{0,2}(\,)\s*\d{0,4}\s*\)\s*(is an |is a |is the |is )';
        $fullRegex_4 = '\w+([, ."-]+\w+){1,10}\s*\(((born)|(born\s*\w+([, .-]+\w+){0,10}))\s*' . $monthRegEx . '\s*\d{0,2}(\,)\s*\d{0,4}\s*((\s*)|(\w+([, ."-]+\w+){1,10}\s*))\)\s*';
        $fullRegex_5 = '\w+([, ."-]+\w+){1,10}\s*\(((born)|(born\s*\w+([, .-]+\w+){0,10}))\s*' . $monthRegEx . '\s*\d{0,2}(\,)\s*\d{0,4}\s*\w+([, ."-]+\w+){1,10}\s*\)\s*(, was an |was an |was a |was the |was )';

        //Carlo Crotti (born September 9, 1900) was an Italian professional football player
        $fullRegex_6 = '\w+([, ."-]+\w+){1,10}\s*\((born)\s*' . $monthRegEx . '\s*\d{0,2}[\,]\s*\d{0,4}\s*\)\s*(, was an |was an |was a |was the |was )';

        //Nais Lago (born 25 February 1914) was an Italian stage
        $fullRegex_7 = '\w+([, ."-]+\w+){1,10}\s*\((born)\s*\d{0,2}\s*(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)\s*\d{0,4}\s*\)\s*(, was an |was an |was a |was the |was )';

        if (preg_match("/$fullRegex_5/", $text)) {
            return 'dead';
        }

        if (preg_match("/$fullRegex_6/", $text)) {
            return 'dead';
        }

        if (preg_match("/$fullRegex_7/", $text)) {
            return 'dead';
        }

        if (preg_match("/$fullRegex_4/", $text)) {
            return 'alive';
        }

        if (preg_match("/$fullRegex_3/", $text)) {
            return 'alive';
        }

        if (preg_match("/$fullRegex_1/", $text)) {
            return 'dead';
        }

        if (preg_match("/$fullRegex_2/", $text)) {
            return 'dead';
        }
        return 'unknown';
    }

    public function getAged($date_1, $date_2 = null)
    {
        $datetime1 = date_create($date_1);
        if ($date_2 !== null) $datetime2 = date_create($date_2);
        else $datetime2 = date_create();
        $interval = date_diff($datetime1, $datetime2);

        return $interval->format('%y');
    }

    public function imgDeletedClean($name)
    {
        $name = str_replace("<!-- Commented out because image was deleted:", "", $name);
        $name = str_replace("\n<!--  Commented out because image was deleted:", "", $name);
        return trim($name);
    }

    public function extractDeathDate($text)
    {
        $monthRegEx = '(November|Nov|December|Dec|January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sep|October|Oct)';
        $regex = '\|death_date\s*\=\s*(\d{1,2})*\s*' . $monthRegEx . '\s*\d{1,2}[ ,]\s*\d{2,4}\s*\|';
        //Example: 24 August 1907
        $date_regex = '\d{0,2}\s*' . $monthRegEx . '\s*\d{0,4}(\,*)\s*\d{0,4}';
        //Example: April 20, 1888
        //Example: 8 March 1908
        $date_regex_2 = "\d{0,2}\s*' . $monthRegEx . '\s*\d{0,4}(,)*\s*\d{2,4}";

        if (preg_match("/$regex/", $text, $matches)) {
            if (preg_match("/$date_regex/", $matches[0], $date_match)) {
                return trim($date_match[0]);
            }
            if (preg_match("/$date_regex_2/", $matches[0], $date_match)) {
                return trim($date_match[0]);
            }
        }
        return null;
    }

    public function XtractText($text)
    {
        //Replace lowercase infobox if exists
        $text = str_replace('{{infobox', '{{Infobox', $text);

        if (strpos($text, "{{Infobox") !== false) {
            $text = $this->_cutInfobox($text);
        }

        $text = $this->_cleanText($text);
        //$text = strip_tags($text);
        if (is_string($text)) return $text;
        else return '';
    }

    private function _takeBetween($content, $start, $end)
    {
        $r = explode($start, $content, 2);
        if (isset($r[1])) {
            $r = explode($end, $r[1]);
            return trim($r[0]);
        }
        return '';
    }

    private function _handleFiguredBrackets(&$str)
    {
        $f = strpos($str, "{{");
        $e = strpos($str, "}}");
        if ($f !== false && $e !== false) {
            $substr = substr($str, $f + 2, $e - $f);
            $str = substr_replace($str, '', $f, $e - $f + 2);
            //$str = preg_replace("/$substr/", '', $str, 1);
            //Recursive handling
            $this->_handleFiguredBrackets($str);
            return $str;
        }
        return $str;
    }

    private function _cleanText($str)
    {
        //Remove tags <ref>
        /*$str = preg_replace('#(<ref.*?>).*?(</ref>)#', '$1$2', $str);*/
        $str = preg_replace('/<ref[^>]*>.*?<\/ref>/i', '', $str);
        //Trimming string and replacing newlines
        //$str = trim(preg_replace('/\s+/', ' ', $str));

        $str = str_replace(array('}}, {{'), '}} {{', $str);

        $str = $this->_handleComplexLinks($str);
        $str = $this->_parseQuotes($str);

        $str = str_replace('{{spaced ndash}}', ' – ', $str);
        $str = preg_replace('/\[\[Image:(.*?)\]\]/', '', $str);
        $str = preg_replace('/\[\[File:(.*?)\]\]/', '', $str);
        $str = preg_replace('/\[http:\/\/(.*?)\]/', '', $str);
        $str = preg_replace('/\[https:\/\/(.*?)\]/', '', $str);

        //Handling substrings with {{asdf|asdf}} model using callback inside
        /*$str = preg_replace_callback('/\{\{(.*?)\}\}/', function ($matches) {
            if (strpos($matches[1], '|')) {
                $s = explode('|', $matches[1]);
                return $s[1];
            }
            return $matches[1];
        }, $str);*/

        //Handling substrings with [[asdf|asdf]] model using callback inside
        $str = preg_replace_callback('/\[\[(.*?)\]\]/', function ($matches) {
            if (strpos($matches[1], '|')) {
                $s = explode('|', $matches[1]);
                return $s[1];
            }
            return $matches[1];
        }, $str);

        //Removing complex data {{ {{asdfasdf}} {{asdfasdf}} }}
        $str = $this->_removeBetweenStrings('{{#tag:ref|', '|group=nb}}', $str);

        //Handling substrings with {{asdf|date=August 2016}} model using callback inside
        $str = preg_replace('/\{\{.*?\}\}/', "", $str);
        //Remove or handle all between {{ and }}
        //$str = $this->_handleFiguredBrackets($str);
        $str = $this->_removeBetweenStrings('{{', '}}', $str);

        //Remove multiple quotes
        $str = str_replace(array('\'\'\''), '', $str);
        $str = str_replace(
            ['\'\'', '&ndash;', ' * ', '()', '  ', '&nbsp;', '(;', '(,', '( ; ', '* ', '( )', '}}', ', ;'],
            ['', '–', '\n', '', ' ', ' ', '(', '(', '(', '', '', '', ';'],
            $str);
        $str = strip_tags($str, '<p><blockquote>');
        $str = trim($str);
        //$str = $this->_newLinesToParagraphs($str);
        return $str;
    }

    private function _removeBetweenStrings($start, $end, $str)
    {
        $startPos = strpos($str, $start);
        $endPos = strrpos($str, $end);
        if ($startPos === false || $endPos === false) {
            return $str;
        }

        $textToDelete = substr($str, $startPos, ($endPos + strlen($end)) - $startPos);

        return str_replace($textToDelete, '', $str);
    }

    private function _cutInfobox($text)
    {
        //Clean string before infobox
        $str = strstr($text, "{{Infobox");
        $str = preg_replace('/{{Infobox/', 'Infobox', $str, 1);
        //$str = str_replace("{{Infobox", 'Infobox', $str);

        //Cut infobox
        $counter = 0;
        while ($counter >= 0) {
            $f = strpos($str, '{{');
            $n = strpos($str, '}}');

            if ($f === false && $n !== false) $f = strlen($str);

            if ($f < $n && $f !== false) {
                $str = strstr($str, '{{');
                $str = preg_replace('/{{/', '', $str, 1);
                $counter++;
            }

            if ($n < $f) {
                $str = strstr($str, '}}');
                $str = preg_replace('/}}/', '', $str, 1);
                $counter--;
            }

            if ($counter < 0 || empty($str)) {
                break;
            }
        }

        return $str;
    }

    /**
     * Handling of links like:
     * [http://www.ascensia.com/ Ascensia Diabetes Care]
     * [http://www.nationalmedals.org/about/contact_thanks.php National Science and Technology Medals Foundation, Photograph by Ryan K. Morris]
     * @param $str
     * @return null|string|string[]
     */
    private function _handleComplexLinks($str)
    {
        $str = preg_replace_callback('/\[http:\/\/(.*?)\]|\[https:\/\/(.*?)\]/', function ($matches) {
            $matches = array_values(array_filter($matches));
            if (strpos($matches[1], ' ')) {
                $s = explode(' ', $matches[1]);
                unset($s[0]);
                $matches[1] = implode(" ", $s);
            }
            return $matches[1];
        }, $str);

        return $str;
    }

    /**
     * @param $text
     * @return mixed
     */
    protected function _parseQuotes($text)
    {
        $tree = $this->ast->parseText($text);

        if (is_array($tree) && !empty($tree)) {
            $search = [];
            $replace = [];
            //var_dump($tree);

            $tree = array_filter($tree, function ($v, $k) {
                return (is_array($v) && isset($v['args'][0]) && $v['args'][0] === 'quote');
            }, ARRAY_FILTER_USE_BOTH);
            foreach ($tree as $k => $v) {
                $search[] = $v['text'];
                if (isset($v['args'][1]) && !is_array($v['args'][1])) {
                    $replace[] = '<blockquote>' . $v['args'][1] . '</blockquote>';
                }
            }
            if (!empty($search) && !empty($replace)) {
                $text = str_replace($search, $replace, $text);
            }
        }
        return $text;
    }

    protected function _newLinesToParagraphs($text)
    {
        $text = "<p>" . $text;
        //$text = preg_replace("/(\s)+/", "$1", $text);
        $text = preg_replace("/[\r\n]+/", "\n", $text);
        $text = preg_replace('/\n/', '</p><p>', $text);
        $text = $text . "</p>";
        return $text;
    }

    protected function str_lreplace($search, $replace, $subject)
    {
        $pos = strrpos($subject, $search);

        if ($pos !== false) {
            $subject = substr_replace($subject, $replace, $pos, strlen($search));
        }

        return $subject;
    }

    public function firstParagraph($text)
    {
        $regex = "\'\'\'(.*?)\'\'\'(.*?)\s*\=\=";
        $matches = [];
        preg_match("/$regex/", $text, $matches);
        if (!empty($matches)) {
            $res = explode('==', $matches[0], 2)[0];
            $res = $this->_newLinesToParagraphs($this->_cleanText($res));
            return $res;
        }
        return null;
    }

    private function _getDates($full_regex, $date_regex, $date_regex_2, $text)
    {
        $matches = [];
        preg_match("/$full_regex/", $text, $matches);
        $dates = explode('–', $matches[0]);
        if (count($dates) < 2) $dates = explode('—', $matches[0]);
        if (count($dates) < 2) $dates = explode('-', $matches[0]);
        if (count($dates) < 2) $dates = explode('&ndash;', $matches[0]);

        if (strtotime($dates[0]) !== false) $res_b[0] = $dates[0];
        else preg_match("/$date_regex/", $dates[0], $res_b);

        if (strtotime($dates[1]) !== false) $res_d[0] = $dates[1];
        else preg_match("/$date_regex_2/", $dates[1], $res_d);

        if (!empty($res_b[0]) && strlen($res_b[0]) == 4 && (int)$res_b[0] !== 0) {
            $res_b[0] = (int)$res_b[0];
            $dt = DateTime::createFromFormat('Y-m-d', $res_b[0] . "-01-01");
            $birth_d = $dt->format('Y-m-d');
        } else
            $birth_d = empty($res_b[0]) ? null : date('Y-m-d', strtotime(trim($res_b[0])));

        if (!empty($res_d[0]) && strlen($res_d[0]) == 4 && (int)$res_d[0] !== 0) {
            $res_d[0] = (int)$res_d[0];
            $dt = DateTime::createFromFormat('Y-m-d', $res_d[0] . "-01-01");
            $death_d = $dt->format('Y-m-d');
        } else
            $death_d = empty($res_d[0]) ? null : date('Y-m-d', strtotime(trim($res_d[0])));

        return [
            'birth_date' => $birth_d,
            'death_date' => $death_d
        ];
    }
}

