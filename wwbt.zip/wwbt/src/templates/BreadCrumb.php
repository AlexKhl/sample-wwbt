<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 12/02/18
 * Time: 11:49 AM
 */

namespace diplux\templates;


class BreadCrumb
{
    private $label;
    private $path;

    /**
     * BreadCrumb constructor.
     * @param $label string|array
     * @param $path string|null
     */
    public function __construct($label, $path = null)
    {
        if (is_array($label)) {
            $path = $label[1];
            $label = $label[0];
        }
        $this->label = $label;
        $this->path = $path;
    }

    /**
     * @return string
     */
    public function getLabel(): string
    {
        return $this->label;
    }

    /**
     * @return string
     */
    public function getPath(): string
    {
        return $this->path;
    }
}