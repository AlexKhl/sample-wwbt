<?php

namespace diplux\templates;


class Paginator
{
    public $basePath = '';
    public $total = 0;
    public $totalPages = 0;
    public $currentPage = 0;
    public $pageSize = 0;
    public $firstPage = 0;
    public $lastPage = 0;

    /**
     * Paginator constructor.
     * @param string $basePath
     * @param int $total
     * @param int $currentPage
     * @param int $pageSize
     */
    public function __construct($basePath, $total, $currentPage, $pageSize)
    {
        $this->basePath = $basePath;
        $this->total = $total;
        $this->currentPage = $currentPage;
        $this->pageSize = $pageSize;

        $this->totalPages = (int)ceil($total / $pageSize);
        $this->lastPage = $this->totalPages > 0 ? $this->totalPages - 1 : 0;
    }

    public function getLabel(int $page)
    {
        return $page + 1;
    }

    public function getPath(int $page = 0)
    {
        if ($page == 0) {
            return $this->basePath;
        } else {
            return \_::normalize_path($this->basePath . '/' . $page);
        }
    }

    /**
     * @return string
     */
    public function getBasePath(): string
    {
        return $this->basePath;
    }

    /**
     * @param string $basePath
     */
    public function setBasePath(string $basePath)
    {
        $this->basePath = $basePath;
    }

    /**
     * @return int
     */
    public function getTotal(): int
    {
        return $this->total;
    }

    /**
     * @param int $total
     */
    public function setTotal(int $total)
    {
        $this->total = $total;
    }

    /**
     * @return int
     */
    public function getTotalPages(): int
    {
        return $this->totalPages;
    }

    /**
     * @param int $totalPages
     */
    public function setTotalPages(int $totalPages)
    {
        $this->totalPages = $totalPages;
    }

    /**
     * @return int
     */
    public function getCurrentPage(): int
    {
        return $this->currentPage;
    }

    /**
     * @param int $currentPage
     */
    public function setCurrentPage(int $currentPage)
    {
        $this->currentPage = $currentPage;
    }

    /**
     * @return int
     */
    public function getPageSize(): int
    {
        return $this->pageSize;
    }

    /**
     * @param int $pageSize
     */
    public function setPageSize(int $pageSize)
    {
        $this->pageSize = $pageSize;
    }

    /**
     * @return int
     */
    public function getFirstPage(): int
    {
        return $this->firstPage;
    }

    /**
     * @param int $firstPage
     */
    public function setFirstPage(int $firstPage)
    {
        $this->firstPage = $firstPage;
    }

    /**
     * @return int
     */
    public function getLastPage(): int
    {
        return $this->lastPage;
    }

    /**
     * @param int $lastPage
     */
    public function setLastPage(int $lastPage)
    {
        $this->lastPage = $lastPage;
    }
}