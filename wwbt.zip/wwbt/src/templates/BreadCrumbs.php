<?php
/**
 * Created by IntelliJ IDEA.
 * User: pavel
 * Date: 12/02/18
 * Time: 11:50 AM
 */

namespace diplux\templates;


class BreadCrumbs
{
    /**
     * @var BreadCrumb[]
     */
    private $crumbs = [];

    /**
     * BreadCrumbs constructor.
     * @param array $crumbs
     */
    public function __construct($crumbs = [])
    {
        foreach ($crumbs as $crumb) {
            if ($crumb instanceof BreadCrumb) {
                $this->crumbs[] = $crumb;
            } else {
                $this->crumbs[] = new BreadCrumb($crumb);
            }
        }
    }

    /**
     * @return BreadCrumb[]
     */
    public function getCrumbs(): array
    {
        return $this->crumbs;
    }

    /**
     * @param BreadCrumb[] $crumbs
     * @return BreadCrumbs
     */
    public function setCrumbs(array $crumbs)
    {
        $this->crumbs = $crumbs;
        return $this;
    }

    public function size()
    {
        return count($this->crumbs);
    }

    /**
     * @param $i
     * @return BreadCrumb
     */
    public function get($i)
    {
        return $this->crumbs[$i] ?? null;
    }

}