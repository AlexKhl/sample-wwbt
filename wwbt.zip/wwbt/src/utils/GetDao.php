<?php

class GetDao
{
    public static function Person(){
        return new \diplux\app\dao\PersonDao();
    }
}